{
    'name': 'FyA PLE 3.0 - Libro de Inventarios y Balances',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations',
    'summary': 'Generación de PLE 3.0 - Libro de Inventarios y Balances para SUNAT Perú',
    'description': '''
        Módulo para generar el Programa de Libros Electrónicos (PLE) 3.0
        - Libro de Inventarios y Balances
        - Documento 3.1: Estado de Situación Financiera
        - Arquitectura escalable para 23 subdocumentos
    ''',
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_03_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
