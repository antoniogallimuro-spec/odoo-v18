from odoo import api, fields, models, _


class PleLine0317(models.Model):
    _name = 'ple.line.03.17'
    _description = 'PLE 3.17 - Detalle del Saldo de la Cuenta 34 - Intangibles'
    _order = 'sequence, account_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 3.17
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )

    account_plan_code = fields.Char(
        string='Código Plan de Cuentas',
        default='01',
        help='01 = Plan Contable General Empresarial'
    )

    account_id = fields.Many2one(
        'account.account',
        string='Cuenta Contable',
        required=True,
        domain="[('company_ids', 'in', company_id), ('code', '=like', '34%')]"
    )

    account_code = fields.Char(
        string='Código Cuenta',
        required=True,
        help='Código de la cuenta contable (debe empezar con 34)'
    )

    account_name = fields.Char(
        string='Descripción Cuenta',
        required=True,
        help='Descripción de la cuenta contable'
    )

    intangible_code = fields.Char(
        string='Código del Intangible',
        help='Código de identificación del activo intangible'
    )

    intangible_description = fields.Char(
        string='Descripción del Intangible',
        help='Descripción detallada del activo intangible'
    )

    acquisition_date = fields.Date(
        string='Fecha de Adquisición',
        help='Fecha de adquisición o desarrollo del intangible'
    )

    acquisition_cost = fields.Monetary(
        string='Costo de Adquisición',
        currency_field='company_currency_id',
        default=0.0,
        help='Costo de adquisición o desarrollo del intangible'
    )

    accumulated_amortization = fields.Monetary(
        string='Amortización Acumulada',
        currency_field='company_currency_id',
        default=0.0,
        help='Amortización acumulada al cierre del período'
    )

    final_balance = fields.Monetary(
        string='Saldo Final (Valor Neto)',
        currency_field='company_currency_id',
        compute='_compute_final_balance',
        store=True,
        help='Valor neto del intangible (costo - amortización acumulada)'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.depends('acquisition_cost', 'accumulated_amortization')
    def _compute_final_balance(self):
        for line in self:
            line.final_balance = line.acquisition_cost - line.accumulated_amortization

    @api.onchange('account_id')
    def _onchange_account_id(self):
        """Auto-completar código y nombre cuando se selecciona cuenta"""
        if self.account_id:
            self.account_code = self.account_id.code
            self.account_name = self.account_id.name

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.17

        Estructura:
        1. Periodo (8)
        2. Código Plan de Cuentas (2)
        3. Código Cuenta Contable (24)
        4. Descripción Cuenta (100)
        5. Código del Intangible (20)
        6. Descripción del Intangible (100)
        7. Fecha de Adquisición (10) DD/MM/YYYY
        8. Costo de Adquisición (decimal 12.2)
        9. Amortización Acumulada (decimal 12.2)
        10. Saldo Final - Valor Neto (decimal 12.2)
        11. Indicador Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear fecha
        date_str = self.acquisition_date.strftime('%d/%m/%Y') if self.acquisition_date else ''

        # Formatear valores numéricos
        cost_str = f"{self.acquisition_cost:.2f}" if self.acquisition_cost else "0.00"
        amort_str = f"{self.accumulated_amortization:.2f}" if self.accumulated_amortization else "0.00"
        balance_str = f"{self.final_balance:.2f}" if self.final_balance else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                              # 1. Periodo
            self.account_plan_code or '01',                # 2. Código Plan
            self.account_code or '',                       # 3. Código Cuenta
            self.account_name or '',                       # 4. Descripción Cuenta
            self.intangible_code or '',                    # 5. Código Intangible
            self.intangible_description or '',             # 6. Descripción Intangible
            date_str,                                      # 7. Fecha Adquisición
            cost_str,                                      # 8. Costo Adquisición
            amort_str,                                     # 9. Amortización Acumulada
            balance_str,                                   # 10. Saldo Final
            self.state_code or '1',                        # 11. Estado
        ]

        return '|'.join(line_parts) + '|'

    @api.model_create_multi
    def create(self, vals_list):
        """Auto-completar campos al crear"""
        for vals in vals_list:
            if 'account_id' in vals and vals['account_id']:
                account = self.env['account.account'].browse(vals['account_id'])
                if not vals.get('account_code'):
                    vals['account_code'] = account.code
                if not vals.get('account_name'):
                    vals['account_name'] = account.name

        return super().create(vals_list)

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code}] {line.account_name}"
            if line.intangible_description:
                name += f" - {line.intangible_description}"
            result.append((line.id, name))
        return result
