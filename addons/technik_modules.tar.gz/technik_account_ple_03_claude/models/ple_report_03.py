from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
import base64
import logging

_logger = logging.getLogger(__name__)


class PleReport03(models.Model):
    _name = 'ple.report.03'
    _description = 'PLE 3.0 - Libro de Inventarios y Balances'
    _order = 'year desc, period desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True,
        readonly=True
    )
    
    year = fields.Integer(
        string='Año',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True
    )
    
    period_type = fields.Selection([
        ('day', 'Día'),
        ('period', 'Periodo')
    ], string='Tipo de Periodo', required=True, default='period', tracking=True)
    
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company,
        tracking=True
    )
    
    period = fields.Char(
        string='Periodo',
        required=True,
        help='Formato YYYYMMDD según tipo de periodo',
        tracking=True
    )
    
    period_date = fields.Date(
        string='Fecha del Periodo',
        compute='_compute_period_date',
        store=True,
        readonly=True
    )
    
    date_start = fields.Date(
        string='Fecha Inicio',
        required=True,
        tracking=True
    )
    
    date_end = fields.Date(
        string='Fecha Fin',
        required=True,
        tracking=True
    )
    
    date_generated = fields.Datetime(
        string='Fecha de Generación',
        readonly=True,
        tracking=True
    )
    
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('generated', 'Generado'),
        ('published', 'Publicado')
    ], string='Estado', default='draft', required=True, tracking=True)

    # Líneas para documento 3.1
    line_03_01_ids = fields.One2many(
        'ple.line.03.01',
        'report_id',
        string='Líneas 3.1 - Estado de Situación Financiera'
    )
    
    line_count_03_01 = fields.Integer(
        string='Total Líneas 3.1',
        compute='_compute_line_counts'
    )
    
    # Líneas para documento 3.2
    line_03_02_ids = fields.One2many(
        'ple.line.03.02',
        'report_id',
        string='Líneas 3.2 - Detalle Cuenta 10'
    )
    
    line_count_03_02 = fields.Integer(
        string='Total Líneas 3.2',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.3
    line_03_03_ids = fields.One2many(
        'ple.line.03.03',
        'report_id',
        string='Líneas 3.3 - Detalle Cuenta 12'
    )

    line_count_03_03 = fields.Integer(
        string='Total Líneas 3.3',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.4
    line_03_04_ids = fields.One2many(
        'ple.line.03.04',
        'report_id',
        string='Líneas 3.4 - Detalle Cuenta 14'
    )

    line_count_03_04 = fields.Integer(
        string='Total Líneas 3.4',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.5
    line_03_05_ids = fields.One2many(
        'ple.line.03.05',
        'report_id',
        string='Líneas 3.5 - Detalle Cuenta 16'
    )

    line_count_03_05 = fields.Integer(
        string='Total Líneas 3.5',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.6
    line_03_06_ids = fields.One2many(
        'ple.line.03.06',
        'report_id',
        string='Líneas 3.6 - Detalle Cuenta 19'
    )

    line_count_03_06 = fields.Integer(
        string='Total Líneas 3.6',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.7
    line_03_07_ids = fields.One2many(
        'ple.line.03.07',
        'report_id',
        string='Líneas 3.7 - Detalle Cuenta 20'
    )

    line_count_03_07 = fields.Integer(
        string='Total Líneas 3.7',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.8
    line_03_08_ids = fields.One2many(
        'ple.line.03.08',
        'report_id',
        string='Líneas 3.8 - Detalle Cuenta 21'
    )

    line_count_03_08 = fields.Integer(
        string='Total Líneas 3.8',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.9
    line_03_09_ids = fields.One2many(
        'ple.line.03.09',
        'report_id',
        string='Líneas 3.9 - Detalle Cuenta 22'
    )

    line_count_03_09 = fields.Integer(
        string='Total Líneas 3.9',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.10
    line_03_10_ids = fields.One2many(
        'ple.line.03.10',
        'report_id',
        string='Líneas 3.10 - Detalle Cuenta 23'
    )

    line_count_03_10 = fields.Integer(
        string='Total Líneas 3.10',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.11
    line_03_11_ids = fields.One2many(
        'ple.line.03.11',
        'report_id',
        string='Líneas 3.11 - Detalle Cuenta 41'
    )

    line_count_03_11 = fields.Integer(
        string='Total Líneas 3.11',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.12
    line_03_12_ids = fields.One2many(
        'ple.line.03.12',
        'report_id',
        string='Líneas 3.12 - Detalle Cuenta 42-43'
    )

    line_count_03_12 = fields.Integer(
        string='Total Líneas 3.12',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.13
    line_03_13_ids = fields.One2many(
        'ple.line.03.13',
        'report_id',
        string='Líneas 3.13 - Detalle Cuenta 46'
    )

    line_count_03_13 = fields.Integer(
        string='Total Líneas 3.13',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.14
    line_03_14_ids = fields.One2many(
        'ple.line.03.14',
        'report_id',
        string='Líneas 3.14 - Detalle Cuenta 47'
    )

    line_count_03_14 = fields.Integer(
        string='Total Líneas 3.14',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.15
    line_03_15_ids = fields.One2many(
        'ple.line.03.15',
        'report_id',
        string='Líneas 3.15 - Detalle Cuenta 49'
    )

    line_count_03_15 = fields.Integer(
        string='Total Líneas 3.15',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.16.1
    line_03_16_1_ids = fields.One2many(
        'ple.line.03.16.1',
        'report_id',
        string='Líneas 3.16.1 - Detalle Cuenta 50'
    )

    line_count_03_16_1 = fields.Integer(
        string='Total Líneas 3.16.1',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.17
    line_03_17_ids = fields.One2many(
        'ple.line.03.17',
        'report_id',
        string='Líneas 3.17 - Detalle Cuenta 34'
    )

    line_count_03_17 = fields.Integer(
        string='Total Líneas 3.17',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.18
    line_03_18_ids = fields.One2many(
        'ple.line.03.18',
        'report_id',
        string='Líneas 3.18 - Estado Flujos Efectivo'
    )

    line_count_03_18 = fields.Integer(
        string='Total Líneas 3.18',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.19
    line_03_19_ids = fields.One2many(
        'ple.line.03.19',
        'report_id',
        string='Líneas 3.19 - Estado Cambios Patrimonio'
    )

    line_count_03_19 = fields.Integer(
        string='Total Líneas 3.19',
        compute='_compute_line_counts'
    )

    # Líneas para documento 3.20
    line_03_20_ids = fields.One2many(
        'ple.line.03.20',
        'report_id',
        string='Líneas 3.20 - Estado Ganancias Pérdidas'
    )

    line_count_03_20 = fields.Integer(
        string='Total Líneas 3.20',
        compute='_compute_line_counts'
    )

    # Archivos generados
    txt_filename_03_01 = fields.Char(string='Nombre Archivo TXT 3.1')
    txt_file_03_01 = fields.Binary(string='Archivo TXT 3.1', readonly=True)
    
    txt_filename_03_02 = fields.Char(string='Nombre Archivo TXT 3.2')
    txt_file_03_02 = fields.Binary(string='Archivo TXT 3.2', readonly=True)

    txt_filename_03_03 = fields.Char(string='Nombre Archivo TXT 3.3')
    txt_file_03_03 = fields.Binary(string='Archivo TXT 3.3', readonly=True)

    txt_filename_03_04 = fields.Char(string='Nombre Archivo TXT 3.4')
    txt_file_03_04 = fields.Binary(string='Archivo TXT 3.4', readonly=True)

    txt_filename_03_05 = fields.Char(string='Nombre Archivo TXT 3.5')
    txt_file_03_05 = fields.Binary(string='Archivo TXT 3.5', readonly=True)

    txt_filename_03_06 = fields.Char(string='Nombre Archivo TXT 3.6')
    txt_file_03_06 = fields.Binary(string='Archivo TXT 3.6', readonly=True)

    txt_filename_03_07 = fields.Char(string='Nombre Archivo TXT 3.7')
    txt_file_03_07 = fields.Binary(string='Archivo TXT 3.7', readonly=True)

    txt_filename_03_08 = fields.Char(string='Nombre Archivo TXT 3.8')
    txt_file_03_08 = fields.Binary(string='Archivo TXT 3.8', readonly=True)

    txt_filename_03_09 = fields.Char(string='Nombre Archivo TXT 3.9')
    txt_file_03_09 = fields.Binary(string='Archivo TXT 3.9', readonly=True)

    txt_filename_03_10 = fields.Char(string='Nombre Archivo TXT 3.10')
    txt_file_03_10 = fields.Binary(string='Archivo TXT 3.10', readonly=True)

    txt_filename_03_11 = fields.Char(string='Nombre Archivo TXT 3.11')
    txt_file_03_11 = fields.Binary(string='Archivo TXT 3.11', readonly=True)

    txt_filename_03_12 = fields.Char(string='Nombre Archivo TXT 3.12')
    txt_file_03_12 = fields.Binary(string='Archivo TXT 3.12', readonly=True)

    txt_filename_03_13 = fields.Char(string='Nombre Archivo TXT 3.13')
    txt_file_03_13 = fields.Binary(string='Archivo TXT 3.13', readonly=True)

    txt_filename_03_14 = fields.Char(string='Nombre Archivo TXT 3.14')
    txt_file_03_14 = fields.Binary(string='Archivo TXT 3.14', readonly=True)

    txt_filename_03_15 = fields.Char(string='Nombre Archivo TXT 3.15')
    txt_file_03_15 = fields.Binary(string='Archivo TXT 3.15', readonly=True)

    txt_filename_03_16_1 = fields.Char(string='Nombre Archivo TXT 3.16.1')
    txt_file_03_16_1 = fields.Binary(string='Archivo TXT 3.16.1', readonly=True)

    txt_filename_03_17 = fields.Char(string='Nombre Archivo TXT 3.17')
    txt_file_03_17 = fields.Binary(string='Archivo TXT 3.17', readonly=True)

    txt_filename_03_18 = fields.Char(string='Nombre Archivo TXT 3.18')
    txt_file_03_18 = fields.Binary(string='Archivo TXT 3.18', readonly=True)

    txt_filename_03_19 = fields.Char(string='Nombre Archivo TXT 3.19')
    txt_file_03_19 = fields.Binary(string='Archivo TXT 3.19', readonly=True)

    txt_filename_03_20 = fields.Char(string='Nombre Archivo TXT 3.20')
    txt_file_03_20 = fields.Binary(string='Archivo TXT 3.20', readonly=True)

    @api.depends('year', 'period', 'company_id')
    def _compute_name(self):
        for record in self:
            if record.year and record.period:
                vat = record.company_id.vat or '00000000000'
                record.name = f"PLE 3.0 - {vat} - {record.year}{record.period}"
            else:
                record.name = "Nuevo PLE 3.0"
    
    @api.depends('period', 'period_type')
    def _compute_period_date(self):
        for record in self:
            if record.period and len(record.period) == 8:
                try:
                    record.period_date = datetime.strptime(record.period, '%Y%m%d').date()
                except:
                    record.period_date = False
            else:
                record.period_date = False
    
    @api.depends('line_03_01_ids', 'line_03_02_ids', 'line_03_03_ids', 'line_03_04_ids', 'line_03_05_ids', 'line_03_06_ids', 'line_03_07_ids', 'line_03_08_ids', 'line_03_09_ids', 'line_03_10_ids', 'line_03_11_ids', 'line_03_12_ids', 'line_03_13_ids', 'line_03_14_ids', 'line_03_15_ids', 'line_03_16_1_ids', 'line_03_17_ids', 'line_03_18_ids', 'line_03_19_ids', 'line_03_20_ids')
    def _compute_line_counts(self):
        for record in self:
            record.line_count_03_01 = len(record.line_03_01_ids)
            record.line_count_03_02 = len(record.line_03_02_ids)
            record.line_count_03_03 = len(record.line_03_03_ids)
            record.line_count_03_04 = len(record.line_03_04_ids)
            record.line_count_03_05 = len(record.line_03_05_ids)
            record.line_count_03_06 = len(record.line_03_06_ids)
            record.line_count_03_07 = len(record.line_03_07_ids)
            record.line_count_03_08 = len(record.line_03_08_ids)
            record.line_count_03_09 = len(record.line_03_09_ids)
            record.line_count_03_10 = len(record.line_03_10_ids)
            record.line_count_03_11 = len(record.line_03_11_ids)
            record.line_count_03_12 = len(record.line_03_12_ids)
            record.line_count_03_13 = len(record.line_03_13_ids)
            record.line_count_03_14 = len(record.line_03_14_ids)
            record.line_count_03_15 = len(record.line_03_15_ids)
            record.line_count_03_16_1 = len(record.line_03_16_1_ids)
            record.line_count_03_17 = len(record.line_03_17_ids)
            record.line_count_03_18 = len(record.line_03_18_ids)
            record.line_count_03_19 = len(record.line_03_19_ids)
            record.line_count_03_20 = len(record.line_03_20_ids)
    
    @api.constrains('date_start', 'date_end')
    def _check_dates(self):
        for record in self:
            if record.date_start and record.date_end:
                if record.date_start > record.date_end:
                    raise ValidationError(_('La fecha de inicio no puede ser mayor a la fecha fin.'))
    
    @api.constrains('period')
    def _check_period_format(self):
        for record in self:
            if record.period and len(record.period) != 8:
                raise ValidationError(_('El periodo debe tener formato YYYYMMDD (8 dígitos).'))
            if record.period:
                try:
                    datetime.strptime(record.period, '%Y%m%d')
                except:
                    raise ValidationError(_('El periodo no tiene un formato de fecha válido YYYYMMDD.'))
    
    def action_generate(self):
        """Generar líneas de todos los subdocumentos"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError(_('Solo se pueden generar reportes en estado Borrador.'))

        # Generar todos los subdocumentos implementados
        self._generate_document_03_01()
        self._generate_document_03_02()
        self._generate_document_03_03()
        self._generate_document_03_04()
        self._generate_document_03_05()
        self._generate_document_03_06()
        self._generate_document_03_07()
        self._generate_document_03_08()
        self._generate_document_03_09()
        self._generate_document_03_10()
        self._generate_document_03_11()
        self._generate_document_03_12()
        self._generate_document_03_13()
        self._generate_document_03_14()
        self._generate_document_03_15()
        self._generate_document_03_16_1()
        self._generate_document_03_17()
        self._generate_document_03_18()
        self._generate_document_03_19()
        self._generate_document_03_20()

        self.write({
            'state': 'generated',
            'date_generated': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _('Todos los subdocumentos han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }
    
    def _generate_document_03_01(self):
        """Generar líneas para documento 3.1 - Estado de Situación Financiera"""
        self.ensure_one()
        
        # Limpiar líneas existentes
        self.line_03_01_ids.unlink()
        
        # Buscar cuentas contables con movimientos en el periodo
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
        ]
        
        move_lines = self.env['account.move.line'].search(domain)
        
        # Agrupar por cuenta
        accounts_data = {}
        for line in move_lines:
            account = line.account_id
            if account.id not in accounts_data:
                accounts_data[account.id] = {
                    'account': account,
                    'debit': 0.0,
                    'credit': 0.0,
                }
            accounts_data[account.id]['debit'] += line.debit
            accounts_data[account.id]['credit'] += line.credit
        
        # Crear líneas PLE
        sequence = 1
        for account_data in accounts_data.values():
            account = account_data['account']
            debit_balance = account_data['debit']
            credit_balance = account_data['credit']
            
            # Solo crear línea si hay movimientos
            if debit_balance != 0 or credit_balance != 0:
                self.env['ple.line.03.01'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'debit_balance': debit_balance,
                    'credit_balance': credit_balance,
                    'state_code': '1',  # 1 = Activo
                })
                sequence += 1
        
        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.1")
    
    def _generate_document_03_02(self):
        """Generar líneas para documento 3.2 - Detalle Cuenta 10 (Efectivo y Equivalentes)"""
        self.ensure_one()
        
        # Limpiar líneas existentes
        self.line_03_02_ids.unlink()
        
        # Buscar cuentas que empiezan con 10
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '10%'),
        ]
        
        move_lines = self.env['account.move.line'].search(domain)
        
        # Agrupar por cuenta y journal (banco/caja)
        accounts_journals = {}
        for line in move_lines:
            account = line.account_id
            journal = line.journal_id
            key = (account.id, journal.id if journal else False)
            
            if key not in accounts_journals:
                accounts_journals[key] = {
                    'account': account,
                    'journal': journal,
                    'balance': 0.0,
                }
            accounts_journals[key]['balance'] += line.debit - line.credit
        
        # Crear líneas PLE
        sequence = 1
        for data in accounts_journals.values():
            account = data['account']
            journal = data['journal']
            balance = data['balance']
            
            # Determinar código de entidad financiera y número de cuenta
            financial_code = ''
            account_number = ''
            currency_code = 'PEN'
            
            if journal:
                # Intentar obtener datos del banco
                if journal.bank_account_id:
                    account_number = journal.bank_account_id.acc_number or ''
                    # Aquí podrías mapear el banco a código SUNAT
                    if journal.bank_id:
                        # Mapeo de bancos principales (ejemplo)
                        bank_mapping = {
                            'BCP': '01',
                            'CONTINENTAL': '03',
                            'SCOTIABANK': '04',
                            'INTERBANK': '05',
                            'BBVA': '38',
                            'BANBIF': '07',
                            'BIF': '07',
                        }
                        bank_name = journal.bank_id.name.upper()
                        for key, code in bank_mapping.items():
                            if key in bank_name:
                                financial_code = code
                                break
                
                # Determinar moneda
                if journal.currency_id:
                    if journal.currency_id.name in ['PEN', 'USD', 'EUR']:
                        currency_code = journal.currency_id.name
            
            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.02'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'financial_entity_code': financial_code,
                    'currency_code': currency_code,
                    'account_number': account_number,
                    'final_balance': balance,
                    'journal_id': journal.id if journal else False,
                    'state_code': '1',
                })
                sequence += 1
        
        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.2")

    def _generate_document_03_03(self):
        """Generar líneas para documento 3.3 - Detalle Cuenta 12 (Cuentas por Cobrar Comerciales)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_03_ids.unlink()

        # Buscar cuentas que empiezan con 12
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '12%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        accounts_partners = {}
        for line in move_lines:
            account = line.account_id
            partner = line.partner_id
            key = (account.id, partner.id if partner else False)

            if key not in accounts_partners:
                accounts_partners[key] = {
                    'account': account,
                    'partner': partner,
                    'balance': 0.0,
                }
            accounts_partners[key]['balance'] += line.debit - line.credit

        # Crear líneas PLE
        sequence = 1
        for data in accounts_partners.values():
            account = data['account']
            partner = data['partner']
            balance = data['balance']

            # Determinar tipo y número de documento del cliente
            partner_document_type = '0'
            partner_vat = ''
            partner_name = ''

            if partner:
                partner_name = partner.name or ''
                if partner.vat:
                    partner_vat = partner.vat
                    # Determinar tipo de documento según longitud
                    vat_len = len(partner.vat)
                    if vat_len == 11:
                        partner_document_type = '6'  # RUC
                    elif vat_len == 8:
                        partner_document_type = '1'  # DNI
                    else:
                        partner_document_type = '0'  # Otros

            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.03'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'partner_id': partner.id if partner else False,
                    'partner_document_type': partner_document_type,
                    'partner_vat': partner_vat,
                    'partner_name': partner_name,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.3")

    def _generate_document_03_04(self):
        """Generar líneas para documento 3.4 - Detalle Cuenta 14 (Cuentas por Cobrar al Personal y Accionistas)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_04_ids.unlink()

        # Buscar cuentas que empiezan con 14
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '14%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        accounts_partners = {}
        for line in move_lines:
            account = line.account_id
            partner = line.partner_id
            key = (account.id, partner.id if partner else False)

            if key not in accounts_partners:
                accounts_partners[key] = {
                    'account': account,
                    'partner': partner,
                    'balance': 0.0,
                }
            accounts_partners[key]['balance'] += line.debit - line.credit

        # Crear líneas PLE
        sequence = 1
        for data in accounts_partners.values():
            account = data['account']
            partner = data['partner']
            balance = data['balance']

            # Determinar tipo y número de documento de la persona
            partner_document_type = '1'  # DNI por defecto
            partner_vat = ''
            partner_name = ''

            if partner:
                partner_name = partner.name or ''
                if partner.vat:
                    partner_vat = partner.vat
                    # Determinar tipo de documento según longitud
                    vat_len = len(partner.vat)
                    if vat_len == 11:
                        partner_document_type = '6'  # RUC
                    elif vat_len == 8:
                        partner_document_type = '1'  # DNI
                    else:
                        partner_document_type = '0'  # Otros

            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.04'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'partner_id': partner.id if partner else False,
                    'partner_document_type': partner_document_type,
                    'partner_vat': partner_vat,
                    'partner_name': partner_name,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.4")

    def _generate_document_03_05(self):
        """Generar líneas para documento 3.5 - Detalle Cuenta 16 (Cuentas por Cobrar Diversas - Terceros)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_05_ids.unlink()

        # Buscar cuentas que empiezan con 16
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '16%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        accounts_partners = {}
        for line in move_lines:
            account = line.account_id
            partner = line.partner_id
            key = (account.id, partner.id if partner else False)

            if key not in accounts_partners:
                accounts_partners[key] = {
                    'account': account,
                    'partner': partner,
                    'balance': 0.0,
                }
            accounts_partners[key]['balance'] += line.debit - line.credit

        # Crear líneas PLE
        sequence = 1
        for data in accounts_partners.values():
            account = data['account']
            partner = data['partner']
            balance = data['balance']

            # Determinar tipo y número de documento del tercero
            partner_document_type = '6'  # RUC por defecto
            partner_vat = ''
            partner_name = ''

            if partner:
                partner_name = partner.name or ''
                if partner.vat:
                    partner_vat = partner.vat
                    # Determinar tipo de documento según longitud
                    vat_len = len(partner.vat)
                    if vat_len == 11:
                        partner_document_type = '6'  # RUC
                    elif vat_len == 8:
                        partner_document_type = '1'  # DNI
                    else:
                        partner_document_type = '0'  # Otros

            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.05'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'partner_id': partner.id if partner else False,
                    'partner_document_type': partner_document_type,
                    'partner_vat': partner_vat,
                    'partner_name': partner_name,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.5")

    def _generate_document_03_06(self):
        """Generar líneas para documento 3.6 - Detalle Cuenta 19 (Estimación de Cuentas de Cobranza Dudosa)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_06_ids.unlink()

        # Buscar cuentas que empiezan con 19
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '19%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta
        accounts_data = {}
        for line in move_lines:
            account = line.account_id
            key = account.id

            if key not in accounts_data:
                accounts_data[key] = {
                    'account': account,
                    'balance': 0.0,
                }
            accounts_data[key]['balance'] += line.debit - line.credit

        # Crear líneas PLE
        sequence = 1
        for data in accounts_data.values():
            account = data['account']
            balance = data['balance']

            # Determinar cuenta relacionada (típicamente 12, 16, etc.)
            # La cuenta 19 es para provisiones de cobranza dudosa
            related_account_code = ''
            # Se puede determinar según la subcuenta, por ejemplo:
            # 191 -> Relacionada con cuenta 12
            # 193 -> Relacionada con cuenta 16
            if account.code.startswith('191'):
                related_account_code = '12'
            elif account.code.startswith('193'):
                related_account_code = '16'

            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.06'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'related_account_code': related_account_code,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.6")

    def _generate_document_03_07(self):
        """Generar líneas para documento 3.7 - Detalle Cuenta 20 (Mercaderías)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_07_ids.unlink()

        # Buscar cuentas que empiezan con 20
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '20%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y producto
        accounts_products = {}
        for line in move_lines:
            account = line.account_id
            product = line.product_id
            key = (account.id, product.id if product else False)

            if key not in accounts_products:
                accounts_products[key] = {
                    'account': account,
                    'product': product,
                    'balance': 0.0,
                    'quantity': 0.0,
                }
            accounts_products[key]['balance'] += line.debit - line.credit
            # La cantidad podría venir del campo quantity si existe
            if hasattr(line, 'quantity'):
                accounts_products[key]['quantity'] += line.quantity or 0.0

        # Crear líneas PLE
        sequence = 1
        for data in accounts_products.values():
            account = data['account']
            product = data['product']
            balance = data['balance']
            quantity = data['quantity']

            # Datos del producto
            product_code = ''
            product_name = ''
            product_uom = ''
            unit_cost = 0.0

            if product:
                product_code = product.default_code or ''
                product_name = product.name or ''
                product_uom = product.uom_id.name if product.uom_id else ''
                # Calcular costo unitario si hay cantidad
                if quantity != 0:
                    unit_cost = balance / quantity
                else:
                    unit_cost = product.standard_price or 0.0

            # Solo crear línea si hay saldo
            if balance != 0:
                self.env['ple.line.03.07'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'product_code': product_code,
                    'product_name': product_name,
                    'product_uom': product_uom,
                    'quantity': quantity,
                    'unit_cost': unit_cost,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.7")

    def _generate_document_03_08(self):
        """Generar líneas para documento 3.8 - Detalle Cuenta 21 (Productos Terminados)"""
        self.ensure_one()

        # Limpiar líneas existentes
        self.line_03_08_ids.unlink()

        # Buscar cuentas que empiezan con 21
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '21%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y producto
        accounts_products = {}
        for line in move_lines:
            account = line.account_id
            product = line.product_id
            key = (account.id, product.id if product else False)

            if key not in accounts_products:
                accounts_products[key] = {
                    'account': account,
                    'product': product,
                    'balance': 0.0,
                    'quantity': 0.0,
                }
            accounts_products[key]['balance'] += line.debit - line.credit
            if hasattr(line, 'quantity'):
                accounts_products[key]['quantity'] += line.quantity or 0.0

        # Crear líneas PLE
        sequence = 1
        for data in accounts_products.values():
            account = data['account']
            product = data['product']
            balance = data['balance']
            quantity = data['quantity']

            product_code = ''
            product_name = ''
            product_uom = ''
            unit_cost = 0.0

            if product:
                product_code = product.default_code or ''
                product_name = product.name or ''
                product_uom = product.uom_id.name if product.uom_id else ''
                if quantity != 0:
                    unit_cost = balance / quantity
                else:
                    unit_cost = product.standard_price or 0.0

            if balance != 0:
                self.env['ple.line.03.08'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'product_code': product_code,
                    'product_name': product_name,
                    'product_uom': product_uom,
                    'quantity': quantity,
                    'unit_cost': unit_cost,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.8")

    def _generate_document_03_09(self):
        """Generar líneas para documento 3.9 - Detalle Cuenta 22 (Subproductos, Desechos y Desperdicios)"""
        self.ensure_one()

        self.line_03_09_ids.unlink()

        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '22%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        accounts_products = {}
        for line in move_lines:
            account = line.account_id
            product = line.product_id
            key = (account.id, product.id if product else False)

            if key not in accounts_products:
                accounts_products[key] = {
                    'account': account,
                    'product': product,
                    'balance': 0.0,
                    'quantity': 0.0,
                }
            accounts_products[key]['balance'] += line.debit - line.credit
            if hasattr(line, 'quantity'):
                accounts_products[key]['quantity'] += line.quantity or 0.0

        sequence = 1
        for data in accounts_products.values():
            account = data['account']
            product = data['product']
            balance = data['balance']
            quantity = data['quantity']

            product_code = ''
            product_name = ''
            product_uom = ''
            unit_cost = 0.0

            if product:
                product_code = product.default_code or ''
                product_name = product.name or ''
                product_uom = product.uom_id.name if product.uom_id else ''
                if quantity != 0:
                    unit_cost = balance / quantity
                else:
                    unit_cost = product.standard_price or 0.0

            if balance != 0:
                self.env['ple.line.03.09'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'product_code': product_code,
                    'product_name': product_name,
                    'product_uom': product_uom,
                    'quantity': quantity,
                    'unit_cost': unit_cost,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.9")

    def _generate_document_03_10(self):
        """Generar líneas para documento 3.10 - Detalle Cuenta 23 (Productos en Proceso)"""
        self.ensure_one()

        self.line_03_10_ids.unlink()

        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '23%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        accounts_products = {}
        for line in move_lines:
            account = line.account_id
            product = line.product_id
            key = (account.id, product.id if product else False)

            if key not in accounts_products:
                accounts_products[key] = {
                    'account': account,
                    'product': product,
                    'balance': 0.0,
                    'quantity': 0.0,
                }
            accounts_products[key]['balance'] += line.debit - line.credit
            if hasattr(line, 'quantity'):
                accounts_products[key]['quantity'] += line.quantity or 0.0

        sequence = 1
        for data in accounts_products.values():
            account = data['account']
            product = data['product']
            balance = data['balance']
            quantity = data['quantity']

            product_code = ''
            product_name = ''
            product_uom = ''
            unit_cost = 0.0

            if product:
                product_code = product.default_code or ''
                product_name = product.name or ''
                product_uom = product.uom_id.name if product.uom_id else ''
                if quantity != 0:
                    unit_cost = balance / quantity
                else:
                    unit_cost = product.standard_price or 0.0

            if balance != 0:
                self.env['ple.line.03.10'].create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'account_id': account.id,
                    'account_code': account.code,
                    'account_name': account.name,
                    'product_code': product_code,
                    'product_name': product_name,
                    'product_uom': product_uom,
                    'quantity': quantity,
                    'unit_cost': unit_cost,
                    'final_balance': balance,
                    'state_code': '1',
                })
                sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.10")

    def action_publish(self):
        """Publicar y generar archivos TXT de todos los subdocumentos"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError(_('Solo se pueden publicar reportes en estado Generado.'))

        # Generar todos los archivos TXT
        self._generate_txt_03_01()
        self._generate_txt_03_02()
        self._generate_txt_03_03()
        self._generate_txt_03_04()
        self._generate_txt_03_05()
        self._generate_txt_03_06()
        self._generate_txt_03_07()
        self._generate_txt_03_08()
        self._generate_txt_03_09()
        self._generate_txt_03_10()
        self._generate_txt_03_11()
        self._generate_txt_03_12()
        self._generate_txt_03_13()
        self._generate_txt_03_14()
        self._generate_txt_03_15()
        self._generate_txt_03_16_1()
        self._generate_txt_03_17()
        self._generate_txt_03_18()
        self._generate_txt_03_19()
        self._generate_txt_03_20()

        self.write({
            'state': 'published'
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Todos los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }
    
    def _generate_txt_03_01(self):
        """Generar archivo TXT para documento 3.1"""
        self.ensure_one()
        
        if not self.line_03_01_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))
        
        vat = self.company_id.vat or '00000000000'
        
        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030100001111.txt"
        
        lines = []
        for line in self.line_03_01_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)
        
        content = '\r\n'.join(lines)
        
        self.write({
            'txt_filename_03_01': filename,
            'txt_file_03_01': base64.b64encode(content.encode('utf-8'))
        })
    
    def _generate_txt_03_02(self):
        """Generar archivo TXT para documento 3.2"""
        self.ensure_one()
        
        if not self.line_03_02_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))
        
        vat = self.company_id.vat or '00000000000'
        
        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030200001111.txt"
        
        lines = []
        for line in self.line_03_02_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)
        
        content = '\r\n'.join(lines)
        
        self.write({
            'txt_filename_03_02': filename,
            'txt_file_03_02': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_03(self):
        """Generar archivo TXT para documento 3.3"""
        self.ensure_one()

        if not self.line_03_03_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'

        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030300001111.txt"

        lines = []
        for line in self.line_03_03_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_03': filename,
            'txt_file_03_03': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_04(self):
        """Generar archivo TXT para documento 3.4"""
        self.ensure_one()

        if not self.line_03_04_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'

        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030400001111.txt"

        lines = []
        for line in self.line_03_04_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_04': filename,
            'txt_file_03_04': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_05(self):
        """Generar archivo TXT para documento 3.5"""
        self.ensure_one()

        if not self.line_03_05_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'

        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030500001111.txt"

        lines = []
        for line in self.line_03_05_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_05': filename,
            'txt_file_03_05': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_06(self):
        """Generar archivo TXT para documento 3.6"""
        self.ensure_one()

        if not self.line_03_06_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'

        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030600001111.txt"

        lines = []
        for line in self.line_03_06_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_06': filename,
            'txt_file_03_06': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_07(self):
        """Generar archivo TXT para documento 3.7"""
        self.ensure_one()

        if not self.line_03_07_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'

        # Nombre del archivo según formato SUNAT
        # LE + RUC + AÑO + MES + DIA + LIBRO + 00 + 1 + 1 + 1 + 1 + .txt
        filename = f"LE{vat}{self.year}{self.period}030700001111.txt"

        lines = []
        for line in self.line_03_07_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_07': filename,
            'txt_file_03_07': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_08(self):
        """Generar archivo TXT para documento 3.8"""
        self.ensure_one()

        if not self.line_03_08_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}030800001111.txt"

        lines = []
        for line in self.line_03_08_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_08': filename,
            'txt_file_03_08': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_09(self):
        """Generar archivo TXT para documento 3.9"""
        self.ensure_one()

        if not self.line_03_09_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}030900001111.txt"

        lines = []
        for line in self.line_03_09_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_09': filename,
            'txt_file_03_09': base64.b64encode(content.encode('utf-8'))
        })

    def _generate_txt_03_10(self):
        """Generar archivo TXT para documento 3.10"""
        self.ensure_one()

        if not self.line_03_10_ids:
            raise UserError(_('No hay líneas para generar el archivo TXT.'))

        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031000001111.txt"

        lines = []
        for line in self.line_03_10_ids.sorted('sequence'):
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        content = '\r\n'.join(lines)

        self.write({
            'txt_filename_03_10': filename,
            'txt_file_03_10': base64.b64encode(content.encode('utf-8'))
        })

    def action_back_to_draft(self):
        """Volver a borrador"""
        self.ensure_one()
        self.write({'state': 'draft'})
    
    def action_view_lines_03_01(self):
        """Ver líneas del documento 3.1"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.1 - Estado de Situación Financiera'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.01',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }
    
    def action_view_lines_03_02(self):
        """Ver líneas del documento 3.2"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.2 - Detalle Cuenta 10'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.02',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_03(self):
        """Ver líneas del documento 3.3"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.3 - Detalle Cuenta 12'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.03',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_04(self):
        """Ver líneas del documento 3.4"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.4 - Detalle Cuenta 14'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.04',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_05(self):
        """Ver líneas del documento 3.5"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.5 - Detalle Cuenta 16'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.05',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_06(self):
        """Ver líneas del documento 3.6"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.6 - Detalle Cuenta 19'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.06',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_07(self):
        """Ver líneas del documento 3.7"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.7 - Detalle Cuenta 20'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.07',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_08(self):
        """Ver líneas del documento 3.8"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.8 - Detalle Cuenta 21'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.08',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_09(self):
        """Ver líneas del documento 3.9"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.9 - Detalle Cuenta 22'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.09',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_10(self):
        """Ver líneas del documento 3.10"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.10 - Detalle Cuenta 23'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.10',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_11(self):
        """Ver líneas del documento 3.11"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.11 - Detalle Cuenta 41'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.11',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_12(self):
        """Ver líneas del documento 3.12"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.12 - Detalle Cuenta 42-43'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.12',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_13(self):
        """Ver líneas del documento 3.13"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.13 - Detalle Cuenta 46'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.13',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_14(self):
        """Ver líneas del documento 3.14"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.14 - Detalle Cuenta 47'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.14',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_15(self):
        """Ver líneas del documento 3.15"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.15 - Detalle Cuenta 49'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.15',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_16_1(self):
        """Ver líneas del documento 3.16.1"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.16.1 - Detalle Cuenta 50'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.16.1',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_17(self):
        """Ver líneas del documento 3.17"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.17 - Detalle Cuenta 34'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.17',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_18(self):
        """Ver líneas del documento 3.18"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.18 - Estado Flujos Efectivo'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.18',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_19(self):
        """Ver líneas del documento 3.19"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.19 - Estado Cambios Patrimonio'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.19',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_03_20(self):
        """Ver líneas del documento 3.20"""
        self.ensure_one()
        return {
            'name': _('Líneas 3.20 - Estado Ganancias Pérdidas'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.03.20',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def _generate_document_03_11(self):
        """Generar líneas para documento 3.11 - Detalle Cuenta 41 (Remuneraciones y Participaciones por Pagar)"""
        self.ensure_one()
        self.line_03_11_ids.unlink()

        # Buscar movimientos en cuenta 41
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '41%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        partners = {}
        for line in move_lines:
            if not line.partner_id:
                continue

            key = (line.account_id.id, line.partner_id.id)
            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (por pagar)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            self.env['ple.line.03.11'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'partner_id': data['partner'].id,
                'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '1',
                'partner_vat': data['partner'].vat or '',
                'partner_name': data['partner'].name,
                'final_balance': data['balance'],
            })
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.11")

    def _generate_document_03_12(self):
        """Generar líneas para documento 3.12 - Detalle Cuenta 42-43 (Cuentas por Pagar Comerciales)"""
        self.ensure_one()
        self.line_03_12_ids.unlink()

        # Buscar movimientos en cuentas 42 y 43
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            '|',
            ('account_id.code', '=like', '42%'),
            ('account_id.code', '=like', '43%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        partners = {}
        for line in move_lines:
            if not line.partner_id:
                continue

            key = (line.account_id.id, line.partner_id.id)
            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (por pagar)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            self.env['ple.line.03.12'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'partner_id': data['partner'].id,
                'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '6',
                'partner_vat': data['partner'].vat or '',
                'partner_name': data['partner'].name,
                'final_balance': data['balance'],
            })
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.12")

    def _generate_document_03_13(self):
        """Generar líneas para documento 3.13 - Detalle Cuenta 46 (Cuentas por Pagar Diversas - Terceros)"""
        self.ensure_one()
        self.line_03_13_ids.unlink()

        # Buscar movimientos en cuenta 46
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '46%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        partners = {}
        for line in move_lines:
            if not line.partner_id:
                continue

            key = (line.account_id.id, line.partner_id.id)
            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (por pagar)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            self.env['ple.line.03.13'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'partner_id': data['partner'].id,
                'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '6',
                'partner_vat': data['partner'].vat or '',
                'partner_name': data['partner'].name,
                'final_balance': data['balance'],
            })
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.13")

    def _generate_document_03_14(self):
        """Generar líneas para documento 3.14 - Detalle Cuenta 47 (Cuentas por Pagar Diversas - Relacionadas)"""
        self.ensure_one()
        self.line_03_14_ids.unlink()

        # Buscar movimientos en cuenta 47
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '47%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        partners = {}
        for line in move_lines:
            if not line.partner_id:
                continue

            key = (line.account_id.id, line.partner_id.id)
            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (por pagar)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            self.env['ple.line.03.14'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'partner_id': data['partner'].id,
                'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '6',
                'partner_vat': data['partner'].vat or '',
                'partner_name': data['partner'].name,
                'final_balance': data['balance'],
            })
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.14")

    def _generate_document_03_15(self):
        """Generar líneas para documento 3.15 - Detalle Cuenta 49 (Pasivo Diferido)"""
        self.ensure_one()
        self.line_03_15_ids.unlink()

        # Buscar movimientos en cuenta 49
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '49%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner (puede ser sin partner para pasivos diferidos)
        partners = {}
        for line in move_lines:
            # Para cuenta 49 puede no tener partner
            partner_id = line.partner_id.id if line.partner_id else False
            key = (line.account_id.id, partner_id)

            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id if line.partner_id else False,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (pasivo)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            vals = {
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'final_balance': data['balance'],
            }

            # Agregar datos del partner si existe
            if data['partner']:
                vals.update({
                    'partner_id': data['partner'].id,
                    'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '0',
                    'partner_vat': data['partner'].vat or '',
                    'partner_name': data['partner'].name,
                })

            self.env['ple.line.03.15'].create(vals)
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.15")

    def _generate_txt_03_11(self):
        """Generar archivo TXT para documento 3.11"""
        self.ensure_one()

        if not self.line_03_11_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.11")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031100001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031100001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_11_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_11': filename,
            'txt_file_03_11': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.11 generado: {filename}")

    def _generate_txt_03_12(self):
        """Generar archivo TXT para documento 3.12"""
        self.ensure_one()

        if not self.line_03_12_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.12")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031200001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031200001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_12_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_12': filename,
            'txt_file_03_12': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.12 generado: {filename}")

    def _generate_txt_03_13(self):
        """Generar archivo TXT para documento 3.13"""
        self.ensure_one()

        if not self.line_03_13_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.13")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031300001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031300001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_13_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_13': filename,
            'txt_file_03_13': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.13 generado: {filename}")

    def _generate_txt_03_14(self):
        """Generar archivo TXT para documento 3.14"""
        self.ensure_one()

        if not self.line_03_14_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.14")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031400001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031400001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_14_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_14': filename,
            'txt_file_03_14': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.14 generado: {filename}")

    def _generate_txt_03_15(self):
        """Generar archivo TXT para documento 3.15"""
        self.ensure_one()

        if not self.line_03_15_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.15")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031500001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031500001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_15_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_15': filename,
            'txt_file_03_15': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.15 generado: {filename}")

    def _generate_document_03_16_1(self):
        """Generar líneas para documento 3.16.1 - Detalle Cuenta 50 (Capital)"""
        self.ensure_one()
        self.line_03_16_1_ids.unlink()

        # Buscar movimientos en cuenta 50
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '50%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta y partner
        partners = {}
        for line in move_lines:
            # Para cuenta 50 puede no tener partner (capital sin asignar)
            partner_id = line.partner_id.id if line.partner_id else False
            key = (line.account_id.id, partner_id)

            if key not in partners:
                partners[key] = {
                    'account': line.account_id,
                    'partner': line.partner_id if line.partner_id else False,
                    'balance': 0.0,
                }
            partners[key]['balance'] += line.credit - line.debit

        # Crear líneas solo con saldo acreedor (capital)
        sequence = 1
        for (acc_id, partner_id), data in partners.items():
            if data['balance'] <= 0:
                continue

            vals = {
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'final_balance': data['balance'],
                'share_type': '01',  # Por defecto acciones
                'share_quantity': 0,
                'nominal_value': 0.0,
            }

            # Agregar datos del partner si existe
            if data['partner']:
                vals.update({
                    'partner_id': data['partner'].id,
                    'partner_document_type': data['partner'].l10n_latam_identification_type_id.l10n_pe_vat_code if data['partner'].l10n_latam_identification_type_id else '6',
                    'partner_vat': data['partner'].vat or '',
                    'partner_name': data['partner'].name,
                })

            self.env['ple.line.03.16.1'].create(vals)
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.16.1")

    def _generate_txt_03_16_1(self):
        """Generar archivo TXT para documento 3.16.1"""
        self.ensure_one()

        if not self.line_03_16_1_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.16.1")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031601001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031601001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_16_1_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_16_1': filename,
            'txt_file_03_16_1': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.16.1 generado: {filename}")

    def _generate_document_03_17(self):
        """Generar líneas para documento 3.17 - Detalle Cuenta 34 (Intangibles)"""
        self.ensure_one()
        self.line_03_17_ids.unlink()

        # Buscar movimientos en cuenta 34
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_start),
            ('date', '<=', self.date_end),
            ('parent_state', '=', 'posted'),
            ('account_id.code', '=like', '34%'),
        ]

        move_lines = self.env['account.move.line'].search(domain)

        # Agrupar por cuenta
        accounts = {}
        for line in move_lines:
            key = line.account_id.id
            if key not in accounts:
                accounts[key] = {
                    'account': line.account_id,
                    'debit': 0.0,
                    'credit': 0.0,
                }
            accounts[key]['debit'] += line.debit
            accounts[key]['credit'] += line.credit

        # Crear líneas con saldo deudor (activos intangibles)
        sequence = 1
        for acc_id, data in accounts.items():
            balance = data['debit'] - data['credit']
            if balance <= 0:
                continue

            # Por defecto, asumimos que el saldo deudor es el costo de adquisición
            # La amortización acumulada debería estar en cuentas 39x
            self.env['ple.line.03.17'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'account_id': data['account'].id,
                'account_code': data['account'].code,
                'account_name': data['account'].name,
                'intangible_code': data['account'].code,
                'intangible_description': data['account'].name,
                'acquisition_cost': balance,
                'accumulated_amortization': 0.0,
            })
            sequence += 1

        _logger.info(f"Generadas {sequence - 1} líneas para documento 3.17")

    def _generate_txt_03_17(self):
        """Generar archivo TXT para documento 3.17"""
        self.ensure_one()

        if not self.line_03_17_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.17")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031700001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031700001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_17_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_17': filename,
            'txt_file_03_17': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.17 generado: {filename}")

    def _generate_document_03_18(self):
        """Generar estructura para documento 3.18 - Estado de Flujos de Efectivo"""
        self.ensure_one()
        self.line_03_18_ids.unlink()

        # Generar estructura básica del Estado de Flujos de Efectivo
        # El usuario podrá completar/modificar estas líneas manualmente

        structure = [
            # Actividades de Operación
            ('101', 'Cobro de ventas de bienes o servicios', 'operating'),
            ('102', 'Cobro de regalías, honorarios, comisiones', 'operating'),
            ('103', 'Cobro de intereses y rendimientos', 'operating'),
            ('104', 'Otros cobros de efectivo relativos a la actividad', 'operating'),
            ('151', 'Pago a proveedores de bienes y servicios', 'operating'),
            ('152', 'Pago de remuneraciones y beneficios sociales', 'operating'),
            ('153', 'Pago de tributos', 'operating'),
            ('154', 'Pago de intereses y rendimientos', 'operating'),
            ('155', 'Otros pagos de efectivo relativos a la actividad', 'operating'),
            ('199', 'Aumento (disminución) del efectivo - Actividades de Operación', 'operating'),

            # Actividades de Inversión
            ('201', 'Venta de inmuebles, maquinaria y equipo', 'investing'),
            ('202', 'Venta de activos intangibles', 'investing'),
            ('203', 'Venta de inversiones mobiliarias e inmobiliarias', 'investing'),
            ('204', 'Otros cobros de efectivo relativos a la actividad', 'investing'),
            ('251', 'Compra de inmuebles, maquinaria y equipo', 'investing'),
            ('252', 'Compra de activos intangibles', 'investing'),
            ('253', 'Compra de inversiones mobiliarias e inmobiliarias', 'investing'),
            ('254', 'Otros pagos de efectivo relativos a la actividad', 'investing'),
            ('299', 'Aumento (disminución) del efectivo - Actividades de Inversión', 'investing'),

            # Actividades de Financiamiento
            ('301', 'Emisión de acciones o nuevos aportes', 'financing'),
            ('302', 'Obtención de préstamos', 'financing'),
            ('303', 'Otros cobros de efectivo relativos a la actividad', 'financing'),
            ('351', 'Amortización o pago de préstamos', 'financing'),
            ('352', 'Pago de dividendos y otras distribuciones', 'financing'),
            ('353', 'Otros pagos de efectivo relativos a la actividad', 'financing'),
            ('399', 'Aumento (disminución) del efectivo - Actividades de Financiamiento', 'financing'),

            # Resumen
            ('901', 'Aumento (disminución) neto de efectivo', 'summary'),
            ('902', 'Saldo efectivo y equivalente al inicio del ejercicio', 'summary'),
            ('903', 'Saldo efectivo y equivalente al final del ejercicio', 'summary'),
        ]

        sequence = 1
        for item_code, description, category in structure:
            self.env['ple.line.03.18'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'item_code': item_code,
                'item_description': description,
                'category': category,
                'amount': 0.0,
                'state_code': '1',
            })
            sequence += 1

        _logger.info(f"Documento 3.18 generado con {len(structure)} líneas de estructura")

    def _generate_txt_03_18(self):
        """Generar archivo TXT para documento 3.18"""
        self.ensure_one()

        if not self.line_03_18_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.18")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031800001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031800001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_18_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_18': filename,
            'txt_file_03_18': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.18 generado: {filename}")

    def _generate_document_03_19(self):
        """Generar estructura para documento 3.19 - Estado de Cambios en el Patrimonio Neto"""
        self.ensure_one()
        self.line_03_19_ids.unlink()

        # Generar estructura básica del Estado de Cambios en el Patrimonio
        # El usuario podrá completar/modificar estas líneas manualmente

        structure = [
            # Saldos iniciales
            ('101', 'Saldos al 1ro de enero'),

            # Cambios en el patrimonio
            ('201', 'Aportes de capital'),
            ('202', 'Capitalización de utilidades'),
            ('203', 'Capitalización de reservas'),
            ('204', 'Reducción de capital'),
            ('205', 'Adquisición de acciones propias'),

            # Utilidades
            ('301', 'Utilidades del ejercicio'),
            ('302', 'Pérdidas del ejercicio'),
            ('303', 'Distribución de dividendos'),

            # Reservas
            ('401', 'Reserva legal'),
            ('402', 'Otras reservas'),

            # Ajustes
            ('501', 'Ajustes por corrección de errores'),
            ('502', 'Excedente de revaluación'),
            ('503', 'Diferencias de cambio'),

            # Saldos finales
            ('901', 'Saldos al 31 de diciembre'),
        ]

        sequence = 1
        for item_code, description in structure:
            self.env['ple.line.03.19'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'item_code': item_code,
                'item_description': description,
                'capital': 0.0,
                'capital_adicional': 0.0,
                'acciones_inversion': 0.0,
                'excedente_revaluacion': 0.0,
                'reservas_legal': 0.0,
                'otras_reservas': 0.0,
                'resultados_acumulados': 0.0,
                'state_code': '1',
            })
            sequence += 1

        _logger.info(f"Documento 3.19 generado con {len(structure)} líneas de estructura")

    def _generate_txt_03_19(self):
        """Generar archivo TXT para documento 3.19"""
        self.ensure_one()

        if not self.line_03_19_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.19")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}031900001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}031900001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_19_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_19': filename,
            'txt_file_03_19': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.19 generado: {filename}")

    def _generate_document_03_20(self):
        """Generar estructura para documento 3.20 - Estado de Ganancias y Pérdidas por Función"""
        self.ensure_one()
        self.line_03_20_ids.unlink()

        # Generar estructura básica del Estado de Ganancias y Pérdidas
        # El usuario podrá completar/modificar estas líneas manualmente

        structure = [
            # Ingresos
            ('101', 'Ventas netas (ingresos operacionales)', 'income'),
            ('102', 'Otros ingresos operacionales', 'income'),
            ('103', 'Total de ingresos brutos', 'income'),

            # Costos
            ('201', 'Costo de ventas (operacionales)', 'cost'),
            ('202', 'Otros costos operacionales', 'cost'),
            ('203', 'Total costos operacionales', 'cost'),
            ('210', 'Utilidad bruta', 'result'),

            # Gastos operativos
            ('301', 'Gastos de administración', 'expense'),
            ('302', 'Gastos de ventas', 'expense'),
            ('303', 'Ganancia (Pérdida) por venta de activos', 'expense'),
            ('304', 'Otros ingresos', 'expense'),
            ('305', 'Otros gastos', 'expense'),
            ('310', 'Utilidad operativa', 'result'),

            # Ingresos y gastos financieros
            ('401', 'Ingresos financieros', 'other'),
            ('402', 'Gastos financieros', 'other'),
            ('403', 'Participación en los resultados de partes relacionadas', 'other'),
            ('410', 'Resultado antes de impuesto a las ganancias', 'result'),

            # Impuesto a la renta
            ('501', 'Gasto por impuesto a las ganancias', 'expense'),

            # Resultado final
            ('901', 'Ganancia (Pérdida) neta del ejercicio', 'result'),
        ]

        sequence = 1
        for item_code, description, category in structure:
            self.env['ple.line.03.20'].create({
                'report_id': self.id,
                'sequence': sequence * 10,
                'item_code': item_code,
                'item_description': description,
                'category': category,
                'amount': 0.0,
                'state_code': '1',
            })
            sequence += 1

        _logger.info(f"Documento 3.20 generado con {len(structure)} líneas de estructura")

    def _generate_txt_03_20(self):
        """Generar archivo TXT para documento 3.20"""
        self.ensure_one()

        if not self.line_03_20_ids:
            _logger.warning("No hay líneas para generar el archivo TXT 3.20")
            return

        # Nombre del archivo: LERUC{RUC}{PERIODO}032000001111.txt
        vat = self.company_id.vat or '00000000000'
        filename = f"LE{vat}{self.year}{self.period}032000001111.txt"

        # Generar contenido
        lines = []
        for line in self.line_03_20_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.write({
            'txt_filename_03_20': filename,
            'txt_file_03_20': base64.b64encode(content.encode('utf-8'))
        })

        _logger.info(f"Archivo TXT 3.20 generado: {filename}")