from odoo import api, fields, models, _


class PleLine0319(models.Model):
    _name = 'ple.line.03.19'
    _description = 'PLE 3.19 - Estado de Cambios en el Patrimonio Neto'
    _order = 'sequence, item_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 3.19
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )

    item_code = fields.Char(
        string='Código de Rubro',
        required=True,
        help='Código interno del rubro patrimonial'
    )

    item_description = fields.Char(
        string='Descripción del Rubro',
        required=True,
        help='Descripción del rubro del patrimonio'
    )

    # Columnas del Estado de Cambios en el Patrimonio
    capital = fields.Monetary(
        string='Capital',
        currency_field='company_currency_id',
        default=0.0,
        help='Capital Social'
    )

    capital_adicional = fields.Monetary(
        string='Capital Adicional',
        currency_field='company_currency_id',
        default=0.0,
        help='Primas de emisión y otros aportes'
    )

    acciones_inversion = fields.Monetary(
        string='Acciones de Inversión',
        currency_field='company_currency_id',
        default=0.0,
        help='Acciones de inversión (si aplica)'
    )

    excedente_revaluacion = fields.Monetary(
        string='Excedente de Revaluación',
        currency_field='company_currency_id',
        default=0.0,
        help='Excedente de revaluación'
    )

    reservas_legal = fields.Monetary(
        string='Reserva Legal',
        currency_field='company_currency_id',
        default=0.0,
        help='Reserva legal'
    )

    otras_reservas = fields.Monetary(
        string='Otras Reservas',
        currency_field='company_currency_id',
        default=0.0,
        help='Otras reservas'
    )

    resultados_acumulados = fields.Monetary(
        string='Resultados Acumulados',
        currency_field='company_currency_id',
        default=0.0,
        help='Resultados acumulados'
    )

    total = fields.Monetary(
        string='Total Patrimonio',
        currency_field='company_currency_id',
        compute='_compute_total',
        store=True,
        help='Total del patrimonio (suma de todos los rubros)'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.depends('capital', 'capital_adicional', 'acciones_inversion', 'excedente_revaluacion',
                 'reservas_legal', 'otras_reservas', 'resultados_acumulados')
    def _compute_total(self):
        for line in self:
            line.total = (line.capital + line.capital_adicional + line.acciones_inversion +
                         line.excedente_revaluacion + line.reservas_legal +
                         line.otras_reservas + line.resultados_acumulados)

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.19

        Estructura:
        1. Periodo (8)
        2. Código del Rubro (10)
        3. Descripción del Rubro (200)
        4. Capital (decimal 12.2)
        5. Capital Adicional (decimal 12.2)
        6. Acciones de Inversión (decimal 12.2)
        7. Excedente de Revaluación (decimal 12.2)
        8. Reserva Legal (decimal 12.2)
        9. Otras Reservas (decimal 12.2)
        10. Resultados Acumulados (decimal 12.2)
        11. Total (decimal 12.2)
        12. Indicador Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear valores numéricos
        capital_str = f"{self.capital:.2f}" if self.capital else "0.00"
        capital_adic_str = f"{self.capital_adicional:.2f}" if self.capital_adicional else "0.00"
        acciones_str = f"{self.acciones_inversion:.2f}" if self.acciones_inversion else "0.00"
        excedente_str = f"{self.excedente_revaluacion:.2f}" if self.excedente_revaluacion else "0.00"
        reserva_legal_str = f"{self.reservas_legal:.2f}" if self.reservas_legal else "0.00"
        otras_reservas_str = f"{self.otras_reservas:.2f}" if self.otras_reservas else "0.00"
        resultados_str = f"{self.resultados_acumulados:.2f}" if self.resultados_acumulados else "0.00"
        total_str = f"{self.total:.2f}" if self.total else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                    # 1. Periodo
            self.item_code or '',                 # 2. Código Rubro
            self.item_description or '',          # 3. Descripción
            capital_str,                          # 4. Capital
            capital_adic_str,                     # 5. Capital Adicional
            acciones_str,                         # 6. Acciones Inversión
            excedente_str,                        # 7. Excedente Revaluación
            reserva_legal_str,                    # 8. Reserva Legal
            otras_reservas_str,                   # 9. Otras Reservas
            resultados_str,                       # 10. Resultados Acumulados
            total_str,                            # 11. Total
            self.state_code or '1',               # 12. Estado
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.item_code}] {line.item_description}"
            if line.total:
                name += f" - {line.company_currency_id.symbol} {line.total:,.2f}"
            result.append((line.id, name))
        return result
