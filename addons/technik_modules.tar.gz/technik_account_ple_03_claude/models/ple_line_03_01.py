from odoo import api, fields, models, _


class PleLine0301(models.Model):
    _name = 'ple.line.03.01'
    _description = 'PLE 3.1 - Líneas Estado de Situación Financiera'
    _order = 'sequence, account_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )
    
    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )
    
    # Campos según formato SUNAT para 3.1
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )
    
    account_plan_code = fields.Char(
        string='Código Plan de Cuentas',
        default='01',
        help='01 = Plan Contable General Empresarial'
    )
    
    account_id = fields.Many2one(
        'account.account',
        string='Cuenta Contable',
        required=True,
        domain="[('company_ids', 'in', company_id)]"
    )
    
    account_code = fields.Char(
        string='Código Cuenta',
        required=True,
        help='Código de la cuenta contable'
    )
    
    account_name = fields.Char(
        string='Descripción Cuenta',
        required=True,
        help='Descripción de la cuenta contable'
    )
    
    account_plan_mayor_code = fields.Char(
        string='Código Plan Mayor',
        compute='_compute_account_plan_mayor',
        store=True,
        help='Código del plan de cuentas del mayor'
    )
    
    debit_balance = fields.Monetary(
        string='Saldo Deudor',
        currency_field='company_currency_id',
        default=0.0
    )
    
    credit_balance = fields.Monetary(
        string='Saldo Acreedor',
        currency_field='company_currency_id',
        default=0.0
    )
    
    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)
    
    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )
    
    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )
    
    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )
    
    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False
    
    @api.depends('account_code')
    def _compute_account_plan_mayor(self):
        """Calcular código del plan mayor (primeros 2 dígitos)"""
        for line in self:
            if line.account_code and len(line.account_code) >= 2:
                line.account_plan_mayor_code = line.account_code[:2]
            else:
                line.account_plan_mayor_code = ''
    
    @api.onchange('account_id')
    def _onchange_account_id(self):
        """Auto-completar código y nombre cuando se selecciona cuenta"""
        if self.account_id:
            self.account_code = self.account_id.code
            self.account_name = self.account_id.name
    
    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.1
        
        Estructura:
        1. Periodo (8)
        2. Código Plan de Cuentas (2)
        3. Código Cuenta Contable (24)
        4. Descripción Cuenta (100)
        5. Código Plan Mayor (3)
        6. Saldo Deudor (decimal 12.2)
        7. Saldo Acreedor (decimal 12.2)
        8. Indicador Estado (1)
        
        Separador: |
        """
        self.ensure_one()
        
        # Formatear montos (sin comas, punto decimal)
        debit = f"{self.debit_balance:.2f}" if self.debit_balance else "0.00"
        credit = f"{self.credit_balance:.2f}" if self.credit_balance else "0.00"
        
        # Construir línea
        line_parts = [
            self.period or '',                              # 1. Periodo
            self.account_plan_code or '01',                # 2. Código Plan
            self.account_code or '',                       # 3. Código Cuenta
            self.account_name or '',                       # 4. Descripción
            self.account_plan_mayor_code or '',            # 5. Código Mayor
            debit,                                         # 6. Saldo Deudor
            credit,                                        # 7. Saldo Acreedor
            self.state_code or '1',                        # 8. Estado
        ]
        
        return '|'.join(line_parts) + '|'
    
    @api.model_create_multi
    def create(self, vals_list):
        """Auto-completar campos al crear"""
        for vals in vals_list:
            if 'account_id' in vals and vals['account_id']:
                account = self.env['account.account'].browse(vals['account_id'])
                if not vals.get('account_code'):
                    vals['account_code'] = account.code
                if not vals.get('account_name'):
                    vals['account_name'] = account.name
        return super().create(vals_list)
    
    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code}] {line.account_name}"
            result.append((line.id, name))
        return result
