from odoo import api, fields, models, _


class PleLine0320(models.Model):
    _name = 'ple.line.03.20'
    _description = 'PLE 3.20 - Estado de Ganancias y Pérdidas por Función'
    _order = 'sequence, item_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 3.20
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )

    item_code = fields.Char(
        string='Código de Rubro',
        required=True,
        help='Código interno del rubro del estado de resultados'
    )

    item_description = fields.Char(
        string='Descripción del Rubro',
        required=True,
        help='Descripción del rubro del estado de resultados'
    )

    category = fields.Selection([
        ('income', 'Ingresos'),
        ('cost', 'Costos'),
        ('expense', 'Gastos'),
        ('other', 'Otros Ingresos/Gastos'),
        ('result', 'Resultado'),
    ], string='Categoría', required=True, default='income')

    amount = fields.Monetary(
        string='Importe',
        currency_field='company_currency_id',
        default=0.0,
        help='Monto del rubro (positivo para ingresos, negativo para egresos)'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.20

        Estructura:
        1. Periodo (8)
        2. Código del Rubro (10)
        3. Descripción del Rubro (200)
        4. Importe (decimal 12.2)
        5. Indicador Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear valor numérico
        amount_str = f"{self.amount:.2f}" if self.amount else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                    # 1. Periodo
            self.item_code or '',                 # 2. Código Rubro
            self.item_description or '',          # 3. Descripción
            amount_str,                           # 4. Importe
            self.state_code or '1',               # 5. Estado
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.item_code}] {line.item_description}"
            if line.amount:
                name += f" - {line.company_currency_id.symbol} {line.amount:,.2f}"
            result.append((line.id, name))
        return result
