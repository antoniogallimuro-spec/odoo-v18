from odoo import api, fields, models, _


class PleLine0315(models.Model):
    _name = 'ple.line.03.15'
    _description = 'PLE 3.15 - Detalle del Saldo de la Cuenta 49 - Pasivo Diferido'
    _order = 'sequence, account_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 3.15
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )

    account_plan_code = fields.Char(
        string='Código Plan de Cuentas',
        default='01',
        help='01 = Plan Contable General Empresarial'
    )

    account_id = fields.Many2one(
        'account.account',
        string='Cuenta Contable',
        required=True,
        domain="[('company_ids', 'in', company_id), ('code', '=like', '49%')]"
    )

    account_code = fields.Char(
        string='Código Cuenta',
        required=True,
        help='Código de la cuenta contable (debe empezar con 49)'
    )

    account_name = fields.Char(
        string='Descripción Cuenta',
        required=True,
        help='Descripción de la cuenta contable'
    )

    partner_id = fields.Many2one(
        'res.partner',
        string='Tercero',
        help='Tercero relacionado (si aplica)'
    )

    partner_document_type = fields.Selection([
        ('0', '0 - Otros'),
        ('1', '1 - DNI'),
        ('4', '4 - Carnet de Extranjería'),
        ('6', '6 - RUC'),
        ('7', '7 - Pasaporte'),
        ('A', 'A - Cédula Diplomática'),
    ], string='Tipo Documento', default='0')

    partner_vat = fields.Char(
        string='Número de Documento',
        help='RUC o documento del tercero (si aplica)'
    )

    partner_name = fields.Char(
        string='Apellidos y Nombres / Razón Social',
        help='Apellidos y nombres o razón social del tercero (si aplica)'
    )

    final_balance = fields.Monetary(
        string='Saldo Final',
        currency_field='company_currency_id',
        default=0.0,
        help='Saldo de pasivo diferido al cierre'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.onchange('account_id')
    def _onchange_account_id(self):
        """Auto-completar código y nombre cuando se selecciona cuenta"""
        if self.account_id:
            self.account_code = self.account_id.code
            self.account_name = self.account_id.name

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        """Auto-completar datos del partner"""
        if self.partner_id:
            self.partner_vat = self.partner_id.vat or ''
            self.partner_name = self.partner_id.name
            if self.partner_id.l10n_latam_identification_type_id:
                self.partner_document_type = self.partner_id.l10n_latam_identification_type_id.l10n_pe_vat_code or '0'

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.15

        Estructura:
        1. Periodo (8)
        2. Código Plan de Cuentas (2)
        3. Código Cuenta Contable (24)
        4. Descripción Cuenta (100)
        5. Tipo Documento Identidad (1)
        6. Número Documento (15)
        7. Apellidos y Nombres / Razón Social (100)
        8. Saldo Final (decimal 12.2)
        9. Indicador Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear valores numéricos
        balance_str = f"{self.final_balance:.2f}" if self.final_balance else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                              # 1. Periodo
            self.account_plan_code or '01',                # 2. Código Plan
            self.account_code or '',                       # 3. Código Cuenta
            self.account_name or '',                       # 4. Descripción
            self.partner_document_type or '0',             # 5. Tipo Doc
            self.partner_vat or '',                        # 6. Nro Documento
            self.partner_name or '',                       # 7. Razón Social
            balance_str,                                   # 8. Saldo Final
            self.state_code or '1',                        # 9. Estado
        ]

        return '|'.join(line_parts) + '|'

    @api.model_create_multi
    def create(self, vals_list):
        """Auto-completar campos al crear"""
        for vals in vals_list:
            if 'account_id' in vals and vals['account_id']:
                account = self.env['account.account'].browse(vals['account_id'])
                if not vals.get('account_code'):
                    vals['account_code'] = account.code
                if not vals.get('account_name'):
                    vals['account_name'] = account.name

            if 'partner_id' in vals and vals['partner_id']:
                partner = self.env['res.partner'].browse(vals['partner_id'])
                if not vals.get('partner_vat'):
                    vals['partner_vat'] = partner.vat or ''
                if not vals.get('partner_name'):
                    vals['partner_name'] = partner.name
                if not vals.get('partner_document_type') and partner.l10n_latam_identification_type_id:
                    vals['partner_document_type'] = partner.l10n_latam_identification_type_id.l10n_pe_vat_code or '0'

        return super().create(vals_list)

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code}] {line.account_name}"
            if line.partner_name:
                name += f" - {line.partner_name}"
            result.append((line.id, name))
        return result
