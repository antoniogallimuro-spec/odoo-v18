from odoo import api, fields, models, _


class PleLine0302(models.Model):
    _name = 'ple.line.03.02'
    _description = 'PLE 3.2 - Detalle del Saldo de la Cuenta 10'
    _order = 'sequence, account_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )
    
    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )
    
    # Campos según formato SUNAT para 3.2
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )
    
    account_plan_code = fields.Char(
        string='Código Plan de Cuentas',
        default='01',
        help='01 = Plan Contable General Empresarial'
    )
    
    account_id = fields.Many2one(
        'account.account',
        string='Cuenta Contable',
        required=True,
        domain="[('company_ids', 'in', company_id), ('code', '=like', '10%')]"
    )
    
    account_code = fields.Char(
        string='Código Cuenta',
        required=True,
        help='Código de la cuenta contable (debe empezar con 10)'
    )
    
    account_name = fields.Char(
        string='Descripción Cuenta',
        required=True,
        help='Descripción de la cuenta contable'
    )
    
    financial_entity_code = fields.Char(
        string='Código Entidad Financiera',
        help='Código según Tabla 3 SUNAT (ej: 01=Banco de Crédito, 03=Continental)'
    )
    
    currency_code = fields.Selection([
        ('PEN', 'Soles - PEN'),
        ('USD', 'Dólares - USD'),
        ('EUR', 'Euros - EUR'),
    ], string='Tipo de Moneda', default='PEN', required=True)
    
    account_number = fields.Char(
        string='Número de Cuenta',
        help='Número de la cuenta bancaria o caja'
    )
    
    final_balance = fields.Monetary(
        string='Saldo Final',
        currency_field='company_currency_id',
        default=0.0,
        help='Saldo final de la cuenta al cierre del periodo'
    )
    
    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)
    
    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )
    
    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )
    
    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )
    
    journal_id = fields.Many2one(
        'account.journal',
        string='Diario',
        help='Diario asociado (Banco/Caja)'
    )
    
    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False
    
    @api.onchange('account_id')
    def _onchange_account_id(self):
        """Auto-completar código y nombre cuando se selecciona cuenta"""
        if self.account_id:
            self.account_code = self.account_id.code
            self.account_name = self.account_id.name
    
    @api.onchange('journal_id')
    def _onchange_journal_id(self):
        """Auto-completar datos del diario/banco"""
        if self.journal_id:
            if self.journal_id.bank_account_id:
                self.account_number = self.journal_id.bank_account_id.acc_number
                # Intentar obtener código de banco
                if self.journal_id.bank_id:
                    # Aquí podrías mapear el banco a código SUNAT
                    pass
            if self.journal_id.currency_id:
                if self.journal_id.currency_id.name in ['PEN', 'USD', 'EUR']:
                    self.currency_code = self.journal_id.currency_id.name
    
    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.2
        
        Estructura:
        1. Periodo (8)
        2. Código Plan de Cuentas (2)
        3. Código Cuenta Contable (24)
        4. Descripción Cuenta (100)
        5. Código Entidad Financiera (4)
        6. Tipo de Moneda (3)
        7. Número de Cuenta (50)
        8. Saldo Final (decimal 12.2)
        9. Indicador Estado (1)
        
        Separador: |
        """
        self.ensure_one()
        
        # Formatear monto
        balance = f"{self.final_balance:.2f}" if self.final_balance else "0.00"
        
        # Construir línea
        line_parts = [
            self.period or '',                              # 1. Periodo
            self.account_plan_code or '01',                # 2. Código Plan
            self.account_code or '',                       # 3. Código Cuenta
            self.account_name or '',                       # 4. Descripción
            self.financial_entity_code or '',              # 5. Código Entidad
            self.currency_code or 'PEN',                   # 6. Moneda
            self.account_number or '',                     # 7. Número Cuenta
            balance,                                       # 8. Saldo Final
            self.state_code or '1',                        # 9. Estado
        ]
        
        return '|'.join(line_parts) + '|'
    
    @api.model_create_multi
    def create(self, vals_list):
        """Auto-completar campos al crear"""
        for vals in vals_list:
            if 'account_id' in vals and vals['account_id']:
                account = self.env['account.account'].browse(vals['account_id'])
                if not vals.get('account_code'):
                    vals['account_code'] = account.code
                if not vals.get('account_name'):
                    vals['account_name'] = account.name
        return super().create(vals_list)
    
    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code}] {line.account_name}"
            if line.account_number:
                name += f" - {line.account_number}"
            result.append((line.id, name))
        return result
