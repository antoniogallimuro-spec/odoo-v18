from odoo import api, fields, models, _


class PleLine0308(models.Model):
    _name = 'ple.line.03.08'
    _description = 'PLE 3.8 - Detalle del Saldo de la Cuenta 21 - Productos Terminados'
    _order = 'sequence, account_code'

    report_id = fields.Many2one(
        'ple.report.03',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 3.8
    period = fields.Char(
        string='Periodo',
        compute='_compute_report_fields',
        store=True,
        help='Formato YYYYMMDD'
    )

    account_plan_code = fields.Char(
        string='Código Plan de Cuentas',
        default='01',
        help='01 = Plan Contable General Empresarial'
    )

    account_id = fields.Many2one(
        'account.account',
        string='Cuenta Contable',
        required=True,
        domain="[('company_ids', 'in', company_id), ('code', '=like', '21%')]"
    )

    account_code = fields.Char(
        string='Código Cuenta',
        required=True,
        help='Código de la cuenta contable (debe empezar con 21)'
    )

    account_name = fields.Char(
        string='Descripción Cuenta',
        required=True,
        help='Descripción de la cuenta contable'
    )

    product_code = fields.Char(
        string='Código Producto',
        help='Código del producto terminado'
    )

    product_name = fields.Char(
        string='Descripción Producto',
        help='Descripción del producto terminado'
    )

    product_uom = fields.Char(
        string='Unidad de Medida',
        help='Unidad de medida del producto'
    )

    quantity = fields.Float(
        string='Cantidad',
        digits='Product Unit of Measure',
        default=0.0,
        help='Cantidad en stock al cierre del periodo'
    )

    unit_cost = fields.Monetary(
        string='Costo Unitario',
        currency_field='company_currency_id',
        default=0.0,
        help='Costo unitario del producto'
    )

    final_balance = fields.Monetary(
        string='Saldo Final',
        currency_field='company_currency_id',
        default=0.0,
        help='Valor total del inventario al cierre'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.onchange('account_id')
    def _onchange_account_id(self):
        """Auto-completar código y nombre cuando se selecciona cuenta"""
        if self.account_id:
            self.account_code = self.account_id.code
            self.account_name = self.account_id.name

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 3.8

        Estructura:
        1. Periodo (8)
        2. Código Plan de Cuentas (2)
        3. Código Cuenta Contable (24)
        4. Descripción Cuenta (100)
        5. Código Producto (24)
        6. Descripción Producto (60)
        7. Unidad de Medida (3)
        8. Cantidad (decimal 12.2)
        9. Costo Unitario (decimal 12.2)
        10. Saldo Final (decimal 12.2)
        11. Indicador Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear valores numéricos
        quantity_str = f"{self.quantity:.2f}" if self.quantity else "0.00"
        unit_cost_str = f"{self.unit_cost:.2f}" if self.unit_cost else "0.00"
        balance_str = f"{self.final_balance:.2f}" if self.final_balance else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                              # 1. Periodo
            self.account_plan_code or '01',                # 2. Código Plan
            self.account_code or '',                       # 3. Código Cuenta
            self.account_name or '',                       # 4. Descripción
            self.product_code or '',                       # 5. Código Producto
            self.product_name or '',                       # 6. Descripción Producto
            self.product_uom or '',                        # 7. Unidad de Medida
            quantity_str,                                  # 8. Cantidad
            unit_cost_str,                                 # 9. Costo Unitario
            balance_str,                                   # 10. Saldo Final
            self.state_code or '1',                        # 11. Estado
        ]

        return '|'.join(line_parts) + '|'

    @api.model_create_multi
    def create(self, vals_list):
        """Auto-completar campos al crear"""
        for vals in vals_list:
            if 'account_id' in vals and vals['account_id']:
                account = self.env['account.account'].browse(vals['account_id'])
                if not vals.get('account_code'):
                    vals['account_code'] = account.code
                if not vals.get('account_name'):
                    vals['account_name'] = account.name

        return super().create(vals_list)

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code}] {line.account_name}"
            if line.product_code:
                name += f" - Prod: {line.product_code}"
            result.append((line.id, name))
        return result
