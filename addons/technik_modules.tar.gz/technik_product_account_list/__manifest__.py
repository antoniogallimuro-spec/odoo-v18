# -*- coding: utf-8 -*-
{
    'name': 'Technik Product Category Account List',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Inventory',
    'summary': 'Show accounting fields in product category list view',
    'description': """
Technik Product Category Account List
=================================

This module extends the product category list view to display the following
accounting fields:

* Price Difference Account (property_account_creditor_price_difference_categ)
* Income Account (property_account_income_categ_id)
* Expense Account (property_account_expense_categ_id)
* Stock Valuation Account (property_stock_valuation_account_id)
* Stock Input Account (property_stock_account_input_categ_id)
* Stock Output Account (property_stock_account_output_categ_id)
* Production Cost Account (property_stock_account_production_cost_id)

This helps users quickly review and audit the accounting configuration
of product categories without opening each record individually.
    """,
    'author': 'Technik',
    'website': '',
    'depends': [
        'product',
        'stock_account',
        'purchase_stock',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/product_category_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'LGPL-3',
}
