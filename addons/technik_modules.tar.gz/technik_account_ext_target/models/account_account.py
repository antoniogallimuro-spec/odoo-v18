from odoo import models, fields, api

class AccountAccount(models.Model):
    _inherit = 'account.account'

    credit_target_account_id = fields.Many2one(
        comodel_name='account.account',
        string='Cuenta Objetivo Crédito',
        help='Cuenta contable objetivo para operaciones de crédito',
        domain="[('company_ids', '=', company_ids)]",
        check_company=True
    )
    
    debit_target_account_id = fields.Many2one(
        comodel_name='account.account',
        string='Cuenta Objetivo Débito',
        help='Cuenta contable objetivo para operaciones de débito',
        domain="[('company_ids', '=', company_ids)]",
        check_company=True
    )
