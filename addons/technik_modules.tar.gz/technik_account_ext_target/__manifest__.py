{
    'name': 'Technik Account Extension Target',
    'version': '18.0.1.0.0',
    'category': 'Accounting',
    'summary': 'Extiende account.account con cuentas objetivo de crédito y débito',
    'description': """
        Módulo que extiende el modelo account.account agregando:
        - Campo credit_target_account_id: Cuenta objetivo para crédito
        - Campo debit_target_account_id: Cuenta objetivo para débito
    """,
    'author': 'Technik',
    'website': 'https://www.fya.com',
    'depends': ['account'],
    'data': [
        'views/account_account_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}