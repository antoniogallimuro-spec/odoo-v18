# -*- coding: utf-8 -*-
{
    'name': 'Technik - Validación RUC/DNI con DeColecta',
    'version': '18.0.1.1.0',
    'category': 'Accounting/Localizations',
    'summary': 'Validación de RUC y DNI usando API DeColecta y autocompletado de datos',
    'description': """
Technik - Validación RUC/DNI con DeColecta
=======================================

Este módulo permite validar el RUC y DNI de un contacto usando la API de DeColecta
y autocompleta los datos automáticamente.

Características:
- Validación automática de RUC (SUNAT) al cambiar el campo VAT
- Validación automática de DNI (RENIEC) al cambiar el campo VAT
- Botón manual para consultar RUC o DNI
- Autocompletado para RUC:
  - Razón Social
  - Nombre Comercial
  - Dirección
  - Distrito, Provincia, Departamento
  - Estado y Condición del contribuyente
- Autocompletado para DNI:
  - Nombre completo (RENIEC)
  - País (Perú)

Requiere configurar el token de DeColecta en Ajustes.
    """,
    'author': 'Technik',
    'website': 'https://fya.pe',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'contacts',
        'l10n_pe',
        'technik_currency_type_sunat_decolecta',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/res_partner_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
