# -*- coding: utf-8 -*-
import requests
import logging
from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

_logger = logging.getLogger(__name__)

DECOLECTA_RUC_URL = 'https://api.decolecta.com/v1/sunat/ruc/full'
DECOLECTA_DNI_URL = 'https://api.decolecta.com/v1/reniec/dni'


class ResPartner(models.Model):
    _inherit = 'res.partner'

    # Campos de validación RUC con prefijo l10n_pe
    l10n_pe_commercial_name = fields.Char(
        string='Nombre Comercial',
        help='Nombre comercial registrado en SUNAT',
    )
    l10n_pe_state_contributor = fields.Selection(
        selection=[
            ('habido', 'Habido'),
            ('nhabido', 'No Habido'),
        ],
        string='Condición Domicilio',
        help='Condición de domicilio del contribuyente (HABIDO/NO HABIDO)',
    )
    l10n_pe_contributor_active = fields.Boolean(
        string='Contribuyente Activo',
        default=False,
        help='Indica si el contribuyente está activo en SUNAT',
    )
    l10n_pe_contributor_state = fields.Char(
        string='Estado Contribuyente',
        readonly=True,
        help='Estado del contribuyente en SUNAT (ACTIVO, BAJA, SUSPENSION, etc.)',
    )

    def _get_decolecta_token(self):
        """Obtiene el token de DeColecta desde la configuración."""
        token = self.env['ir.config_parameter'].sudo().get_param(
            'technik_cts_decolecta_token',
            default=''
        )
        if not token:
            raise UserError(
                _('Token de DeColecta no configurado. '
                  'Por favor configure el token en Ajustes > Contabilidad.')
            )
        return token

    def _call_decolecta_ruc_api(self, ruc):
        """
        Llama a la API de DeColecta para consultar información del RUC.

        Args:
            ruc: Número de RUC a consultar

        Returns:
            dict: Datos del RUC desde DeColecta
        """
        token = self._get_decolecta_token()

        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        }

        try:
            url = f'{DECOLECTA_RUC_URL}?numero={ruc}'
            _logger.info(f'[DeColecta RUC] Consultando: {url}')

            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()

            data = response.json()
            _logger.info(f'[DeColecta RUC] Respuesta: {data}')

            return data

        except requests.exceptions.Timeout:
            raise UserError(
                _('Tiempo de espera agotado al conectar con DeColecta.')
            )
        except requests.exceptions.RequestException as e:
            raise UserError(
                _('Error al conectar con DeColecta API: %s') % str(e)
            )
        except ValueError as e:
            raise ValidationError(
                _('Error al procesar la respuesta de DeColecta: %s') % str(e)
            )

    def _call_decolecta_dni_api(self, dni):
        """
        Llama a la API de DeColecta RENIEC para consultar información del DNI.

        Args:
            dni: Número de DNI a consultar (8 dígitos)

        Returns:
            dict: Datos del DNI desde DeColecta
        """
        token = self._get_decolecta_token()

        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json',
        }

        try:
            url = f'{DECOLECTA_DNI_URL}?numero={dni}'
            _logger.info(f'[DeColecta DNI] Consultando: {url}')

            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()

            data = response.json()
            _logger.info(f'[DeColecta DNI] Respuesta: {data}')

            return data

        except requests.exceptions.Timeout:
            raise UserError(
                _('Tiempo de espera agotado al conectar con DeColecta.')
            )
        except requests.exceptions.RequestException as e:
            raise UserError(
                _('Error al conectar con DeColecta API: %s') % str(e)
            )
        except ValueError as e:
            raise ValidationError(
                _('Error al procesar la respuesta de DeColecta: %s') % str(e)
            )

    def _update_partner_from_dni_data(self, data):
        """
        Actualiza los datos del partner con la información del DNI (RENIEC).

        Campos de DeColecta RENIEC:
        - full_name -> name
        - first_name -> nombres
        - first_last_name -> apellido paterno
        - second_last_name -> apellido materno

        Args:
            data: Diccionario con datos de DeColecta RENIEC
        """
        vals = {}

        # Nombre completo
        if data.get('full_name'):
            vals['name'] = data['full_name'].strip()
        elif data.get('first_name') and data.get('first_last_name'):
            parts = [
                data.get('first_last_name', '').strip(),
                data.get('second_last_name', '').strip(),
                data.get('first_name', '').strip(),
            ]
            vals['name'] = ' '.join(p for p in parts if p)

        # País Perú por defecto
        peru = self.env['res.country'].search([('code', '=', 'PE')], limit=1)
        if peru:
            vals['country_id'] = peru.id

        # Tipo persona
        vals['company_type'] = 'person'

        self.write(vals)

    def _find_district_by_ubigeo(self, ubigeo):
        """
        Busca el distrito por código de ubigeo.

        Args:
            ubigeo: Código de ubigeo SUNAT (6 dígitos)

        Returns:
            recordset: Distrito encontrado o False
        """
        if not ubigeo or len(ubigeo) != 6:
            return False

        district = self.env['l10n_pe.res.city.district'].search([
            ('code', '=', ubigeo)
        ], limit=1)

        return district

    def _find_district_by_name(self, distrito, provincia, departamento):
        """
        Busca el distrito por nombre en la base de datos.

        Args:
            distrito: Nombre del distrito
            provincia: Nombre de la provincia
            departamento: Nombre del departamento

        Returns:
            recordset: Distrito encontrado o False
        """
        if not distrito:
            return False

        # Normalizar nombres (title case)
        distrito = distrito.strip().title()
        provincia = provincia.strip().title() if provincia else ''
        departamento = departamento.strip().title() if departamento else ''

        # Buscar provincia (res.city)
        city_domain = [('name', 'ilike', provincia)]
        if departamento:
            state = self.env['res.country.state'].search([
                ('name', 'ilike', departamento),
                ('country_id.code', '=', 'PE')
            ], limit=1)
            if state:
                city_domain.append(('state_id', '=', state.id))

        cities = self.env['res.city'].search(city_domain)

        # Buscar distrito
        district_domain = [('name', 'ilike', distrito)]
        if cities:
            district_domain.append(('city_id', 'in', cities.ids))

        district = self.env['l10n_pe.res.city.district'].search(
            district_domain, limit=1
        )

        # Si no encuentra con la provincia, buscar solo por nombre
        if not district:
            district = self.env['l10n_pe.res.city.district'].search([
                ('name', 'ilike', distrito)
            ], limit=1)

        return district

    def _update_partner_from_ruc_data(self, data):
        """
        Actualiza los datos del partner con la información del RUC.

        Campos de DeColecta:
        - razon_social -> name
        - nombre_comercial -> l10n_pe_commercial_name
        - estado -> l10n_pe_contributor_state, l10n_pe_contributor_active
        - condicion -> l10n_pe_state_contributor (habido/nhabido)
        - direccion -> street
        - ubigeo -> para buscar distrito
        - distrito, provincia, departamento -> l10n_pe_district, city_id, state_id

        Args:
            data: Diccionario con datos de DeColecta
        """
        vals = {}

        # Razón Social -> name
        if data.get('razon_social'):
            vals['name'] = data['razon_social'].strip()

        # Nombre Comercial -> l10n_pe_commercial_name
        if data.get('nombre_comercial'):
            vals['l10n_pe_commercial_name'] = data['nombre_comercial'].strip()

        # Estado del contribuyente -> l10n_pe_contributor_state, l10n_pe_contributor_active
        estado = data.get('estado', '')
        vals['l10n_pe_contributor_state'] = estado
        vals['l10n_pe_contributor_active'] = (estado == 'ACTIVO')

        # Condición (HABIDO/NO HABIDO) -> l10n_pe_state_contributor
        condicion = data.get('condicion', '')
        if condicion == 'HABIDO':
            vals['l10n_pe_state_contributor'] = 'habido'
        elif condicion == 'NO HABIDO':
            vals['l10n_pe_state_contributor'] = 'nhabido'

        # Dirección -> street
        if data.get('direccion'):
            vals['street'] = data['direccion'].strip()

        # Buscar distrito por ubigeo primero, luego por nombre
        district = False
        ubigeo = data.get('ubigeo')
        if ubigeo:
            district = self._find_district_by_ubigeo(ubigeo)

        if not district:
            district = self._find_district_by_name(
                data.get('distrito', ''),
                data.get('provincia', ''),
                data.get('departamento', '')
            )

        # Ubicación geográfica
        if district:
            vals['l10n_pe_district'] = district.id
            if district.city_id:
                vals['city_id'] = district.city_id.id
                if district.city_id.state_id:
                    vals['state_id'] = district.city_id.state_id.id
                    if district.city_id.state_id.country_id:
                        vals['country_id'] = district.city_id.state_id.country_id.id

        # País por defecto Perú
        if 'country_id' not in vals:
            peru = self.env['res.country'].search([('code', '=', 'PE')], limit=1)
            if peru:
                vals['country_id'] = peru.id

        # Tipo de empresa
        vals['company_type'] = 'company'

        self.write(vals)

    def action_validate_ruc_decolecta(self):
        """
        Acción para validar el RUC o DNI usando DeColecta API.
        Llamada desde el botón en la vista.
        """
        self.ensure_one()

        if not self.vat:
            raise UserError(_('Debe ingresar un número de documento.'))

        # Determinar tipo de documento
        vat_code = False
        if self.l10n_latam_identification_type_id:
            vat_code = self.l10n_latam_identification_type_id.l10n_pe_vat_code

        # DNI: código '1', 8 dígitos
        if vat_code == '1':
            if len(self.vat) != 8:
                raise UserError(_('El DNI debe tener 8 dígitos.'))

            data = self._call_decolecta_dni_api(self.vat)

            if not data:
                raise UserError(_('No se encontraron datos para el DNI %s') % self.vat)

            if data.get('error'):
                raise UserError(_('Error de DeColecta: %s') % data['error'])

            self._update_partner_from_dni_data(data)

            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Validación DNI'),
                    'message': _('Datos actualizados correctamente desde RENIEC.'),
                    'type': 'success',
                    'sticky': False,
                }
            }

        # RUC: código '6', 11 dígitos
        elif vat_code == '6' or not vat_code:
            if len(self.vat) != 11:
                raise UserError(_('El RUC debe tener 11 dígitos.'))

            data = self._call_decolecta_ruc_api(self.vat)

            if not data:
                raise UserError(_('No se encontraron datos para el RUC %s') % self.vat)

            if data.get('error'):
                raise UserError(_('Error de DeColecta: %s') % data['error'])

            self._update_partner_from_ruc_data(data)

            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Validación RUC'),
                    'message': _('Datos actualizados correctamente desde SUNAT.'),
                    'type': 'success',
                    'sticky': False,
                }
            }

        else:
            raise UserError(
                _('La validación solo está disponible para documentos tipo RUC y DNI.')
            )

    @api.onchange('vat', 'l10n_latam_identification_type_id')
    def _onchange_vat_decolecta(self):
        """
        Valida automáticamente el RUC o DNI al cambiar el VAT.
        RUC (código 6): 11 dígitos, DNI (código 1): 8 dígitos.
        """
        if not self.vat:
            return

        if not self.l10n_latam_identification_type_id:
            return

        vat_code = self.l10n_latam_identification_type_id.l10n_pe_vat_code

        # Verificar si tiene token configurado
        token = self.env['ir.config_parameter'].sudo().get_param(
            'technik_cts_decolecta_token',
            default=''
        )
        if not token:
            return

        # DNI: código '1', 8 dígitos
        if vat_code == '1':
            if len(self.vat) != 8:
                return {
                    'warning': {
                        'title': _('Advertencia'),
                        'message': _('El DNI debe tener 8 dígitos.'),
                    }
                }

            try:
                data = self._call_decolecta_dni_api(self.vat)

                if data and not data.get('error'):
                    # Nombre completo
                    if data.get('full_name'):
                        self.name = data['full_name'].strip()
                    elif data.get('first_name') and data.get('first_last_name'):
                        parts = [
                            data.get('first_last_name', '').strip(),
                            data.get('second_last_name', '').strip(),
                            data.get('first_name', '').strip(),
                        ]
                        self.name = ' '.join(p for p in parts if p)

                    # País Perú por defecto
                    if not self.country_id:
                        peru = self.env['res.country'].search([('code', '=', 'PE')], limit=1)
                        if peru:
                            self.country_id = peru.id

                    self.company_type = 'person'

            except Exception as e:
                _logger.warning(f'[DeColecta DNI] Error en onchange: {str(e)}')

        # RUC: código '6', 11 dígitos
        elif vat_code == '6':
            if len(self.vat) != 11:
                return {
                    'warning': {
                        'title': _('Advertencia'),
                        'message': _('El RUC debe tener 11 dígitos.'),
                    }
                }

            try:
                data = self._call_decolecta_ruc_api(self.vat)

                if data and not data.get('error'):
                    if data.get('razon_social'):
                        self.name = data['razon_social'].strip()

                    if data.get('nombre_comercial'):
                        self.l10n_pe_commercial_name = data['nombre_comercial'].strip()

                    estado = data.get('estado', '')
                    self.l10n_pe_contributor_state = estado
                    self.l10n_pe_contributor_active = (estado == 'ACTIVO')

                    condicion = data.get('condicion', '')
                    if condicion == 'HABIDO':
                        self.l10n_pe_state_contributor = 'habido'
                    elif condicion == 'NO HABIDO':
                        self.l10n_pe_state_contributor = 'nhabido'

                    if data.get('direccion'):
                        self.street = data['direccion'].strip()

                    district = False
                    ubigeo = data.get('ubigeo')
                    if ubigeo:
                        district = self._find_district_by_ubigeo(ubigeo)

                    if not district:
                        district = self._find_district_by_name(
                            data.get('distrito', ''),
                            data.get('provincia', ''),
                            data.get('departamento', '')
                        )

                    if district:
                        self.l10n_pe_district = district.id
                        if district.city_id:
                            self.city_id = district.city_id.id
                            if district.city_id.state_id:
                                self.state_id = district.city_id.state_id.id
                                if district.city_id.state_id.country_id:
                                    self.country_id = district.city_id.state_id.country_id.id

                    if not self.country_id:
                        peru = self.env['res.country'].search([('code', '=', 'PE')], limit=1)
                        if peru:
                            self.country_id = peru.id

                    self.company_type = 'company'

            except Exception as e:
                _logger.warning(f'[DeColecta RUC] Error en onchange: {str(e)}')
