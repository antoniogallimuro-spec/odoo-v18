# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 5.0 - Libro Diario',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 5.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 5.0 - Libro Diario para Odoo 18
====================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 5.0
correspondiente al Libro Diario según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 5.0 por período mensual
* Soporte para dos formatos:
  - 5.1: Libro Diario (formato completo)
  - 5.2: Libro Diario de Formato Simplificado
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos mensuales
* Integración completa con asientos contables (account.move)

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período mensual
3. Generar: Obtiene los asientos contables del período
4. Publicar: Genera los archivos TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 05.01: Libro Diario (formato completo)
* 05.02: Libro Diario de Formato Simplificado

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}000501{ESTABLECIMIENTO}{OIM}1.txt (Formato 5.1)
LE{RUC}{PERIODO}000502{ESTABLECIMIENTO}{OIM}1.txt (Formato 5.2)

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAAMM00 (año, mes y 00)
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro 5.1:
-------------------------
1. Período (AAAAMM00)
2. Número Correlativo del Asiento
3. Código del Libro/Registro
4. Número Correlativo
5. Fecha de la Operación
6. Glosa o Descripción General
7. Glosa Referencial
8. Código de la Cuenta Contable
9. Denominación de la Cuenta Contable
10. Debe
11. Haber
12. Dato Estructurado
13. Estado de la Operación

Campos del Registro 5.2 (Simplificado):
----------------------------------------
1. Período (AAAAMM00)
2. Número Correlativo del Asiento
3. Fecha de la Operación
4. Glosa o Descripción de la Operación
5. Código de la Cuenta Contable
6. Denominación de la Cuenta Contable
7. Debe
8. Haber
9. Dato Estructurado
10. Estado de la Operación

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_05_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
