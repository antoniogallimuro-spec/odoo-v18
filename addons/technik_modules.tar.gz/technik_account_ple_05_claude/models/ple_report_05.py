# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
import base64
import logging

_logger = logging.getLogger(__name__)


class PleReport05(models.Model):
    _name = 'ple.report.05'
    _description = 'PLE 5.0 - Libro Diario'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc, month desc'

    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company,
        tracking=True
    )
    year = fields.Integer(
        string='Año',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True
    )
    month = fields.Selection([
        ('01', 'Enero'),
        ('02', 'Febrero'),
        ('03', 'Marzo'),
        ('04', 'Abril'),
        ('05', 'Mayo'),
        ('06', 'Junio'),
        ('07', 'Julio'),
        ('08', 'Agosto'),
        ('09', 'Septiembre'),
        ('10', 'Octubre'),
        ('11', 'Noviembre'),
        ('12', 'Diciembre'),
    ], string='Mes', required=True, tracking=True)

    period = fields.Char(
        string='Período',
        compute='_compute_period',
        store=True,
        help='Formato AAAAMM00'
    )

    date_from = fields.Date(
        string='Fecha Inicio',
        required=True,
        tracking=True
    )
    date_to = fields.Date(
        string='Fecha Fin',
        required=True,
        tracking=True
    )

    state = fields.Selection([
        ('draft', 'Borrador'),
        ('generated', 'Generado'),
        ('published', 'Publicado')
    ], string='Estado', default='draft', required=True, tracking=True)

    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True
    )
    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True
    )

    # Líneas de detalle
    line_05_01_ids = fields.One2many(
        'ple.line.05.01',
        'report_id',
        string='Libro Diario 5.1'
    )
    line_05_02_ids = fields.One2many(
        'ple.line.05.02',
        'report_id',
        string='Libro Diario Simplificado 5.2'
    )

    # Campos computados
    line_count_05_01 = fields.Integer(
        string='Líneas 5.1',
        compute='_compute_line_counts'
    )
    line_count_05_02 = fields.Integer(
        string='Líneas 5.2',
        compute='_compute_line_counts'
    )

    # Archivos generados
    txt_file_05_01 = fields.Binary(
        string='Archivo TXT 05.01',
        readonly=True
    )
    txt_filename_05_01 = fields.Char(
        string='Nombre Archivo 05.01',
        readonly=True
    )
    txt_file_05_02 = fields.Binary(
        string='Archivo TXT 05.02',
        readonly=True
    )
    txt_filename_05_02 = fields.Char(
        string='Nombre Archivo 05.02',
        readonly=True
    )

    @api.depends('year', 'month')
    def _compute_name(self):
        for record in self:
            month_name = dict(self._fields['month'].selection).get(record.month, '')
            record.name = f"PLE 5.0 - {record.year} - {month_name}"

    @api.depends('year', 'month')
    def _compute_period(self):
        for record in self:
            if record.year and record.month:
                record.period = f"{record.year}{record.month}00"
            else:
                record.period = False

    @api.depends('line_05_01_ids', 'line_05_02_ids')
    def _compute_line_counts(self):
        for record in self:
            record.line_count_05_01 = len(record.line_05_01_ids)
            record.line_count_05_02 = len(record.line_05_02_ids)

    @api.onchange('year', 'month')
    def _onchange_period_dates(self):
        """Calcula automáticamente las fechas inicio y fin del período"""
        if self.year and self.month:
            month_int = int(self.month)
            self.date_from = datetime(self.year, month_int, 1).date()

            # Último día del mes
            if month_int == 12:
                next_month = datetime(self.year + 1, 1, 1)
            else:
                next_month = datetime(self.year, month_int + 1, 1)

            from datetime import timedelta
            self.date_to = (next_month - timedelta(days=1)).date()

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for record in self:
            if record.date_from and record.date_to and record.date_from > record.date_to:
                raise ValidationError(_('La fecha de inicio no puede ser mayor a la fecha fin.'))

    def action_generate(self):
        """Genera las líneas del reporte PLE según el período seleccionado"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError(_('Solo se pueden generar reportes en estado Borrador.'))

        # Limpiar líneas existentes
        self.line_05_01_ids.unlink()
        self.line_05_02_ids.unlink()

        # Obtener asientos contables en el rango de fechas
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('state', '=', 'posted'),  # Solo asientos contabilizados
        ]

        moves = self.env['account.move'].search(domain, order='date, name')

        # Generar líneas para formato 5.1 (completo)
        line_05_01_vals = []
        for move in moves:
            for line in move.line_ids:
                line_05_01_vals.append({
                    'report_id': self.id,
                    'move_id': move.id,
                    'move_line_id': line.id,
                })

        # Generar líneas para formato 5.2 (simplificado)
        line_05_02_vals = []
        for move in moves:
            for line in move.line_ids:
                line_05_02_vals.append({
                    'report_id': self.id,
                    'move_id': move.id,
                    'move_line_id': line.id,
                })

        if line_05_01_vals:
            self.env['ple.line.05.01'].create(line_05_01_vals)

        if line_05_02_vals:
            self.env['ple.line.05.02'].create(line_05_02_vals)

        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _('Se han generado %s líneas de formato 5.1 y %s líneas de formato 5.2.') % (
                    len(line_05_01_vals), len(line_05_02_vals)
                ),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_publish(self):
        """Publica el reporte generando los archivos TXT"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError(_('Solo se pueden publicar reportes en estado Generado.'))

        # Generar archivos TXT
        if self.line_05_01_ids:
            self._generate_txt_05_01()
        if self.line_05_02_ids:
            self._generate_txt_05_02()

        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_back_to_draft(self):
        """Regresa el reporte a estado borrador"""
        self.ensure_one()
        self.write({'state': 'draft'})

    def _generate_txt_05_01(self):
        """Genera el archivo TXT según formato PLE 5.1"""
        self.ensure_one()

        if not self.line_05_01_ids:
            return

        # RUC de la compañía
        ruc = self.company_id.vat or '00000000000'

        # Formato: LERRRRRRRRRRRAAAAMMDD000501EEEEOIM1.txt
        establecimiento = '0000'
        oim = '1'  # 1=Operaciones normales, Moneda=1 (soles)

        filename = f"LE{ruc}{self.period}00000501{establecimiento}{oim}1.txt"

        # Generar contenido
        lines = []
        for line in self.line_05_01_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.txt_file_05_01 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_05_01 = filename

    def _generate_txt_05_02(self):
        """Genera el archivo TXT según formato PLE 5.2"""
        self.ensure_one()

        if not self.line_05_02_ids:
            return

        # RUC de la compañía
        ruc = self.company_id.vat or '00000000000'

        # Formato: LERRRRRRRRRRRAAAAMMDD000502EEEEOIM1.txt
        establecimiento = '0000'
        oim = '1'  # 1=Operaciones normales, Moneda=1 (soles)

        filename = f"LE{ruc}{self.period}00000502{establecimiento}{oim}1.txt"

        # Generar contenido
        lines = []
        for line in self.line_05_02_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.txt_file_05_02 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_05_02 = filename

    def action_view_lines_05_01(self):
        """Abre vista de líneas formato 5.1"""
        self.ensure_one()

        return {
            'name': _('Libro Diario 5.1 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.05.01',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_05_02(self):
        """Abre vista de líneas formato 5.2"""
        self.ensure_one()

        return {
            'name': _('Libro Diario Simplificado 5.2 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.05.02',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }
