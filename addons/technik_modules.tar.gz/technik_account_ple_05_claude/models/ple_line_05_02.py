# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0502(models.Model):
    _name = 'ple.line.05.02'
    _description = 'PLE 5.2 - Libro Diario de Formato Simplificado'
    _order = 'operation_date, entry_number, sequence'

    report_id = fields.Many2one(
        'ple.report.05',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 5.2
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAAMM00'
    )

    entry_number = fields.Char(
        string='Número Correlativo del Asiento',
        required=True,
        help='Código del asiento contable'
    )

    operation_date = fields.Date(
        string='Fecha de la Operación',
        required=True
    )

    description = fields.Text(
        string='Glosa o Descripción',
        help='Descripción de la operación'
    )

    account_code = fields.Char(
        string='Código de Cuenta',
        required=True,
        help='Código de la cuenta contable desagregado al máximo dígito'
    )

    account_name = fields.Char(
        string='Denominación de Cuenta',
        required=True,
        help='Nombre de la cuenta contable'
    )

    debit = fields.Monetary(
        string='Debe',
        currency_field='company_currency_id',
        default=0.0
    )

    credit = fields.Monetary(
        string='Haber',
        currency_field='company_currency_id',
        default=0.0
    )

    structured_data = fields.Char(
        string='Dato Estructurado',
        help='Campo para cruce con otros registros'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación con asiento contable de Odoo
    move_id = fields.Many2one(
        'account.move',
        string='Asiento Contable',
        help='Asiento contable de Odoo'
    )

    move_line_id = fields.Many2one(
        'account.move.line',
        string='Línea de Asiento',
        help='Línea del asiento contable de Odoo'
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.onchange('move_line_id')
    def _onchange_move_line_id(self):
        """Auto-completar campos desde la línea de asiento"""
        if self.move_line_id:
            line = self.move_line_id
            move = line.move_id

            # Datos del asiento
            self.move_id = move.id
            self.entry_number = move.name
            self.operation_date = move.date
            self.description = move.ref or move.narration or ''

            # Datos de la cuenta
            if line.account_id:
                self.account_code = line.account_id.code
                self.account_name = line.account_id.name

            # Montos
            self.debit = line.debit
            self.credit = line.credit

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 5.2 (Simplificado)

        Estructura:
        1. Periodo (8) - AAAAMM00
        2. Número Correlativo del Asiento
        3. Fecha de la Operación (10) - DD/MM/AAAA
        4. Glosa o Descripción
        5. Código de Cuenta
        6. Denominación de Cuenta
        7. Debe (decimal)
        8. Haber (decimal)
        9. Dato Estructurado
        10. Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear fecha
        date_str = self.operation_date.strftime('%d/%m/%Y') if self.operation_date else ''

        # Formatear montos
        debit_str = f"{self.debit:.2f}" if self.debit else "0.00"
        credit_str = f"{self.credit:.2f}" if self.credit else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                      # 1. Periodo
            self.entry_number or '',                # 2. Número Correlativo Asiento
            date_str,                               # 3. Fecha Operación
            self.description or '',                 # 4. Glosa
            self.account_code or '',                # 5. Código Cuenta
            self.account_name or '',                # 6. Denominación Cuenta
            debit_str,                              # 7. Debe
            credit_str,                             # 8. Haber
            self.structured_data or '',             # 9. Dato Estructurado
            self.state_code or '1',                 # 10. Estado
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.entry_number}] {line.account_code or ''} - {line.account_name or ''}"
            if line.debit:
                name += f" D: {line.company_currency_id.symbol} {line.debit:,.2f}"
            if line.credit:
                name += f" H: {line.company_currency_id.symbol} {line.credit:,.2f}"
            result.append((line.id, name))
        return result
