# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0704(models.Model):
    _name = 'ple.line.07.04'
    _description = 'PLE 7.4 - Activos Fijos en Arrendamiento Financiero'
    _order = 'contract_code, sequence'

    report_id = fields.Many2one(
        'ple.report.07',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 7.4
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAA0000'
    )

    contract_code = fields.Char(
        string='Código del Contrato',
        required=True,
        help='Número o código del contrato de leasing'
    )

    asset_description = fields.Char(
        string='Descripción del Activo',
        required=True,
        help='Nombre o descripción del activo bajo leasing'
    )

    contract_start_date = fields.Date(
        string='Fecha Inicio Contrato',
        required=True,
        help='Fecha de inicio del contrato de leasing'
    )

    contract_amount = fields.Monetary(
        string='Monto del Contrato',
        currency_field='company_currency_id',
        help='Valor total del contrato de leasing'
    )

    paid_installments = fields.Monetary(
        string='Cuotas Pagadas',
        currency_field='company_currency_id',
        help='Monto de cuotas pagadas durante el ejercicio'
    )

    pending_balance = fields.Monetary(
        string='Saldo Pendiente',
        currency_field='company_currency_id',
        compute='_compute_pending_balance',
        store=True,
        help='Saldo pendiente del contrato al cierre'
    )

    lessor_name = fields.Char(
        string='Arrendador',
        help='Nombre de la empresa arrendadora (leasing)'
    )

    lessor_vat = fields.Char(
        string='RUC Arrendador',
        help='RUC de la empresa arrendadora'
    )

    contract_term = fields.Integer(
        string='Plazo del Contrato (meses)',
        help='Duración del contrato en meses'
    )

    monthly_installment = fields.Monetary(
        string='Cuota Mensual',
        currency_field='company_currency_id',
        help='Monto de la cuota mensual'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación con activo fijo de Odoo
    asset_id = fields.Many2one(
        'account.asset',
        string='Activo Fijo',
        help='Activo fijo de Odoo bajo leasing'
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.depends('contract_amount', 'paid_installments')
    def _compute_pending_balance(self):
        for line in self:
            line.pending_balance = line.contract_amount - line.paid_installments

    @api.onchange('asset_id')
    def _onchange_asset_id(self):
        """Auto-completar campos desde el activo fijo"""
        if self.asset_id:
            asset = self.asset_id

            self.asset_description = asset.name
            self.contract_start_date = asset.acquisition_date

            # Si el activo tiene información de leasing
            if hasattr(asset, 'original_value'):
                self.contract_amount = asset.original_value

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 7.4

        Estructura:
        1. Período
        2. Código del Contrato
        3. Descripción del Activo
        4. Fecha Inicio Contrato (DD/MM/AAAA)
        5. Monto del Contrato
        6. Cuotas Pagadas
        7. Saldo Pendiente
        8. Estado

        Separador: |
        """
        self.ensure_one()

        # Formatear fecha
        date_str = self.contract_start_date.strftime('%d/%m/%Y') if self.contract_start_date else ''

        # Formatear montos
        contract_str = f"{self.contract_amount:.2f}" if self.contract_amount else "0.00"
        paid_str = f"{self.paid_installments:.2f}" if self.paid_installments else "0.00"
        pending_str = f"{self.pending_balance:.2f}" if self.pending_balance else "0.00"

        line_parts = [
            self.period or '',
            self.contract_code or '',
            self.asset_description or '',
            date_str,
            contract_str,
            paid_str,
            pending_str,
            self.state_code or '1',
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.contract_code or ''}] {line.asset_description or 'Sin nombre'}"
            if line.pending_balance:
                name += f" - Saldo: {line.company_currency_id.symbol} {line.pending_balance:,.2f}"
            result.append((line.id, name))
        return result
