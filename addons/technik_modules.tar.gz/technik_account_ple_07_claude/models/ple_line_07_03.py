# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0703(models.Model):
    _name = 'ple.line.07.03'
    _description = 'PLE 7.3 - Diferencia de Cambio de Activos Fijos'
    _order = 'asset_code, sequence'

    report_id = fields.Many2one(
        'ple.report.07',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 7.3
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAA0000'
    )

    asset_code = fields.Char(
        string='Código del Activo',
        required=True,
        help='Código interno del activo fijo'
    )

    asset_description = fields.Char(
        string='Descripción del Activo',
        required=True,
        help='Nombre o descripción del activo fijo'
    )

    exchange_difference = fields.Monetary(
        string='Diferencia de Cambio',
        currency_field='company_currency_id',
        help='Diferencia de cambio generada por activo en moneda extranjera'
    )

    currency_id = fields.Many2one(
        'res.currency',
        string='Moneda del Activo',
        help='Moneda original del activo'
    )

    original_amount = fields.Monetary(
        string='Monto Original',
        currency_field='currency_id',
        help='Valor del activo en moneda extranjera'
    )

    exchange_rate_initial = fields.Float(
        string='Tipo de Cambio Inicial',
        digits=(12, 4),
        help='Tipo de cambio al inicio del período'
    )

    exchange_rate_final = fields.Float(
        string='Tipo de Cambio Final',
        digits=(12, 4),
        help='Tipo de cambio al cierre del período'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación con activo fijo de Odoo
    asset_id = fields.Many2one(
        'account.asset',
        string='Activo Fijo',
        help='Activo fijo de Odoo'
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.onchange('asset_id')
    def _onchange_asset_id(self):
        """Auto-completar campos desde el activo fijo"""
        if self.asset_id:
            asset = self.asset_id

            self.asset_code = asset.code or asset.name
            self.asset_description = asset.name

            # Si el activo tiene moneda diferente a la de la compañía
            if hasattr(asset, 'currency_id') and asset.currency_id != asset.company_id.currency_id:
                self.currency_id = asset.currency_id

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 7.3

        Estructura:
        1. Período
        2. Código del Activo
        3. Descripción del Activo
        4. Diferencia de Cambio
        5. Estado

        Separador: |
        """
        self.ensure_one()

        # Formatear monto
        exchange_diff_str = f"{self.exchange_difference:.2f}" if self.exchange_difference else "0.00"

        line_parts = [
            self.period or '',
            self.asset_code or '',
            self.asset_description or '',
            exchange_diff_str,
            self.state_code or '1',
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.asset_code or ''}] {line.asset_description or 'Sin nombre'}"
            if line.exchange_difference:
                name += f" - Dif. Cambio: {line.company_currency_id.symbol} {line.exchange_difference:,.2f}"
            result.append((line.id, name))
        return result
