# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
import base64
import logging

_logger = logging.getLogger(__name__)


class PleReport07(models.Model):
    _name = 'ple.report.07'
    _description = 'PLE 7.0 - Registro de Activos Fijos'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc'

    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company,
        tracking=True
    )
    year = fields.Integer(
        string='Año',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True,
        help='Período anual del registro de activos fijos'
    )

    period = fields.Char(
        string='Período',
        compute='_compute_period',
        store=True,
        help='Formato AAAA0000 (registro anual)'
    )

    date_from = fields.Date(
        string='Fecha Inicio',
        required=True,
        tracking=True
    )
    date_to = fields.Date(
        string='Fecha Fin',
        required=True,
        tracking=True
    )

    state = fields.Selection([
        ('draft', 'Borrador'),
        ('generated', 'Generado'),
        ('published', 'Publicado')
    ], string='Estado', default='draft', required=True, tracking=True)

    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True
    )
    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True
    )

    # Líneas de detalle
    line_07_01_ids = fields.One2many(
        'ple.line.07.01',
        'report_id',
        string='Activos Fijos 7.1'
    )
    line_07_03_ids = fields.One2many(
        'ple.line.07.03',
        'report_id',
        string='Diferencia de Cambio 7.3'
    )
    line_07_04_ids = fields.One2many(
        'ple.line.07.04',
        'report_id',
        string='Arrendamiento Financiero 7.4'
    )

    # Campos computados
    line_count_07_01 = fields.Integer(
        string='Líneas 7.1',
        compute='_compute_line_counts'
    )
    line_count_07_03 = fields.Integer(
        string='Líneas 7.3',
        compute='_compute_line_counts'
    )
    line_count_07_04 = fields.Integer(
        string='Líneas 7.4',
        compute='_compute_line_counts'
    )

    # Archivos generados
    txt_file_07_01 = fields.Binary(
        string='Archivo TXT 07.01',
        readonly=True
    )
    txt_filename_07_01 = fields.Char(
        string='Nombre Archivo 07.01',
        readonly=True
    )
    txt_file_07_03 = fields.Binary(
        string='Archivo TXT 07.03',
        readonly=True
    )
    txt_filename_07_03 = fields.Char(
        string='Nombre Archivo 07.03',
        readonly=True
    )
    txt_file_07_04 = fields.Binary(
        string='Archivo TXT 07.04',
        readonly=True
    )
    txt_filename_07_04 = fields.Char(
        string='Nombre Archivo 07.04',
        readonly=True
    )

    @api.depends('year')
    def _compute_name(self):
        for record in self:
            record.name = f"PLE 7.0 - {record.year}"

    @api.depends('year')
    def _compute_period(self):
        for record in self:
            if record.year:
                record.period = f"{record.year}0000"
            else:
                record.period = False

    @api.depends('line_07_01_ids', 'line_07_03_ids', 'line_07_04_ids')
    def _compute_line_counts(self):
        for record in self:
            record.line_count_07_01 = len(record.line_07_01_ids)
            record.line_count_07_03 = len(record.line_07_03_ids)
            record.line_count_07_04 = len(record.line_07_04_ids)

    @api.onchange('year')
    def _onchange_year_dates(self):
        """Calcula automáticamente las fechas inicio y fin del año"""
        if self.year:
            self.date_from = datetime(self.year, 1, 1).date()
            self.date_to = datetime(self.year, 12, 31).date()

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for record in self:
            if record.date_from and record.date_to and record.date_from > record.date_to:
                raise ValidationError(_('La fecha de inicio no puede ser mayor a la fecha fin.'))

    def action_generate(self):
        """Genera las líneas del reporte PLE según el período seleccionado"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError(_('Solo se pueden generar reportes en estado Borrador.'))

        # Limpiar líneas existentes
        self.line_07_01_ids.unlink()
        self.line_07_03_ids.unlink()
        self.line_07_04_ids.unlink()

        # Obtener activos fijos del año
        # Nota: Esta implementación asume que existe el módulo account_asset en Odoo
        assets = self.env['account.asset'].search([
            ('company_id', '=', self.company_id.id),
            ('acquisition_date', '<=', self.date_to),
            '|', ('disposal_date', '=', False), ('disposal_date', '>=', self.date_from),
        ])

        # Generar líneas para formato 7.1 (todos los activos)
        line_07_01_vals = []
        for asset in assets:
            line_07_01_vals.append({
                'report_id': self.id,
                'asset_id': asset.id,
            })

        # Generar líneas para formato 7.3 (activos con diferencia de cambio)
        line_07_03_vals = []
        for asset in assets.filtered(lambda a: a.currency_id != a.company_id.currency_id):
            line_07_03_vals.append({
                'report_id': self.id,
                'asset_id': asset.id,
            })

        # Generar líneas para formato 7.4 (activos en leasing)
        # Nota: Esto requiere que haya un campo o tag para identificar activos en leasing
        line_07_04_vals = []
        leasing_assets = assets.filtered(lambda a: hasattr(a, 'is_leasing') and a.is_leasing)
        for asset in leasing_assets:
            line_07_04_vals.append({
                'report_id': self.id,
                'asset_id': asset.id,
            })

        if line_07_01_vals:
            self.env['ple.line.07.01'].create(line_07_01_vals)

        if line_07_03_vals:
            self.env['ple.line.07.03'].create(line_07_03_vals)

        if line_07_04_vals:
            self.env['ple.line.07.04'].create(line_07_04_vals)

        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _('Se han generado %s líneas formato 7.1, %s líneas formato 7.3 y %s líneas formato 7.4.') % (
                    len(line_07_01_vals), len(line_07_03_vals), len(line_07_04_vals)
                ),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_publish(self):
        """Publica el reporte generando los archivos TXT"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError(_('Solo se pueden publicar reportes en estado Generado.'))

        # Generar archivos TXT
        if self.line_07_01_ids:
            self._generate_txt_07_01()
        if self.line_07_03_ids:
            self._generate_txt_07_03()
        if self.line_07_04_ids:
            self._generate_txt_07_04()

        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_back_to_draft(self):
        """Regresa el reporte a estado borrador"""
        self.ensure_one()
        self.write({'state': 'draft'})

    def _generate_txt_07_01(self):
        """Genera el archivo TXT según formato PLE 7.1"""
        self.ensure_one()

        if not self.line_07_01_ids:
            return

        ruc = self.company_id.vat or '00000000000'
        establecimiento = '0000'
        oim = '1'

        filename = f"LE{ruc}{self.period}00000701{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_07_01_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)
        self.txt_file_07_01 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_07_01 = filename

    def _generate_txt_07_03(self):
        """Genera el archivo TXT según formato PLE 7.3"""
        self.ensure_one()

        if not self.line_07_03_ids:
            return

        ruc = self.company_id.vat or '00000000000'
        establecimiento = '0000'
        oim = '1'

        filename = f"LE{ruc}{self.period}00000703{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_07_03_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)
        self.txt_file_07_03 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_07_03 = filename

    def _generate_txt_07_04(self):
        """Genera el archivo TXT según formato PLE 7.4"""
        self.ensure_one()

        if not self.line_07_04_ids:
            return

        ruc = self.company_id.vat or '00000000000'
        establecimiento = '0000'
        oim = '1'

        filename = f"LE{ruc}{self.period}00000704{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_07_04_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)
        self.txt_file_07_04 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_07_04 = filename

    def action_view_lines_07_01(self):
        """Abre vista de líneas formato 7.1"""
        self.ensure_one()

        return {
            'name': _('Activos Fijos 7.1 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.07.01',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_07_03(self):
        """Abre vista de líneas formato 7.3"""
        self.ensure_one()

        return {
            'name': _('Diferencia de Cambio 7.3 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.07.03',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }

    def action_view_lines_07_04(self):
        """Abre vista de líneas formato 7.4"""
        self.ensure_one()

        return {
            'name': _('Arrendamiento Financiero 7.4 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.07.04',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }
