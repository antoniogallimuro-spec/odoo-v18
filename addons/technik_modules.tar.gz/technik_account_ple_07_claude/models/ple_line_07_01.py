# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0701(models.Model):
    _name = 'ple.line.07.01'
    _description = 'PLE 7.1 - Activos Fijos Revaluados y No Revaluados'
    _order = 'asset_code, sequence'

    report_id = fields.Many2one(
        'ple.report.07',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 7.1
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAA0000'
    )

    operation_code = fields.Char(
        string='Código Único de Operación',
        help='CUO - Código único de la operación'
    )

    entry_number = fields.Char(
        string='Número Correlativo del Asiento',
        help='Asiento contable relacionado'
    )

    account_code = fields.Char(
        string='Cuenta Contable',
        help='Cuenta contable del activo fijo'
    )

    asset_code = fields.Char(
        string='Código del Activo',
        required=True,
        help='Código interno del activo fijo'
    )

    asset_description = fields.Char(
        string='Descripción del Activo',
        required=True,
        help='Nombre o descripción del activo fijo'
    )

    brand = fields.Char(
        string='Marca',
        help='Marca del activo fijo'
    )

    model = fields.Char(
        string='Modelo',
        help='Modelo del activo fijo'
    )

    serial_number = fields.Char(
        string='Número de Serie/Placa',
        help='Número de serie o placa del activo'
    )

    initial_balance = fields.Monetary(
        string='Saldo Inicial',
        currency_field='company_currency_id',
        help='Valor al inicio del ejercicio'
    )

    acquisitions = fields.Monetary(
        string='Adquisiciones',
        currency_field='company_currency_id',
        help='Adquisiciones durante el ejercicio'
    )

    improvements = fields.Monetary(
        string='Mejoras',
        currency_field='company_currency_id',
        help='Mejoras capitalizables'
    )

    retirements = fields.Monetary(
        string='Retiros y/o Bajas',
        currency_field='company_currency_id',
        help='Valor de activos retirados o dados de baja'
    )

    other_adjustments = fields.Monetary(
        string='Otros Ajustes',
        currency_field='company_currency_id',
        help='Otros ajustes al valor del activo'
    )

    historical_value = fields.Monetary(
        string='Valor Histórico',
        currency_field='company_currency_id',
        compute='_compute_historical_value',
        store=True,
        help='Valor total del activo al cierre'
    )

    initial_depreciation = fields.Monetary(
        string='Depreciación Acumulada Inicial',
        currency_field='company_currency_id',
        help='Depreciación acumulada al inicio'
    )

    period_depreciation = fields.Monetary(
        string='Depreciación del Ejercicio',
        currency_field='company_currency_id',
        help='Depreciación calculada en el ejercicio'
    )

    retirement_depreciation = fields.Monetary(
        string='Depreciación de Retiros',
        currency_field='company_currency_id',
        help='Depreciación de activos retirados'
    )

    depreciation_adjustments = fields.Monetary(
        string='Depreciación Otros Ajustes',
        currency_field='company_currency_id',
        help='Ajustes a la depreciación'
    )

    final_depreciation = fields.Monetary(
        string='Depreciación Acumulada Final',
        currency_field='company_currency_id',
        compute='_compute_final_depreciation',
        store=True,
        help='Depreciación acumulada al cierre'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación con activo fijo de Odoo
    asset_id = fields.Many2one(
        'account.asset',
        string='Activo Fijo',
        help='Activo fijo de Odoo'
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.depends('initial_balance', 'acquisitions', 'improvements', 'retirements', 'other_adjustments')
    def _compute_historical_value(self):
        for line in self:
            line.historical_value = (
                line.initial_balance +
                line.acquisitions +
                line.improvements -
                line.retirements +
                line.other_adjustments
            )

    @api.depends('initial_depreciation', 'period_depreciation', 'retirement_depreciation', 'depreciation_adjustments')
    def _compute_final_depreciation(self):
        for line in self:
            line.final_depreciation = (
                line.initial_depreciation +
                line.period_depreciation -
                line.retirement_depreciation +
                line.depreciation_adjustments
            )

    @api.onchange('asset_id')
    def _onchange_asset_id(self):
        """Auto-completar campos desde el activo fijo"""
        if self.asset_id:
            asset = self.asset_id

            self.asset_code = asset.code or asset.name
            self.asset_description = asset.name
            self.account_code = asset.account_asset_id.code if asset.account_asset_id else ''

            # Valores
            self.initial_balance = asset.original_value
            self.historical_value = asset.value_residual

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 7.1

        Estructura (21 campos):
        1. Período
        2. Código Único Operación
        3. Número Correlativo Asiento
        4. Cuenta Contable
        5. Código Activo
        6. Descripción Activo
        7. Marca
        8. Modelo
        9. Número Serie/Placa
        10. Saldo Inicial
        11. Adquisiciones
        12. Mejoras
        13. Retiros y Bajas
        14. Otros Ajustes
        15. Valor Histórico
        16. Depreciación Acumulada Inicial
        17. Depreciación del Ejercicio
        18. Depreciación Retiros
        19. Depreciación Otros Ajustes
        20. Depreciación Acumulada Final
        21. Estado

        Separador: |
        """
        self.ensure_one()

        # Formatear montos
        def fmt(val):
            return f"{val:.2f}" if val else "0.00"

        line_parts = [
            self.period or '',
            self.operation_code or '',
            self.entry_number or '',
            self.account_code or '',
            self.asset_code or '',
            self.asset_description or '',
            self.brand or '',
            self.model or '',
            self.serial_number or '',
            fmt(self.initial_balance),
            fmt(self.acquisitions),
            fmt(self.improvements),
            fmt(self.retirements),
            fmt(self.other_adjustments),
            fmt(self.historical_value),
            fmt(self.initial_depreciation),
            fmt(self.period_depreciation),
            fmt(self.retirement_depreciation),
            fmt(self.depreciation_adjustments),
            fmt(self.final_depreciation),
            self.state_code or '1',
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.asset_code or ''}] {line.asset_description or 'Sin nombre'}"
            result.append((line.id, name))
        return result
