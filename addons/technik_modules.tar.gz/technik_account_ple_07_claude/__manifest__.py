# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 7.0 - Registro de Activos Fijos',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 7.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 7.0 - Registro de Activos Fijos para Odoo 18
=================================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 7.0
correspondiente al Registro de Activos Fijos según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 7.0 por período anual
* Soporte para tres formatos:
  - 7.1: Detalle de Activos Fijos Revaluados y No Revaluados
  - 7.3: Detalle de la Diferencia de Cambio
  - 7.4: Detalle de Activos Fijos bajo Arrendamiento Financiero
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos anuales
* Integración con activos fijos de Odoo
* Control de depreciación según normas tributarias

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período anual
3. Generar: Obtiene los activos fijos del período
4. Publicar: Genera los archivos TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 07.01: Activos Fijos Revaluados y No Revaluados
* 07.03: Diferencia de Cambio
* 07.04: Activos en Arrendamiento Financiero (Leasing)

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}000701{ESTABLECIMIENTO}{OIM}1.txt (Formato 7.1)
LE{RUC}{PERIODO}000703{ESTABLECIMIENTO}{OIM}1.txt (Formato 7.3)
LE{RUC}{PERIODO}000704{ESTABLECIMIENTO}{OIM}1.txt (Formato 7.4)

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAA0000 (año y 0000 para libros anuales)
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro 7.1:
-------------------------
1. Período (AAAA0000)
2. Código Único de la Operación
3. Número Correlativo del Asiento
4. Cuenta Contable del Activo
5. Código del Activo Fijo
6. Descripción del Activo Fijo
7. Marca del Activo Fijo
8. Modelo del Activo Fijo
9. Número de Serie/Placa
10. Saldo Inicial
11. Adquisiciones
12. Mejoras
13. Retiros y/o Bajas
14. Otros Ajustes
15. Valor Histórico del Activo
16. Depreciación Acumulada Inicial
17. Depreciación del Ejercicio
18. Depreciación de Retiros y Bajas
19. Depreciación Otros Ajustes
20. Depreciación Acumulada Final
21. Estado

Campos del Registro 7.3:
-------------------------
(Diferencia de Cambio en Activos Fijos)
1. Período
2. Código del Activo Fijo
3. Descripción del Activo
4. Diferencia de Cambio
5. Estado

Campos del Registro 7.4:
-------------------------
(Arrendamiento Financiero - Leasing)
1. Período
2. Código del Contrato
3. Descripción del Activo
4. Fecha de Inicio del Contrato
5. Monto del Contrato
6. Cuotas Pagadas
7. Saldo Pendiente
8. Estado

Características Especiales:
----------------------------
- Registro de periodicidad ANUAL
- Enfoque en depreciación tributaria (no contable)
- Formato 7.4 solo para arrendamientos financieros (leasing)
- Control de revaluaciones de activos
- Seguimiento de diferencias de cambio en activos en moneda extranjera

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'account_asset',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_07_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
