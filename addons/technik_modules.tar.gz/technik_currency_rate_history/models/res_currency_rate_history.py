from odoo import models, fields, api
from datetime import datetime

class ResCurrencyRateHistory(models.Model):
    _name = 'res.currency.rate.history'
    _description = 'Histórico de Actualizaciones de Tasa de Cambio'
    _order = 'create_date desc'

    # Relación con res.currency.rate
    currency_rate_id = fields.Many2one(
        'res.currency.rate',
        string='Tasa de Cambio',
        required=True,
        ondelete='cascade'
    )

    # Campo de hora de actualización
    time = fields.Datetime(
        string='Hora de Actualización',
        default=fields.Datetime.now,
        required=True
    )

    # Tasa de cambio
    rate = fields.Float(
        string='Tasa',
        required=True,
        digits=(12, 6)
    )

    # Motor/API utilizado
    engine = fields.Char(
        string='Motor de Actualización',
        required=True,
        help='API o servicio utilizado para obtener la tasa'
    )

    # Información de auditoría (automática en Odoo)
    create_date = fields.Datetime(
        string='Fecha de Creación',
        readonly=True
    )
    
    create_uid = fields.Many2one(
        'res.users',
        string='Creado por',
        readonly=True
    )
    
    write_date = fields.Datetime(
        string='Fecha de Modificación',
        readonly=True
    )
    
    write_uid = fields.Many2one(
        'res.users',
        string='Modificado por',
        readonly=True
    )

    @api.model_create_multi
    def create(self, vals_list):
        """Asegurar que time sea poblado correctamente"""
        for vals in vals_list:
            if not vals.get('time'):
                vals['time'] = fields.Datetime.now()
        return super().create(vals_list)

    def name_get(self):
        """Mostrar nombre descriptivo en relaciones"""
        result = []
        for record in self:
            name = f"{record.currency_rate_id.name} - {record.time} ({record.engine})"
            result.append((record.id, name))
        return result
