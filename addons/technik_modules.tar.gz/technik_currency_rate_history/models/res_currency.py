from odoo import models, fields
from odoo.exceptions import ValidationError
import logging
import traceback

_logger = logging.getLogger(__name__)


class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def get_currency_rate(self, date_eval=None):
        self.ensure_one()
        if date_eval:
            if isinstance(date_eval, str):
                try:
                    eval_date = fields.Date.from_string(date_eval)
                except ValueError:
                    raise ValidationError("Formato de fecha inválido. Use YYYY-MM-DD.")
            else:
                eval_date = fields.Date.to_date(date_eval)
        else:
            eval_date = fields.Date.today()
        
        existing_rate = self.env['res.currency.rate'].search([
            ('currency_id', '=', self.id),
            ('name', '<=', eval_date),
            ('company_id', '=', self.env.company.id)
        ], limit=1)

        return existing_rate

    def set_currency_rate(self, rate, date_eval=None, engine='MANUAL_API'):
        """
        Método para registrar o modificar el rate de una moneda según la fecha
        
        :param rate: Tasa de cambio (float)
        :param date_eval: Fecha de evaluación (string o date object) - Opcional, por defecto fecha actual
        :param engine: Motor/API que realiza la actualización (string) - Opcional
        :return: Dictionary con resultado de la operación
        """
        try:
            # Validar parámetros
            if not rate or rate <= 0:
                raise ValidationError("El rate debe ser un número positivo.")
            
            # Procesar fecha
            if date_eval:
                if isinstance(date_eval, str):
                    try:
                        eval_date = fields.Date.from_string(date_eval)
                    except ValueError:
                        raise ValidationError("Formato de fecha inválido. Use YYYY-MM-DD.")
                else:
                    eval_date = fields.Date.to_date(date_eval)
            else:
                eval_date = fields.Date.today()
            
            _logger.info(f"Setting rate {rate} for currency {self.name} on date {eval_date}")
            
            # Buscar rate existente para esta fecha y moneda
            existing_rate = self.env['res.currency.rate'].search([
                ('currency_id', '=', self.id),
                ('name', '=', eval_date),
                ('company_id', '=', self.env.company.id)
            ], limit=1)
            
            if existing_rate:
                if existing_rate.rate == rate:
                    rate_history = self.env['res.currency.rate.history'].search([
                        ('currency_rate_id', '=', existing_rate.id),
                        ('rate', '=', rate),
                    ], order = 'id desc', limit = 1)
                    if rate_history:
                        return rate_history
                
                # Actualizar rate existente
                old_rate = existing_rate.rate
                existing_rate.write({
                    'rate': rate,
                    'engine': engine
                })
                
                rate_id = existing_rate.id
                _logger.info(f"Updated existing rate: {old_rate} -> {rate}")
            else:
                # Crear nuevo rate
                new_rate = self.env['res.currency.rate'].create({
                    'currency_id': self.id,
                    'company_id': self.env.company.id,
                    'name': eval_date,
                    'rate': rate,
                    'engine': engine
                })
                
                rate_id = new_rate.id
                _logger.info(f"Created new rate: {rate}")

            rate_history = self.env['res.currency.rate.history'].search([
                ('currency_rate_id', '=', rate_id),
                ('rate', '=', rate),
            ], order = 'id desc', limit = 1)
            
            return rate_history
            
        except Exception as e:
            _logger.error(f"Error setting currency rate: {str(e)}")
            traceback.print_exc()
        
        return None
