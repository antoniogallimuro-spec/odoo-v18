from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class ResCurrencyRate(models.Model):
    _inherit = 'res.currency.rate'

    # Relación one-to-many inversa (un2muchos)
    rate_history_ids = fields.One2many(
        'res.currency.rate.history',
        'currency_rate_id',
        string='Histórico de Actualizaciones',
        help='Registro de todas las actualizaciones de esta tasa de cambio'
    )

    rate_history_count = fields.Integer(
        string='Cantidad de Actualizaciones',
        compute='_compute_rate_history_count',
        store=False
    )

    @api.depends('rate_history_ids')
    def _compute_rate_history_count(self):
        """Contar la cantidad de actualizaciones"""
        for record in self:
            record.rate_history_count = len(record.rate_history_ids)

    def _create_history_record(self, operation_type, engine=None):
        """Crear registro en el historial"""
        if not operation_type:
            engine_final = f"{engine}_{operation_type}"
        else:
            engine_final = engine
        engine = engine or self.current_engine or 'MANUAL_UPDATE'
        history_vals = {
            'currency_rate_id': self.id,
            'time': fields.Datetime.now(),
            'rate': self.rate,
            'engine': engine_final,
        }
        history_record = self.env['res.currency.rate.history'].create(history_vals)
        
        # Asociar el historial al rate actual
        self.write({
            'rate_history_ids': [(4, history_record.id)]
        })
        return history_record

    @api.model
    def create(self, vals):
        operation_type='CREATE'
        engine='MANUAL_CREATE'

        _logger.info(f"[create] init")
        _logger.info(vals)
        if "engine" in vals:
            operation_type = vals["engine"]
            del vals["engine"]
            _logger.info(f"engine: {engine}")
        if "operation_type" in vals:
            operation_type = vals["operation_type"]
            del vals["operation_type"]
            _logger.info(f"operation_type: {operation_type}")

        # Crear el rate primero
        rate = super().create(vals)
        _logger.info("[create] super")
        
        # Crear registro en el historial
        if rate:
            rate._create_history_record(operation_type, engine)
        _logger.info(f"[create] Fin")
        return rate
    
    def write(self, vals):
        operation_type='CREATE'
        engine='MANUAL_CREATE'

        _logger.info(f"[create] init")
        _logger.info(vals)
        if "engine" in vals:
            operation_type = vals["engine"]
            del vals["engine"]
            _logger.info(f"engine: {engine}")
        if "operation_type" in vals:
            operation_type = vals["operation_type"]
            del vals["operation_type"]
            _logger.info(f"operation_type: {operation_type}")
        # Verificar si el rate está cambiando
        _logger.info("[write]")
        rate_changed = 'rate' in vals
        
        # Guardar el rate anterior para comparación
        old_rates = {r.id: r.rate for r in self} if rate_changed else {}
        
        # Ejecutar el write original
        result = super().write(vals)
        
        # Crear historial solo si el rate cambió
        if rate_changed:
            for record in self:
                old_rate = old_rates.get(record.id)
                new_rate = record.rate
                
                # Solo crear historial si el rate realmente cambió
                if old_rate != new_rate:
                    record._create_history_record(operation_type, engine)
        
        return result

    def action_view_rate_updates(self):
        """Acción para abrir la vista de actualizaciones filtrada por esta tasa"""
        self.ensure_one()
        
        return {
            'type': 'ir.actions.act_window',
            'name': f'Actualizaciones de {self.name}',
            'res_model': 'res.currency.rate.history',
            'view_mode': 'tree,form',
            'domain': [('currency_rate_id', '=', self.id)],
            'context': {
                'default_currency_rate_id': self.id,
                'search_default_currency': True,
            },
            'target': 'current',
        }

    def get_rate_history(self):
        self.ensure_one()
        
        rate_history = self.env['res.currency.rate.history'].search([
                ('currency_rate_id', '=', self.id),
                ('rate', '=', self.rate),
            ], order = 'id desc', limit = 1)

        return rate_history
