{
    'name': 'Technik - Currency Rate Updates',
    'version': '18.0.1.0.0',
    'category': 'Accounting',
    'summary': 'Registro historico de cambios de rate',
    'description': """
        Modulo encargado de registar historico de cambios en el 
        rate de las monedas del sistema
    """,
    'author': 'shinseiki.nge@gmail.com',
    'website': 'https://fya.pe',
    'depends': ['base', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/res_currency_rate_history_views.xml',
        'views/res_currency_rate_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
