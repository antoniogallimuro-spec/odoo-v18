# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
import base64
import logging

_logger = logging.getLogger(__name__)


class PleReport06(models.Model):
    _name = 'ple.report.06'
    _description = 'PLE 6.1 - Libro Mayor'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc, month desc'

    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company,
        tracking=True
    )
    year = fields.Integer(
        string='Año',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True
    )
    month = fields.Selection([
        ('01', 'Enero'),
        ('02', 'Febrero'),
        ('03', 'Marzo'),
        ('04', 'Abril'),
        ('05', 'Mayo'),
        ('06', 'Junio'),
        ('07', 'Julio'),
        ('08', 'Agosto'),
        ('09', 'Septiembre'),
        ('10', 'Octubre'),
        ('11', 'Noviembre'),
        ('12', 'Diciembre'),
    ], string='Mes', required=True, tracking=True)

    period = fields.Char(
        string='Período',
        compute='_compute_period',
        store=True,
        help='Formato AAAAMM00'
    )

    date_from = fields.Date(
        string='Fecha Inicio',
        required=True,
        tracking=True
    )
    date_to = fields.Date(
        string='Fecha Fin',
        required=True,
        tracking=True
    )

    state = fields.Selection([
        ('draft', 'Borrador'),
        ('generated', 'Generado'),
        ('published', 'Publicado')
    ], string='Estado', default='draft', required=True, tracking=True)

    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True
    )
    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True
    )

    # Líneas de detalle
    line_06_01_ids = fields.One2many(
        'ple.line.06.01',
        'report_id',
        string='Libro Mayor 6.1'
    )

    # Campos computados
    line_count_06_01 = fields.Integer(
        string='Líneas Mayor',
        compute='_compute_line_counts'
    )

    # Archivos generados
    txt_file_06_01 = fields.Binary(
        string='Archivo TXT 06.01',
        readonly=True
    )
    txt_filename_06_01 = fields.Char(
        string='Nombre Archivo 06.01',
        readonly=True
    )

    @api.depends('year', 'month')
    def _compute_name(self):
        for record in self:
            month_name = dict(self._fields['month'].selection).get(record.month, '')
            record.name = f"PLE 6.1 - {record.year} - {month_name}"

    @api.depends('year', 'month')
    def _compute_period(self):
        for record in self:
            if record.year and record.month:
                record.period = f"{record.year}{record.month}00"
            else:
                record.period = False

    @api.depends('line_06_01_ids')
    def _compute_line_counts(self):
        for record in self:
            record.line_count_06_01 = len(record.line_06_01_ids)

    @api.onchange('year', 'month')
    def _onchange_period_dates(self):
        """Calcula automáticamente las fechas inicio y fin del período"""
        if self.year and self.month:
            month_int = int(self.month)
            self.date_from = datetime(self.year, month_int, 1).date()

            # Último día del mes
            if month_int == 12:
                next_month = datetime(self.year + 1, 1, 1)
            else:
                next_month = datetime(self.year, month_int + 1, 1)

            from datetime import timedelta
            self.date_to = (next_month - timedelta(days=1)).date()

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for record in self:
            if record.date_from and record.date_to and record.date_from > record.date_to:
                raise ValidationError(_('La fecha de inicio no puede ser mayor a la fecha fin.'))

    def action_generate(self):
        """Genera las líneas del reporte PLE según el período seleccionado"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError(_('Solo se pueden generar reportes en estado Borrador.'))

        # Limpiar líneas existentes
        self.line_06_01_ids.unlink()

        # Obtener líneas de asientos contables en el rango de fechas
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('parent_state', '=', 'posted'),  # Solo asientos contabilizados
        ]

        move_lines = self.env['account.move.line'].search(domain, order='account_id, date, move_id')

        # Generar líneas del Libro Mayor agrupadas por cuenta
        line_vals = []
        for move_line in move_lines:
            line_vals.append({
                'report_id': self.id,
                'move_line_id': move_line.id,
            })

        if line_vals:
            self.env['ple.line.06.01'].create(line_vals)

        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _('Se han generado %s líneas del Libro Mayor.') % len(line_vals),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_publish(self):
        """Publica el reporte generando los archivos TXT"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError(_('Solo se pueden publicar reportes en estado Generado.'))

        # Generar archivo TXT
        if self.line_06_01_ids:
            self._generate_txt_06_01()

        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now()
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('El archivo TXT ha sido generado correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_back_to_draft(self):
        """Regresa el reporte a estado borrador"""
        self.ensure_one()
        self.write({'state': 'draft'})

    def _generate_txt_06_01(self):
        """Genera el archivo TXT según formato PLE 6.1"""
        self.ensure_one()

        if not self.line_06_01_ids:
            return

        # RUC de la compañía
        ruc = self.company_id.vat or '00000000000'

        # Formato: LERRRRRRRRRRRAAAAMMDD000601EEEEOIM1.txt
        establecimiento = '0000'
        oim = '1'  # 1=Operaciones normales, Moneda=1 (soles)

        filename = f"LE{ruc}{self.period}00000601{establecimiento}{oim}1.txt"

        # Generar contenido
        lines = []
        for line in self.line_06_01_ids:
            lines.append(line._format_txt_line())

        content = '\n'.join(lines)

        # Guardar archivo
        self.txt_file_06_01 = base64.b64encode(content.encode('utf-8'))
        self.txt_filename_06_01 = filename

    def action_view_lines_06_01(self):
        """Abre vista de líneas del Libro Mayor"""
        self.ensure_one()

        return {
            'name': _('Libro Mayor 6.1 - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.06.01',
            'view_mode': 'tree,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id}
        }
