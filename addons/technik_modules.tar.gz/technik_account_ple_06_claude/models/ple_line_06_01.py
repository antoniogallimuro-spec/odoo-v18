# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0601(models.Model):
    _name = 'ple.line.06.01'
    _description = 'PLE 6.1 - Libro Mayor'
    _order = 'account_code, operation_date, entry_number'

    report_id = fields.Many2one(
        'ple.report.06',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    # Campos según formato SUNAT para 6.1
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAAMM00'
    )

    account_code = fields.Char(
        string='Código de Cuenta',
        required=True,
        help='Código de la cuenta contable desagregado al máximo dígito'
    )

    account_name = fields.Char(
        string='Denominación de Cuenta',
        required=True,
        help='Nombre de la cuenta contable'
    )

    operation_date = fields.Date(
        string='Fecha de la Operación',
        required=True
    )

    entry_number = fields.Char(
        string='Número Correlativo del Asiento',
        required=True,
        help='Código del asiento contable'
    )

    description = fields.Text(
        string='Glosa o Descripción',
        help='Descripción de la operación'
    )

    debit = fields.Monetary(
        string='Debe',
        currency_field='company_currency_id',
        default=0.0
    )

    credit = fields.Monetary(
        string='Haber',
        currency_field='company_currency_id',
        default=0.0
    )

    balance_debit = fields.Monetary(
        string='Saldo Deudor',
        currency_field='company_currency_id',
        compute='_compute_balances',
        store=True,
        help='Saldo acumulado deudor de la cuenta'
    )

    balance_credit = fields.Monetary(
        string='Saldo Acreedor',
        currency_field='company_currency_id',
        compute='_compute_balances',
        store=True,
        help='Saldo acumulado acreedor de la cuenta'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación con línea de asiento contable de Odoo
    move_line_id = fields.Many2one(
        'account.move.line',
        string='Línea de Asiento',
        help='Línea del asiento contable de Odoo'
    )

    move_id = fields.Many2one(
        'account.move',
        string='Asiento Contable',
        related='move_line_id.move_id',
        store=True,
        readonly=True
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.depends('account_code', 'operation_date', 'debit', 'credit')
    def _compute_balances(self):
        """Calcula los saldos deudores y acreedores acumulados por cuenta"""
        for line in self:
            if not line.report_id or not line.account_code:
                line.balance_debit = 0.0
                line.balance_credit = 0.0
                continue

            # Obtener todas las líneas anteriores de la misma cuenta en orden cronológico
            previous_lines = self.search([
                ('report_id', '=', line.report_id.id),
                ('account_code', '=', line.account_code),
                ('operation_date', '<=', line.operation_date),
                ('id', '<=', line.id),
            ], order='operation_date, id')

            # Calcular saldo acumulado
            total_debit = sum(previous_lines.mapped('debit'))
            total_credit = sum(previous_lines.mapped('credit'))

            balance = total_debit - total_credit

            if balance >= 0:
                line.balance_debit = balance
                line.balance_credit = 0.0
            else:
                line.balance_debit = 0.0
                line.balance_credit = abs(balance)

    @api.onchange('move_line_id')
    def _onchange_move_line_id(self):
        """Auto-completar campos desde la línea de asiento"""
        if self.move_line_id:
            line = self.move_line_id
            move = line.move_id

            # Datos del asiento
            self.entry_number = move.name
            self.operation_date = move.date
            self.description = line.name or move.ref or move.narration or ''

            # Datos de la cuenta
            if line.account_id:
                self.account_code = line.account_id.code
                self.account_name = line.account_id.name

            # Montos
            self.debit = line.debit
            self.credit = line.credit

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 6.1

        Estructura:
        1. Periodo (8) - AAAAMM00
        2. Código de Cuenta
        3. Denominación de Cuenta
        4. Fecha de la Operación (10) - DD/MM/AAAA
        5. Número Correlativo del Asiento
        6. Glosa o Descripción
        7. Debe (decimal)
        8. Haber (decimal)
        9. Saldo Deudor (decimal)
        10. Saldo Acreedor (decimal)
        11. Estado (1)

        Separador: |
        """
        self.ensure_one()

        # Formatear fecha
        date_str = self.operation_date.strftime('%d/%m/%Y') if self.operation_date else ''

        # Formatear montos
        debit_str = f"{self.debit:.2f}" if self.debit else "0.00"
        credit_str = f"{self.credit:.2f}" if self.credit else "0.00"
        balance_debit_str = f"{self.balance_debit:.2f}" if self.balance_debit else "0.00"
        balance_credit_str = f"{self.balance_credit:.2f}" if self.balance_credit else "0.00"

        # Construir línea
        line_parts = [
            self.period or '',                      # 1. Periodo
            self.account_code or '',                # 2. Código Cuenta
            self.account_name or '',                # 3. Denominación Cuenta
            date_str,                               # 4. Fecha Operación
            self.entry_number or '',                # 5. Número Correlativo Asiento
            self.description or '',                 # 6. Glosa
            debit_str,                              # 7. Debe
            credit_str,                             # 8. Haber
            balance_debit_str,                      # 9. Saldo Deudor
            balance_credit_str,                     # 10. Saldo Acreedor
            self.state_code or '1',                 # 11. Estado
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.account_code or ''}] {line.account_name or ''}"
            if line.balance_debit:
                name += f" - Saldo D: {line.company_currency_id.symbol} {line.balance_debit:,.2f}"
            if line.balance_credit:
                name += f" - Saldo H: {line.company_currency_id.symbol} {line.balance_credit:,.2f}"
            result.append((line.id, name))
        return result
