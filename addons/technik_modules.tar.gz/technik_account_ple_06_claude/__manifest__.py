# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 6.0 - Libro Mayor',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 6.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 6.0 - Libro Mayor para Odoo 18
===================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 6.0
correspondiente al Libro Mayor según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 6.0 por período mensual
* Formato 6.1: Libro Mayor
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos mensuales
* Integración completa con plan contable y asientos contables
* Cálculo automático de saldos deudores y acreedores

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período mensual
3. Generar: Obtiene los movimientos agrupados por cuenta contable
4. Publicar: Genera el archivo TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 06.01: Libro Mayor

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}000601{ESTABLECIMIENTO}{OIM}1.txt

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAAMM00 (año, mes y 00)
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro 6.1:
-------------------------
1. Período (AAAAMM00)
2. Código de la Cuenta Contable
3. Denominación de la Cuenta Contable
4. Fecha de la Operación
5. Número Correlativo del Asiento
6. Glosa o Descripción de la Operación
7. Debe
8. Haber
9. Saldo Deudor
10. Saldo Acreedor
11. Estado de la Operación

Diferencias con el Libro Diario:
---------------------------------
El Libro Mayor agrupa todas las operaciones por cuenta contable, mostrando el saldo
acumulado de cada cuenta. Mientras que el Libro Diario muestra los asientos completos,
el Libro Mayor se enfoca en el movimiento de cada cuenta individual.

Obligados a llevar este libro:
-------------------------------
- PRICOS (Principales Contribuyentes)
- Contribuyentes que opten voluntariamente por llevarlo

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_06_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
