from . import res_config_settings

from odoo import models, fields

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    technik_cts_decolecta_token = fields.Char(
        string='Token DeColecta',
        config_parameter='technik_cts_decolecta_token',
        groups='base.group_system',
    )
