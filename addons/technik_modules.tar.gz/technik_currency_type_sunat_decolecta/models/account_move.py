from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class AccountMove(models.Model):
    _inherit = 'account.move'
    
    rate_history_id = fields.Many2one(
        'res.currency.rate.history',
        string='Historial de Tipo de Cambio',
        readonly=True,
        copy=False,
        help='Referencia al tipo de cambio aplicado en esta factura'
    )

    rate_history_amount = fields.Float(
        string='Tipo de Cambio',
        store=True,
        digits=(12, 6),
        compute="_compute_history_amount",
    )

    rate_history_inverse_amount = fields.Float(
        string='Tipo de Cambio inverso',
        store=True,
        digits=(12, 6),
        compute="_compute_inverse_history_amount",
    )

    def _compute_decolecta(self, move):
        usd_venta = None
        if move.currency_id and move.currency_id.name == 'USD':
            if not usd_venta:
                usd_venta = move.currency_id
                _logger.info("[create] Llamando DECOLECTA")
                move.currency_id.get_sunat_exchange_rate_decolecta()
            
            _logger.info("[create] Llamando get_currency_rate")
            currency_rate = usd_venta.get_currency_rate()
            if not currency_rate:
                return

            _logger.info("[create] Llamando get_rate_history")
            rate_history = currency_rate.get_rate_history()
            if not rate_history:
                return

            move.rate_history_id = rate_history.id
            _logger.info("[create] Update line_ids")
            for line in move.line_ids:
                line.rate_history_id = rate_history.id

    @api.model_create_multi
    def create(self, vals_list):
        _logger.info("[create] Llamando DECOLECTA")

        moves = super().create(vals_list)
        
        for move in moves:
            usd_venta = None
            if move.currency_id and move.currency_id.name == 'USD':
                if not usd_venta:
                    usd_venta = move.currency_id
                    _logger.info("[create] Llamando DECOLECTA")
                    move.currency_id.get_sunat_exchange_rate_decolecta()
                
                _logger.info("[create] Llamando get_currency_rate")
                currency_rate = usd_venta.get_currency_rate()
                if not currency_rate:
                    continue

                _logger.info("[create] Llamando get_rate_history")
                rate_history = currency_rate.get_rate_history()
                if not rate_history:
                    continue

                move.rate_history_id = rate_history.id
                _logger.info("[create] Update line_ids")
                for line in move.line_ids:
                    line.rate_history_id = rate_history.id
        _logger.info("[create] Fin")

        return moves
    
    def write(self, vals_list):
        _logger.info("[Write] Override")
        _logger.info(vals_list)
        _logger.info(self["state"])
        if self["state"] == 'draft' and 'currency_id' in vals_list:
            _logger.info("[Write] t Llamando DECOLECTA if USD")
            currency = self.env['res.currency'].browse(vals_list['currency_id'])
            if currency.name == 'USD':
                _logger.info("[Write] Llamando DECOLECTA")
                currency.get_sunat_exchange_rate_decolecta()

                _logger.info("[Write] Llamando get_currency_rate")
                currency_rate = currency.get_currency_rate()
                if currency_rate:
                    _logger.info("[Write] Llamando get_rate_history")
                    rate_history = currency_rate.get_rate_history()
                    if rate_history:
                        vals_list['rate_history_id'] = rate_history.id
                        _logger.info("[Write] Update line_ids")
                        for line in self.line_ids:
                            line.rate_history_id = rate_history.id

        result = super().write(vals_list)
        return result
    
    @api.depends("rate_history_id", "rate_history_id.currency_rate_id")
    def _compute_history_amount(self):
        for move in self:
            if move.rate_history_id and move.rate_history_id.currency_rate_id:
                move.rate_history_amount = move.rate_history_id.currency_rate_id.company_rate
    
    @api.depends("rate_history_id", "rate_history_id.currency_rate_id")
    def _compute_inverse_history_amount(self):
        for move in self:
            if move.rate_history_id and move.rate_history_id.currency_rate_id:
                move.rate_history_inverse_amount = move.rate_history_id.currency_rate_id.inverse_company_rate


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'
    
    rate_history_id = fields.Many2one(
        'res.currency.rate.history',
        string='Historial de Tipo de Cambio',
        readonly=True,
        copy=False,
        help='Referencia al tipo de cambio aplicado en esta línea'
    )

    rate_history_amount = fields.Float(
        string='Tipo de Cambio',
        digits=(12, 6),
        store=True,
        compute="_compute_history_amount",
    )

    rate_history_inverse_amount = fields.Float(
        string='Tipo de Cambio inverso',
        store=True,
        digits=(12, 6),
        compute="_compute_inverse_history_amount",
    )

    def _get_rate_history_from_move(self):
        for line in self:
            if line.move_id and line.move_id.rate_history_id:
                if not line.rate_history_id:
                    line.rate_history_id = line.move_id.rate_history_id.id
    
    @api.depends("rate_history_id")
    def _compute_history_amount(self):
        for line in self:
            if line.rate_history_id and line.move_id:
                _logger.info(line.move_id)
                move = self.env['account.move'].browse(line.move_id.id)
                line.rate_history_amount = move.rate_history_amount
    
    @api.depends("rate_history_id")
    def _compute_inverse_history_amount(self):
        for line in self:
            if line.rate_history_id and line.move_id:
                line.rate_history_inverse_amount = line.move_id.rate_history_inverse_amount
