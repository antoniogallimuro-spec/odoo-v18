import requests
import json
from datetime import datetime
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import logging

_logger = logging.getLogger(__name__)


class ResCurrency(models.Model):
    _inherit = 'res.currency'

    def get_sunat_exchange_rate_decolecta(self):
        """
        Obtiene el tipo de cambio SUNAT desde la API de DeColecta
        y crea/actualiza el registro en res.currency.rate
        """
        self.ensure_one()
        
        token = self.env['ir.config_parameter'].sudo().get_param(
            'technik_cts_decolecta_token',
            default=''
        )
        
        if not token:
            raise UserError(
                _('Token de DeColecta no configurado. '
                  'Por favor configure el token en Configuración del Sistema.')
            )
        
        try:
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json',
            }
            
            url = 'https://api.decolecta.com/v1/tipo-cambio/sunat'
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            _logger.info(data)

            buy_price = float(data.get('buy_price', 0))
            sell_price = float(data.get('sell_price', 0))
            base_currency = data.get('base_currency', 'USD')
            quote_currency = data.get('quote_currency', 'PEN')
            rate_date = data.get('date')
            
            if not rate_date:
                raise ValidationError(
                    _('La respuesta de DeColecta no contiene fecha.')
                )

            usd_compra = self.env['res.currency'].search([
                ('currency_type', '=', 'compra'),
                ('name', '=', 'USD')
            ], limit=1)
            usd_venta = self.env['res.currency'].search([
                ('currency_type', '=', 'venta'),
                ('name', '=', 'USD')
            ], limit=1)
            
            _logger.info(usd_compra)
            _logger.info(usd_venta)
            usd_compra.set_currency_rate(1 / buy_price, None, 'SUNAT DECOLETA')
            usd_venta.set_currency_rate(1 / sell_price, None, 'SUNAT DECOLETA')
            if not usd_compra:
                raise ValidationError(
                    _('No hay moneda USD Compra.')
                )
            if not usd_venta:
                raise ValidationError(
                    _('No hay moneda USD Venta.')
                )
        except requests.exceptions.RequestException as e:
            raise UserError(
                _('Error al conectar con DeColecta API: %s') % str(e)
            )
        except (KeyError, ValueError) as e:
            raise ValidationError(
                _('Error al procesar la respuesta de DeColecta: %s') % str(e)
            )

    def action_sunat_exchange_rate_decolecta(self):
        self.get_sunat_exchange_rate_decolecta()

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Información de Moneda'),
                'message': "Actualizacion SUNAT por DECOLECTA",
                'type': 'info',
                'sticky': True,  # Permite que el usuario cierre el mensaje manualmente
            }
        }
