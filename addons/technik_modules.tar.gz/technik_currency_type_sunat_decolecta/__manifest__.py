{
    'name': 'Technik - Currency Type SUNAT DeColecta',
    'version': '18.0.1.0.0',
    'category': 'Accounting',
    'author': 'shinseiki.nge@gmail.com',
    'website': 'https://fya.pe',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'account',
        'technik_currency_type',
        'technik_currency_rate_history',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/account_move_views.xml',
        'views/res_config_settings_views.xml',
        'views/res_currency_rate_views.xml',
    ],
    'installable': True,
    'auto_install': False,
}
