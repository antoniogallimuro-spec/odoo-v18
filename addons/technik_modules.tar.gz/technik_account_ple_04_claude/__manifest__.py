# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 4.0 - Libro de Retenciones LIR',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 4.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 4.0 - Libro de Retenciones LIR para Odoo 18
================================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 4.0
correspondiente al Libro de Retenciones inciso e) y f) del Art. 34º de la Ley del
Impuesto a la Renta según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 4.0 por período mensual
* Registro de retenciones del Impuesto a la Renta
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos mensuales
* Integración completa con proveedores y pagos

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período mensual
3. Generar: Obtiene las retenciones del período
4. Publicar: Genera el archivo TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 04.01: Libro de Retenciones inciso e) y f) del Art. 34º de la LIR

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}000401{ESTABLECIMIENTO}{OIM}1.txt

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAAMM (año y mes)
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro:
--------------------
1. Período (AAAAMM)
2. Número de Asiento
3. Fecha de Retención
4. Tipo de Documento
5. Número de Documento
6. Monto Bruto
7. Monto Retenido
8. Tipo de Documento de Identidad del Beneficiario
9. Número de Documento de Identidad del Beneficiario
10. Apellidos y Nombres o Razón Social del Beneficiario
11. Glosa o Descripción de la Operación

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_04_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
