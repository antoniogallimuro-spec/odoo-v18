# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class PleLine0401(models.Model):
    _name = 'ple.line.04.01'
    _description = 'PLE 4.1 - Libro de Retenciones LIR'
    _order = 'sequence, retention_date'

    report_id = fields.Many2one(
        'ple.report.04',
        string='Reporte PLE',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10,
        help='Número de asiento correlativo'
    )

    # Campos según formato SUNAT para 4.1
    period = fields.Char(
        string='Período',
        compute='_compute_report_fields',
        store=True,
        help='Formato AAAAMM'
    )

    entry_number = fields.Char(
        string='Número de Asiento',
        required=True,
        help='Número correlativo del asiento o código único'
    )

    retention_date = fields.Date(
        string='Fecha de Retención',
        required=True,
        help='Fecha en que se efectuó la retención (coincide con fecha de pago)'
    )

    document_type_id = fields.Many2one(
        'l10n_latam.document.type',
        string='Tipo de Documento',
        required=True,
        help='Tipo de comprobante de pago'
    )

    document_number = fields.Char(
        string='Número de Documento',
        required=True,
        help='Serie y número del comprobante de pago'
    )

    gross_amount = fields.Monetary(
        string='Monto Bruto',
        currency_field='company_currency_id',
        required=True,
        help='Monto bruto sujeto a retención'
    )

    withheld_amount = fields.Monetary(
        string='Monto Retenido',
        currency_field='company_currency_id',
        required=True,
        help='Monto del impuesto retenido'
    )

    partner_id = fields.Many2one(
        'res.partner',
        string='Beneficiario',
        required=True,
        help='Proveedor o beneficiario de la retención'
    )

    partner_document_type_id = fields.Many2one(
        'l10n_latam.identification.type',
        string='Tipo Doc. Identidad',
        required=True,
        help='Tipo de documento de identidad del beneficiario'
    )

    partner_vat = fields.Char(
        string='Número Doc. Identidad',
        required=True,
        help='Número de documento de identidad del beneficiario'
    )

    partner_name = fields.Char(
        string='Razón Social / Nombre',
        required=True,
        help='Apellidos y nombres o razón social del beneficiario'
    )

    description = fields.Text(
        string='Glosa / Descripción',
        help='Descripción de la operación (máx 250 caracteres)'
    )

    state_code = fields.Selection([
        ('1', '1 - Activo'),
        ('8', '8 - Anulado'),
        ('9', '9 - Ajuste')
    ], string='Estado', default='1', required=True)

    # Campos relacionados
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    state = fields.Selection(
        related='report_id.state',
        string='Estado Reporte',
        store=True,
        readonly=True
    )

    # Relación opcional con el pago
    payment_id = fields.Many2one(
        'account.payment',
        string='Pago Relacionado',
        help='Pago asociado a la retención'
    )

    @api.depends('report_id', 'report_id.period')
    def _compute_report_fields(self):
        for line in self:
            line.period = line.report_id.period if line.report_id else False

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        """Auto-completar datos del beneficiario al seleccionar el partner"""
        if self.partner_id:
            self.partner_name = self.partner_id.name
            self.partner_vat = self.partner_id.vat or ''

            # Intentar obtener el tipo de documento
            if self.partner_id.l10n_latam_identification_type_id:
                self.partner_document_type_id = self.partner_id.l10n_latam_identification_type_id

    @api.onchange('payment_id')
    def _onchange_payment_id(self):
        """Auto-completar campos desde el pago relacionado"""
        if self.payment_id:
            payment = self.payment_id

            # Datos del partner
            if payment.partner_id:
                self.partner_id = payment.partner_id
                self.partner_name = payment.partner_id.name
                self.partner_vat = payment.partner_id.vat or ''

            # Fecha de retención (fecha de pago)
            if payment.payment_date:
                self.retention_date = payment.payment_date

            # Número de asiento
            if payment.move_id:
                self.entry_number = payment.move_id.name

            # Descripción
            if payment.ref:
                self.description = payment.ref

    def _format_txt_line(self):
        """
        Formatear línea según estructura SUNAT para PLE 4.1

        Estructura:
        1. Periodo (6) - AAAAMM
        2. Número de Asiento (varies)
        3. Fecha de Retención (10) - DD/MM/AAAA
        4. Tipo de Documento (2)
        5. Número de Documento (varies)
        6. Monto Bruto (decimal)
        7. Monto Retenido (decimal)
        8. Tipo Doc. Identidad (1)
        9. Número Doc. Identidad (varies)
        10. Apellidos y Nombres / Razón Social (varies)
        11. Glosa o Descripción (250)

        Separador: |
        """
        self.ensure_one()

        # Formatear fecha
        date_str = self.retention_date.strftime('%d/%m/%Y') if self.retention_date else ''

        # Formatear montos
        gross_str = f"{self.gross_amount:.2f}" if self.gross_amount else "0.00"
        withheld_str = f"{self.withheld_amount:.2f}" if self.withheld_amount else "0.00"

        # Obtener códigos
        doc_type_code = self.document_type_id.code if self.document_type_id else ''
        partner_doc_type = self.partner_document_type_id.l10n_pe_vat_code if self.partner_document_type_id else ''

        # Construir línea
        line_parts = [
            self.period or '',                    # 1. Periodo
            self.entry_number or '',              # 2. Número de Asiento
            date_str,                             # 3. Fecha de Retención
            doc_type_code,                        # 4. Tipo de Documento
            self.document_number or '',           # 5. Número de Documento
            gross_str,                            # 6. Monto Bruto
            withheld_str,                         # 7. Monto Retenido
            partner_doc_type,                     # 8. Tipo Doc. Identidad
            self.partner_vat or '',               # 9. Número Doc. Identidad
            self.partner_name or '',              # 10. Razón Social
            self.description or '',               # 11. Glosa
            self.state_code or '1',               # 12. Estado
        ]

        return '|'.join(line_parts) + '|'

    def name_get(self):
        """Nombre personalizado para la línea"""
        result = []
        for line in self:
            name = f"[{line.entry_number}] {line.partner_name or 'Sin nombre'}"
            if line.withheld_amount:
                name += f" - Ret: {line.company_currency_id.symbol} {line.withheld_amount:,.2f}"
            result.append((line.id, name))
        return result
