# -*- coding: utf-8 -*-

from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    l10n_pe_edi_es_agente_percepcion = fields.Boolean(
        string='Es Agente de Percepción',
        default=False,
        help='Indica si el proveedor es agente de percepción. '
             'Si es True, el proveedor nos cobra percepción. '
             'Si es False, nosotros le cobramos y debemos enviar el CPE a SUNAT.',
    )
