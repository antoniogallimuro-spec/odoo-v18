# Technik - Stock User Warehouse

## Descripción

Este módulo muestra el almacén predeterminado del usuario y la cantidad disponible en ese almacén en las vistas kanban y lista de productos.

## Características

### 1. Campos Agregados

**En `product.template`:**

- **user_warehouse_id**: Almacén predeterminado del usuario actual (computed, no almacenado)
- **user_warehouse_qty**: Cantidad disponible en el almacén del usuario (computed, no almacenado)

### 2. Vista de Lista (Tree)

En la vista de lista de productos, después de la columna "Cantidad a mano" (`qty_available`), se muestran:

- **Almacén del Usuario**: Nombre del almacén predeterminado del usuario
- **Cantidad en Almacén del Usuario**: Cantidad disponible
  - Color verde si hay stock (qty > 0)
  - Color rojo si no hay stock (qty <= 0)
  - Solo visible si el usuario tiene un almacén asignado

### 3. Vista Kanban

En las tarjetas kanban de productos, se muestra:

- Badge azul con el icono de almacén y el nombre del almacén del usuario
- Badge verde/rojo con el icono de stock y la cantidad disponible
  - Verde si hay stock disponible
  - Rojo si no hay stock
- Solo visible si el usuario tiene un almacén asignado

## Instalación

### Requisitos

- Odoo v18
- Módulos instalados:
  - `product`
  - `stock`

### Pasos de Instalación

1. Copiar el módulo a la ruta de addons:
   ```bash
   /home/shinseiki/tmp/fya/fya-git/addons-vendors/fya/technik_stock_user_wharehouse/
   ```

2. Actualizar la lista de aplicaciones:
   ```bash
   odoo -d nombre_base_datos -u all
   ```

3. Instalar el módulo desde Apps:
   - Buscar "Technik - Stock User Warehouse"
   - Hacer clic en "Instalar"

## Configuración

### Asignar Almacén a Usuarios

Para que el módulo funcione correctamente, cada usuario debe tener un almacén predeterminado asignado:

1. Ir a **Ajustes → Usuarios y Compañías → Usuarios**
2. Seleccionar un usuario
3. En la pestaña **Preferencias**, buscar el campo **Almacén predeterminado** (`property_warehouse_id`)
4. Seleccionar el almacén deseado
5. Guardar

## Uso

Una vez instalado y configurado:

### Vista de Lista

1. Ir a **Inventario → Productos → Productos**
2. En la vista de lista, verás dos columnas adicionales:
   - **Almacén del Usuario**: Muestra el almacén del usuario actual
   - **Cantidad en Almacén del Usuario**: Muestra la cantidad disponible en ese almacén

### Vista Kanban

1. Ir a **Inventario → Productos → Productos**
2. Cambiar a vista kanban
3. En cada tarjeta de producto verás:
   - Badge azul con el nombre del almacén del usuario
   - Badge verde/rojo con la cantidad disponible en ese almacén

## Cálculo de Cantidad Disponible

El módulo calcula la cantidad disponible de la siguiente manera:

1. Obtiene el almacén predeterminado del usuario actual (`env.user.property_warehouse_id`)
2. Obtiene la ubicación de stock de ese almacén (`warehouse.lot_stock_id`)
3. Busca todas las variantes del producto (`product.product_variant_ids`)
4. Suma las cantidades de todos los `stock.quant` en la ubicación del almacén y sus ubicaciones hijas
5. Retorna el total de la cantidad disponible

## Campos Técnicos

### product.template

```python
user_warehouse_id = fields.Many2one(
    'stock.warehouse',
    compute='_compute_user_warehouse',
    store=False,
)

user_warehouse_qty = fields.Float(
    compute='_compute_user_warehouse_qty',
    store=False,
    digits='Product Unit of Measure',
)
```

### Métodos Computados

**`_compute_user_warehouse()`**
- Depende del contexto del usuario (`uid`)
- Obtiene el almacén del usuario actual
- No se almacena en la base de datos

**`_compute_user_warehouse_qty()`**
- Depende de `user_warehouse_id` y `product_variant_ids.stock_quant_ids`
- Depende del contexto del usuario (`uid`)
- Calcula la suma de cantidades en el almacén del usuario
- Incluye ubicaciones hijas del almacén
- No se almacena en la base de datos

## Notas Importantes

1. **Campos Computados**: Los campos no se almacenan en la base de datos, se calculan dinámicamente
2. **Rendimiento**: El cálculo se hace solo cuando se visualizan los productos
3. **Ubicaciones Hijas**: El cálculo incluye todas las ubicaciones hijas del almacén
4. **Usuario sin Almacén**: Si el usuario no tiene almacén asignado, los campos estarán vacíos
5. **Multi-variante**: Si el producto tiene múltiples variantes, se suman las cantidades de todas

## Vistas Heredadas

### Vista de Lista
- **Vista padre**: `product.product_template_tree_view`
- **XPath**: Después de `//field[@name='qty_available']`

### Vista Kanban
- **Vista padre**: `stock.product_template_kanban_stock_view`
- **XPath**:
  - Campos: Después de `//field[@name='qty_available']`
  - Visualización: Dentro de `//div[hasclass('o_kanban_record_body')]`

## Ejemplo de Salida

### Vista de Lista
```
Producto            | Cantidad a mano | Almacén del Usuario | Cantidad en Almacén del Usuario
--------------------|-----------------|---------------------|--------------------------------
Producto A          | 150             | Almacén Principal   | 100 (verde)
Producto B          | 50              | Almacén Principal   | 0 (rojo)
Producto C          | 200             | Almacén Principal   | 75 (verde)
```

### Vista Kanban
```
┌─────────────────────────┐
│ Producto A              │
│ [Código: PA-001]        │
│                         │
│ 📦 Almacén Principal    │
│ 📊 100                  │
└─────────────────────────┘
```

## Personalización

### Cambiar Colores en Vista de Lista

Editar `views/product_views.xml`:

```xml
<field name="user_warehouse_qty"
       decoration-success="user_warehouse_qty &gt; 0"     <!-- Verde si > 0 -->
       decoration-danger="user_warehouse_qty &lt;= 0"     <!-- Rojo si <= 0 -->
       decoration-warning="user_warehouse_qty &lt; 10"    <!-- Amarillo si < 10 -->
/>
```

### Cambiar Colores en Vista Kanban

Editar `views/product_views.xml`:

```xml
<span t-attf-class="badge ms-1 {{record.user_warehouse_qty.raw_value > 0 ? 'bg-success' : 'bg-danger'}}">
    <!-- Cambiar bg-success/bg-danger por otros colores Bootstrap -->
</span>
```

## Estructura de Archivos

```
technik_stock_user_wharehouse/
├── __init__.py
├── __manifest__.py
├── README.md
├── models/
│   ├── __init__.py
│   └── product_template.py
└── views/
    └── product_views.xml
```

## Dependencias

- `product`: Modelo de productos
- `stock`: Gestión de inventario y almacenes

## Licencia

LGPL-3

## Autor

Technik

## Versión

18.0.1.0.0

## Soporte

Para problemas o consultas sobre este módulo, revisar los logs de Odoo:

```bash
tail -f /var/log/odoo/odoo-server.log | grep -i "technik_stock_user_wharehouse"
```
