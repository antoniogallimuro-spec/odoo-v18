# -*- coding: utf-8 -*-

from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    user_warehouse_id = fields.Many2one(
        'stock.warehouse',
        string='User Warehouse',
        compute='_compute_user_warehouse',
        store=False,
        help='Current user default warehouse',
    )

    user_warehouse_qty = fields.Float(
        string='Qty in User Warehouse',
        compute='_compute_user_warehouse_qty',
        store=False,
        digits='Product Unit of Measure',
        help='Available quantity in current user warehouse',
    )

    @api.depends_context('uid')
    def _compute_user_warehouse(self):
        """Get current user's default warehouse"""
        user_warehouse = self.env.user.property_warehouse_id
        for product in self:
            product.user_warehouse_id = user_warehouse

    @api.depends('user_warehouse_id', 'product_variant_ids.stock_quant_ids')
    @api.depends_context('uid')
    def _compute_user_warehouse_qty(self):
        """Calculate available quantity in user's warehouse"""
        for product in self:
            qty = 0.0
            user_warehouse = self.env.user.property_warehouse_id

            if user_warehouse:
                # Get warehouse stock location
                warehouse_location = user_warehouse.lot_stock_id

                # Get all product variants for this template
                variants = product.product_variant_ids

                if variants and warehouse_location:
                    # Get all child locations of the warehouse location
                    child_locations = self.env['stock.location'].search([
                        ('id', 'child_of', warehouse_location.id),
                        ('usage', '=', 'internal'),
                    ])

                    # Get stock quants for these variants in warehouse locations
                    quants = self.env['stock.quant'].search([
                        ('product_id', 'in', variants.ids),
                        ('location_id', 'in', child_locations.ids),
                    ])

                    # Sum all quantities
                    qty = sum(quants.mapped('quantity'))

            product.user_warehouse_qty = qty
