# -*- coding: utf-8 -*-
{
    'name': 'Technik - Stock User Warehouse',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Inventory',
    'summary': 'Show user warehouse and stock quantity in product views',
    'description': """
Technik - Stock User Warehouse
===========================

Shows user's warehouse and available stock quantity in that warehouse
in product kanban and list views.

Features:
---------
* Display user's default warehouse in product views
* Show available stock quantity for the user's warehouse
* Enhanced product kanban and list views
    """,
    'author': 'Technik',
    'depends': [
        'product',
        'stock',
    ],
    'data': [
        'views/product_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
