{
    'name': 'FyA PLE [Base] - Base Libro Electronicos',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations',
    'summary': 'Generación base de PLE para SUNAT Perú',
    'description': '''
        Módulo base para generar el Programa de Libros Electrónicos 
    ''',
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
    ],
    'data': [
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
