# -*- coding: utf-8 -*-

import base64
import logging
from copy import deepcopy
from datetime import datetime
from hashlib import sha1

from lxml import etree
from lxml import objectify
from markupsafe import Markup
from pytz import timezone
from requests.exceptions import ConnectionError as ReqConnectionError, HTTPError, ReadTimeout

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import html_escape
from odoo.tools.zeep import Client, Settings
from odoo.tools.zeep.wsse.username import UsernameToken

_logger = logging.getLogger(__name__)

DEFAULT_PE_DATE_FORMAT = '%Y-%m-%d'

# WSDL SOAP de SUNAT para Otros CPE (Retenciones / Percepciones)
SUNAT_WSDL_PROD = 'https://e-factura.sunat.gob.pe/ol-ti-itemision-otroscpe-gem/billService?wsdl'
SUNAT_WSDL_BETA = 'https://e-beta.sunat.gob.pe/ol-ti-itemision-otroscpe-gem-beta/billService?wsdl'

# Códigos de tipo de régimen de retención según SUNAT
RETENTION_REGIME_CODES = [
    ('01', 'Tasa 3%'),
    ('02', 'Tasa 6%'),
]


class AccountMove(models.Model):
    _inherit = 'account.move'

    # Campo para detectar si tiene impuesto de retención y el proveedor NO es retenedor
    l10n_pe_edi_has_retention = fields.Boolean(
        string='Tiene Retención',
        compute='_compute_l10n_pe_edi_has_retention',
        store=True,
    )

    # Campo relacionado para saber si el proveedor es agente de retención
    l10n_pe_edi_partner_es_retenedor = fields.Boolean(
        string='Proveedor es Agente de Retención',
        related='partner_id.l10n_pe_edi_es_retenedor',
        store=True,
    )

    # Monto de retención calculado
    l10n_pe_edi_retention_amount = fields.Monetary(
        string='Monto Retención',
        compute='_compute_l10n_pe_edi_retention_amount',
        store=True,
        currency_field='currency_id',
    )

    # Porcentaje de retención
    l10n_pe_edi_retention_percent = fields.Float(
        string='Porcentaje Retención',
        compute='_compute_l10n_pe_edi_retention_percent',
        store=True,
    )

    # Estado del envío a SUNAT
    l10n_pe_edi_retention_status = fields.Selection(
        selection=[
            ('to_send', 'Por Enviar'),
            ('sent', 'Enviado'),
            ('test', 'Prueba'),
        ],
        string='Estado Retención SUNAT',
        copy=False,
    )

    # Error de envío
    l10n_pe_edi_retention_error = fields.Html(
        string='Error Retención EDI',
        copy=False,
    )

    # Número de ticket de SUNAT
    l10n_pe_edi_retention_ticket_number = fields.Char(
        string='Número de Ticket Retención',
        readonly=True,
        copy=False,
    )

    # Número del comprobante de retención
    l10n_pe_edi_retention_number = fields.Char(
        string='Número Comprobante Retención',
        copy=False,
    )

    # Régimen de retención
    l10n_pe_edi_retention_regime = fields.Selection(
        selection=RETENTION_REGIME_CODES,
        string='Régimen de Retención',
        default='01',
    )

    # Campos del wizard de envío (guardados para referencia)
    l10n_pe_edi_retention_invoice_serie = fields.Char(
        string='Serie Factura Compra',
        copy=False,
        readonly=True,
    )

    l10n_pe_edi_retention_invoice_number = fields.Char(
        string='Número Factura Compra',
        copy=False,
        readonly=True,
    )

    l10n_pe_edi_retention_amount_sent = fields.Monetary(
        string='Monto Retención Enviado',
        currency_field='currency_id',
        copy=False,
        readonly=True,
    )

    # Archivos XML y ZIP del envío a SUNAT
    l10n_pe_edi_retention_xml_file = fields.Binary(
        string='XML Retención',
        copy=False,
        readonly=True,
    )
    l10n_pe_edi_retention_xml_filename = fields.Char(
        string='Nombre XML Retención',
        copy=False,
        readonly=True,
    )
    l10n_pe_edi_retention_zip_file = fields.Binary(
        string='ZIP Retención',
        copy=False,
        readonly=True,
    )
    l10n_pe_edi_retention_zip_filename = fields.Char(
        string='Nombre ZIP Retención',
        copy=False,
        readonly=True,
    )
    l10n_pe_edi_retention_cdr_file = fields.Binary(
        string='CDR Retención',
        copy=False,
        readonly=True,
    )
    l10n_pe_edi_retention_cdr_filename = fields.Char(
        string='Nombre CDR Retención',
        copy=False,
        readonly=True,
    )

    # -------------------------------------------------------------------------
    # COMPUTE METHODS
    # -------------------------------------------------------------------------

    @api.depends('move_type', 'invoice_line_ids.tax_ids', 'state', 'partner_id.l10n_pe_edi_es_retenedor')
    def _compute_l10n_pe_edi_has_retention(self):
        """
        Detecta si la factura de compra tiene impuestos del grupo RET
        y el proveedor NO es agente de retención.
        """
        for move in self:
            move.l10n_pe_edi_has_retention = False
            if move.move_type == 'in_invoice' and move.state == 'posted':
                # Verificar que el proveedor NO sea agente de retención
                if move.partner_id and not move.partner_id.l10n_pe_edi_es_retenedor:
                    retention_taxes = move.invoice_line_ids.mapped('tax_ids').filtered(
                        lambda t: t.tax_group_id and 'RET' in (t.tax_group_id.name or '').upper()
                    )
                    move.l10n_pe_edi_has_retention = bool(retention_taxes)

    @api.depends('move_type', 'invoice_line_ids.tax_ids', 'amount_total')
    def _compute_l10n_pe_edi_retention_amount(self):
        """
        Calcula el monto de retención de la factura.
        """
        for move in self:
            move.l10n_pe_edi_retention_amount = 0.0
            if move.move_type == 'in_invoice':
                for line in move.line_ids:
                    for tax_id in line.tax_ids:
                        if tax_id and tax_id.tax_group_id:
                            if 'RET' == tax_id.tax_group_id.name:
                                _logger.info(
                                    "[_compute_l10n_pe_edi_retention_amount] tax_group_id.name: %s, %s - OK",
                                    tax_id.tax_group_id.name, line.balance
                                )
                                total_amount = line.price_total / (1 - (abs(tax_id.amount) / 100))
                                total_amount = round(total_amount, line.currency_id.decimal_places)
                                tax_amount = total_amount - line.price_total
                                tax_amount = round(tax_amount, line.currency_id.decimal_places)
                                _logger.info(tax_amount)
                                move.l10n_pe_edi_retention_amount += tax_amount

    @api.depends('invoice_line_ids.tax_ids')
    def _compute_l10n_pe_edi_retention_percent(self):
        """
        Obtiene el porcentaje de retención de los impuestos.
        """
        for move in self:
            move.l10n_pe_edi_retention_percent = 0.0
            if move.move_type == 'in_invoice':
                retention_taxes = move.invoice_line_ids.mapped('tax_ids').filtered(
                    lambda t: t.tax_group_id and 'RET' in (t.tax_group_id.name or '').upper()
                )
                if retention_taxes:
                    move.l10n_pe_edi_retention_percent = abs(retention_taxes[0].amount)

    # -------------------------------------------------------------------------
    # ACTIONS
    # -------------------------------------------------------------------------

    def action_clear_retention_error(self):
        """Limpia el error de retención."""
        for record in self:
            record.l10n_pe_edi_retention_error = False

    def action_open_retention_wizard(self):
        """Abre el wizard para enviar retención a SUNAT."""
        self.ensure_one()
        return {
            'name': _('Enviar Retención a SUNAT'),
            'type': 'ir.actions.act_window',
            'res_model': 'retention.send.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'active_id': self.id,
                'active_model': 'account.move',
            },
        }

    def action_send_retention(self):
        """
        Envía el comprobante de retención a SUNAT vía SOAP.
        """
        self.ensure_one()
        self._check_retention_required_data()

        is_test_mode = self.company_id.l10n_pe_edi_test_env

        # Generar número de documento si no existe
        if not self.l10n_pe_edi_retention_number:
            sunat_sequence = self.env['ir.sequence'].search([
                ('code', '=', 'l10n_pe_edi.retention_sunat_sequence'),
                ('company_id', '=', self.company_id.id)
            ], limit=1)
            if not sunat_sequence:
                sunat_sequence = self.env['ir.sequence'].sudo().create({
                    'name': 'Retention Sunat Sequence %s' % self.company_id.name,
                    'code': 'l10n_pe_edi.retention_sunat_sequence',
                    'padding': 8,
                    'company_id': self.company_id.id,
                    'prefix': 'R001-',
                    'number_next': 1,
                })
            self.l10n_pe_edi_retention_number = sunat_sequence.next_by_id()

        # Generar y firmar XML, enviar vía SOAP
        self.l10n_pe_edi_retention_status = 'to_send'
        edi_str = self._l10n_pe_edi_create_retention_xml()
        res = self._l10n_pe_edi_send_retention_soap(edi_str)

        edi_filename = "%s-20-%s" % (self.company_id.vat, self.l10n_pe_edi_retention_number)

        # Guardar siempre el XML y ZIP (éxito o error)
        xml_document = res.get('xml_document', edi_str)
        xml_b64 = base64.b64encode(xml_document if isinstance(xml_document, bytes) else xml_document.encode('utf-8'))
        file_vals = {
            'l10n_pe_edi_retention_xml_file': xml_b64,
            'l10n_pe_edi_retention_xml_filename': '%s.xml' % edi_filename,
        }
        if res.get('zip_document'):
            file_vals['l10n_pe_edi_retention_zip_file'] = base64.b64encode(res['zip_document'])
            file_vals['l10n_pe_edi_retention_zip_filename'] = '%s.zip' % edi_filename
        if res.get('cdr'):
            cdr_data = res['cdr']
            file_vals['l10n_pe_edi_retention_cdr_file'] = base64.b64encode(
                cdr_data if isinstance(cdr_data, bytes) else cdr_data.encode('utf-8')
            )
            file_vals['l10n_pe_edi_retention_cdr_filename'] = 'cdr-%s.xml' % edi_filename
        self.write(file_vals)

        if res.get('error'):
            self.l10n_pe_edi_retention_error = res['error']
            self._save_retention_xml_attachment(edi_str, is_test=is_test_mode)
            return

        # Éxito: crear adjuntos con XML firmado y CDR
        test_suffix = ' (PRUEBA)' if is_test_mode else ''
        attachment_vals = [
            {
                'name': '%s.xml' % edi_filename,
                'res_model': self._name,
                'res_id': self.id,
                'type': 'binary',
                'raw': xml_document,
                'mimetype': 'application/xml',
                'description': _('Comprobante de Retención%s para factura %s', test_suffix, self.name),
            },
        ]
        if res.get('cdr'):
            attachment_vals.append({
                'name': 'cdr-%s.xml' % edi_filename,
                'res_model': self._name,
                'res_id': self.id,
                'type': 'binary',
                'raw': res['cdr'],
                'mimetype': 'application/xml',
                'description': _('CDR del Comprobante de Retención%s para factura %s', test_suffix, self.name),
            })

        attachments = self.env['ir.attachment'].create(attachment_vals)

        if is_test_mode:
            message = _("MODO PRUEBA (SOAP Beta): El Comprobante de Retención fue enviado y aceptado por SUNAT.")
            final_status = 'test'
        else:
            message = _("El Comprobante de Retención fue firmado exitosamente por SUNAT.")
            final_status = 'sent'

        self._message_log(body=message, attachment_ids=attachments.ids)
        self.write({
            'l10n_pe_edi_retention_error': False,
            'l10n_pe_edi_retention_status': final_status,
        })

    # -------------------------------------------------------------------------
    # VALIDATIONS
    # -------------------------------------------------------------------------

    def _check_retention_required_data(self):
        """Valida que los datos requeridos estén presentes."""
        errors = []
        self._compute_l10n_pe_edi_retention_amount()
        if not self.partner_id:
            errors.append(_('Se requiere un proveedor.'))
        if self.partner_id and self.partner_id.l10n_pe_edi_es_retenedor:
            errors.append(_('El proveedor es agente de retención. No se debe emitir CRE.'))
        if not self.partner_id.vat:
            errors.append(_('El proveedor debe tener RUC.'))
        if not self.company_id.partner_id.vat:
            errors.append(_('La empresa debe tener RUC configurado.'))
        if not self.l10n_pe_edi_has_retention:
            errors.append(_('La factura no tiene impuestos de retención.'))
        if self.l10n_pe_edi_retention_amount <= 0:
            self._compute_l10n_pe_edi_retention_amount()
            errors.append(_('El monto de retención debe ser mayor a cero.'))

        # Validar certificado digital
        company = self.company_id.sudo()
        if not company.l10n_pe_edi_certificate_id:
            errors.append(_('No se encontró certificado digital para la empresa %s.', company.display_name))

        # Validar credenciales SUNAT
        if not company.l10n_pe_edi_test_env:
            if not company.l10n_pe_edi_provider_username or not company.l10n_pe_edi_provider_password:
                errors.append(_('Se requieren las credenciales SUNAT SOL (usuario y clave).'))

        if errors:
            raise UserError('%s\n\n%s' % (_("Configuración inválida:"), '\n'.join(errors)))

    def _save_retention_xml_attachment(self, edi_str, is_test=False):
        """Guarda el XML de retención como adjunto para debug."""
        test_suffix = '-TEST' if is_test else ''
        self.env['ir.attachment'].create([
            {
                'name': '%s-20-%s%s.xml' % (self.company_id.vat, self.l10n_pe_edi_retention_number, test_suffix),
                'res_model': self._name,
                'res_id': self.id,
                'type': 'binary',
                'raw': edi_str,
                'mimetype': 'application/xml',
                'description': _('Comprobante de Retención (con error) para factura %s', self.name),
            },
        ])

    # -------------------------------------------------------------------------
    # XML GENERATION
    # -------------------------------------------------------------------------

    def _l10n_pe_edi_create_retention_xml(self):
        """Genera el XML del comprobante de retención."""
        values = self._l10n_pe_edi_get_retention_values()
        return self._l10n_pe_edi_render_retention_xml(values)

    def _l10n_pe_edi_get_retention_values(self):
        """Prepara los valores para el XML de retención."""
        self.ensure_one()

        def format_date(date):
            return date.strftime(DEFAULT_PE_DATE_FORMAT) if date else ''

        def format_float(val, digits=2):
            return '%.*f' % (digits, val)

        date_pe = datetime.now(tz=timezone('America/Lima'))

        # Obtener tasa de retención
        retention_rate = self.l10n_pe_edi_retention_percent

        # Usar monto enviado si existe, sino el calculado
        retention_amount = self.l10n_pe_edi_retention_amount_sent or self.l10n_pe_edi_retention_amount
        total_paid = self.amount_total - retention_amount

        # Construir número de factura desde serie y número del wizard si existen
        if self.l10n_pe_edi_retention_invoice_serie and self.l10n_pe_edi_retention_invoice_number:
            invoice_number = '%s-%s' % (self.l10n_pe_edi_retention_invoice_serie, self.l10n_pe_edi_retention_invoice_number)
        else:
            invoice_number = self.ref or self.name

        return {
            'record': self,
            'date_issue': date_pe.strftime(DEFAULT_PE_DATE_FORMAT),
            'time_issue': date_pe.strftime("%H:%M:%S"),
            'document_number': self.l10n_pe_edi_retention_number,
            'supplier_vat': self.partner_id.vat,
            'supplier_name': self.partner_id.name,
            'company_vat': self.company_id.partner_id.vat,
            'company_name': self.company_id.name,
            'retention_regime': self.l10n_pe_edi_retention_regime,
            'retention_rate': retention_rate,
            'retention_amount': format_float(retention_amount, 2),
            'total_paid': format_float(total_paid, 2),
            'total_retention': format_float(retention_amount, 2),
            'invoice_number': invoice_number,
            'invoice_date': format_date(self.invoice_date),
            'invoice_amount': format_float(self.amount_total, 2),
            'currency': self.currency_id.name,
            'format_float': format_float,
            'format_date': format_date,
        }

    def _l10n_pe_edi_render_retention_xml(self, values):
        """Renderiza el XML UBL 2.0 para comprobante de retención."""
        company_address = self.company_id.partner_id.street or 'Sin dirección'
        supplier_address = self.partner_id.street or 'Sin dirección'

        # Estructura XML según especificación SUNAT para CRE (código 20)
        xml_content = """<?xml version="1.0" encoding="UTF-8"?>
<Retention xmlns="urn:sunat:names:specification:ubl:peru:schema:xsd:Retention-1"
           xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
           xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
           xmlns:ds="http://www.w3.org/2000/09/xmldsig#"
           xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"
           xmlns:sac="urn:sunat:names:specification:ubl:peru:schema:xsd:SunatAggregateComponents-1">
    <ext:UBLExtensions>
        <ext:UBLExtension>
            <ext:ExtensionContent>
                <ds:Signature Id="placeholder"/>
            </ext:ExtensionContent>
        </ext:UBLExtension>
    </ext:UBLExtensions>
    <cbc:UBLVersionID>2.0</cbc:UBLVersionID>
    <cbc:CustomizationID>1.0</cbc:CustomizationID>
    <cac:Signature>
        <cbc:ID>{company_vat}</cbc:ID>
        <cac:SignatoryParty>
            <cac:PartyIdentification>
                <cbc:ID>{company_vat}</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name><![CDATA[{company_name}]]></cbc:Name>
            </cac:PartyName>
        </cac:SignatoryParty>
        <cac:DigitalSignatureAttachment>
            <cac:ExternalReference>
                <cbc:URI>#{company_vat}</cbc:URI>
            </cac:ExternalReference>
        </cac:DigitalSignatureAttachment>
    </cac:Signature>
    <cbc:ID>{document_number}</cbc:ID>
    <cbc:IssueDate>{date_issue}</cbc:IssueDate>
    <cbc:IssueTime>{time_issue}</cbc:IssueTime>
    <cac:AgentParty>
        <cac:PartyIdentification>
            <cbc:ID schemeID="6">{company_vat}</cbc:ID>
        </cac:PartyIdentification>
        <cac:PartyName>
            <cbc:Name><![CDATA[{company_name}]]></cbc:Name>
        </cac:PartyName>
        <cac:PostalAddress>
            <cbc:ID>150101</cbc:ID>
            <cbc:StreetName><![CDATA[{company_address}]]></cbc:StreetName>
            <cbc:CitySubdivisionName>NONE</cbc:CitySubdivisionName>
            <cbc:CityName>LIMA</cbc:CityName>
            <cbc:CountrySubentity>LIMA</cbc:CountrySubentity>
            <cbc:District>LIMA</cbc:District>
            <cac:Country>
                <cbc:IdentificationCode>PE</cbc:IdentificationCode>
            </cac:Country>
        </cac:PostalAddress>
        <cac:PartyLegalEntity>
            <cbc:RegistrationName><![CDATA[{company_name}]]></cbc:RegistrationName>
        </cac:PartyLegalEntity>
    </cac:AgentParty>
    <cac:ReceiverParty>
        <cac:PartyIdentification>
            <cbc:ID schemeID="6">{supplier_vat}</cbc:ID>
        </cac:PartyIdentification>
        <cac:PartyName>
            <cbc:Name><![CDATA[{supplier_name}]]></cbc:Name>
        </cac:PartyName>
        <cac:PostalAddress>
            <cbc:ID>150101</cbc:ID>
            <cbc:StreetName><![CDATA[{supplier_address}]]></cbc:StreetName>
            <cbc:CitySubdivisionName>NONE</cbc:CitySubdivisionName>
            <cbc:CityName>LIMA</cbc:CityName>
            <cbc:CountrySubentity>LIMA</cbc:CountrySubentity>
            <cbc:District>LIMA</cbc:District>
            <cac:Country>
                <cbc:IdentificationCode>PE</cbc:IdentificationCode>
            </cac:Country>
        </cac:PostalAddress>
        <cac:PartyLegalEntity>
            <cbc:RegistrationName><![CDATA[{supplier_name}]]></cbc:RegistrationName>
        </cac:PartyLegalEntity>
    </cac:ReceiverParty>
    <sac:SUNATRetentionSystemCode>{retention_regime}</sac:SUNATRetentionSystemCode>
    <sac:SUNATRetentionPercent>{retention_rate}</sac:SUNATRetentionPercent>
    <cbc:Note><![CDATA[Comprobante de Retención]]></cbc:Note>
    <cbc:TotalInvoiceAmount currencyID="{currency}">{retention_amount}</cbc:TotalInvoiceAmount>
    <sac:SUNATTotalPaid currencyID="{currency}">{total_paid}</sac:SUNATTotalPaid>
    <sac:SUNATRetentionDocumentReference>
        <cbc:ID schemeID="01">{invoice_number}</cbc:ID>
        <cbc:IssueDate>{invoice_date}</cbc:IssueDate>
        <cbc:TotalInvoiceAmount currencyID="{currency}">{invoice_amount}</cbc:TotalInvoiceAmount>
        <cac:Payment>
            <cbc:ID>1</cbc:ID>
            <cbc:PaidAmount currencyID="{currency}">{total_paid}</cbc:PaidAmount>
            <cbc:PaidDate>{date_issue}</cbc:PaidDate>
        </cac:Payment>
        <sac:SUNATRetentionInformation>
            <sac:SUNATRetentionAmount currencyID="{currency}">{retention_amount}</sac:SUNATRetentionAmount>
            <sac:SUNATRetentionDate>{date_issue}</sac:SUNATRetentionDate>
            <sac:SUNATNetTotalPaid currencyID="{currency}">{total_paid}</sac:SUNATNetTotalPaid>
            <cac:ExchangeRate>
                <cbc:SourceCurrencyCode>{currency}</cbc:SourceCurrencyCode>
                <cbc:TargetCurrencyCode>PEN</cbc:TargetCurrencyCode>
                <cbc:CalculationRate>1.000000</cbc:CalculationRate>
                <cbc:Date>{date_issue}</cbc:Date>
            </cac:ExchangeRate>
        </sac:SUNATRetentionInformation>
    </sac:SUNATRetentionDocumentReference>
</Retention>"""

        xml_formatted = xml_content.format(
            company_vat=values['company_vat'],
            company_name=values['company_name'],
            company_address=company_address,
            supplier_vat=values['supplier_vat'],
            supplier_name=values['supplier_name'],
            supplier_address=supplier_address,
            document_number=values['document_number'],
            date_issue=values['date_issue'],
            time_issue=values['time_issue'],
            retention_regime=values['retention_regime'],
            retention_rate=values['retention_rate'],
            retention_amount=values['retention_amount'],
            total_paid=values['total_paid'],
            total_retention=values['total_retention'],
            invoice_number=values['invoice_number'],
            invoice_date=values['invoice_date'],
            invoice_amount=values['invoice_amount'],
            currency=values['currency'],
        )

        return xml_formatted.encode('utf-8')

    # -------------------------------------------------------------------------
    # SOAP SENDING LOGIC
    # -------------------------------------------------------------------------

    def _l10n_pe_edi_get_retention_soap_credentials(self):
        """
        Obtiene las credenciales SOAP para el envío de retenciones a SUNAT.
        Usa el mismo patrón que account_edi_format._l10n_pe_edi_get_sunat_credentials().
        """
        company = self.company_id.sudo()
        is_test = company.l10n_pe_edi_test_env

        if is_test:
            return {
                'wsdl': SUNAT_WSDL_BETA,
                'token': UsernameToken('MODDATOS', 'MODDATOS'),
                'fault_ns': 'soap-env',
            }
        else:
            return {
                'wsdl': SUNAT_WSDL_PROD,
                'token': UsernameToken(
                    company.l10n_pe_edi_provider_username,
                    company.l10n_pe_edi_provider_password
                ),
                'fault_ns': 'soap-env',
            }

    def _l10n_pe_edi_sign_retention_xml(self, edi_str):
        """
        Firma el XML de retención con el certificado digital de la empresa.
        Reutiliza la lógica de firma de account.edi.format._l10n_pe_sign().
        """
        company = self.company_id.sudo()
        certificate = company.l10n_pe_edi_certificate_id
        if not certificate:
            return {'error': _("No se encontró certificado digital para la empresa %s.", company.display_name)}

        edi_format = self.env.ref('l10n_pe_edi.edi_pe_ubl_2_1')

        # Parsear el XML
        edi_tree = objectify.fromstring(edi_str)

        # Firmar con el certificado digital
        signed_edi_tree = edi_format._l10n_pe_sign(certificate, edi_tree)

        # Convertir a string con encoding ISO-8859-1 (requerido por SUNAT)
        signed_edi_str = etree.tostring(signed_edi_tree, xml_declaration=True, encoding='ISO-8859-1')

        return {'signed_xml': signed_edi_str}

    def _l10n_pe_edi_send_retention_soap(self, edi_str):
        """
        Firma y envía el comprobante de retención a SUNAT vía SOAP (sendBill).
        Sigue el mismo patrón que:
        account_edi_format._l10n_pe_edi_sign_service_sunat_digiflow_common()
        """
        self.ensure_one()

        # 1. Firmar el XML con certificado digital
        sign_result = self._l10n_pe_edi_sign_retention_xml(edi_str)
        if sign_result.get('error'):
            return sign_result

        signed_xml = sign_result['signed_xml']

        # 2. Comprimir en ZIP
        edi_filename = "%s-20-%s" % (self.company_id.vat, self.l10n_pe_edi_retention_number)
        edi_format = self.env.ref('l10n_pe_edi.edi_pe_ubl_2_1')
        zip_edi_str = edi_format._l10n_pe_edi_zip_edi_document([
            ('%s.xml' % edi_filename, signed_xml)
        ])

        # 3. Obtener credenciales SOAP
        credentials = self._l10n_pe_edi_get_retention_soap_credentials()

        # 4. Enviar vía SOAP sendBill
        _logger.info(
            "[Retención SOAP] Enviando CRE %s a SUNAT (WSDL: %s, test: %s)",
            edi_filename, credentials['wsdl'], self.company_id.l10n_pe_edi_test_env
        )
        try:
            settings = Settings(raw_response=True)
            client = Client(
                wsdl=credentials['wsdl'],
                wsse=credentials['token'],
                settings=settings,
                operation_timeout=15,
                timeout=15,
            )
            result = client.service.sendBill('%s.zip' % edi_filename, zip_edi_str)
            # SUNAT devuelve HTTP 500 con SOAP response si el documento ya existe
            if result.status_code != 500:
                result.raise_for_status()
        except (ReqConnectionError, HTTPError, TypeError, ReadTimeout) as e:
            _logger.error("[Retención SOAP] Error de conexión: %s", e)
            return {
                'error': '%s<br/><br/><b>%s</b><br/>%s' % (
                    _("Error de comunicación con SUNAT vía SOAP."),
                    _("Detalles:"),
                    html_escape(str(e)),
                ),
                'xml_document': signed_xml,
                'zip_document': zip_edi_str,
            }

        # 5. Decodificar la respuesta SOAP
        soap_response = result.content
        _logger.info("[Retención SOAP] HTTP Status: %s, Respuesta: %s bytes", result.status_code, len(soap_response) if soap_response else 0)

        soap_decoded = edi_format._l10n_pe_edi_decode_soap_response(soap_response) if soap_response else {}

        if soap_decoded.get('error'):
            error_msg = '%s<br/><br/><b>%s</b><br/>%s' % (
                _("Error en respuesta SOAP de SUNAT."),
                _("Código: %s", soap_decoded.get('code', 'N/A')),
                soap_decoded['error'],
            )
            _logger.warning("[Retención SOAP] Error SOAP: code=%s, error=%s", soap_decoded.get('code'), soap_decoded.get('error'))
            return {'error': error_msg, 'xml_document': signed_xml, 'zip_document': zip_edi_str}

        # 6. Validar CDR
        cdr = soap_decoded.get('cdr')
        if cdr:
            cdr_status = edi_format._l10n_pe_edi_extract_cdr_status(cdr)
            _logger.info("[Retención SOAP] CDR code=%s, description=%s", cdr_status.get('code'), cdr_status.get('description'))

            if cdr_status['code'] != '0':
                error_message = '%s<br/><br/><b>%s</b><br/>%s' % (
                    cdr_status.get('description', ''),
                    _("Código CDR: %s", cdr_status['code']),
                    _("Este documento fue registrado por SUNAT como inválido."),
                )
                return {'error': error_message, 'xml_document': signed_xml}

        return {
            'success': True,
            'xml_document': signed_xml,
            'cdr': cdr,
        }
