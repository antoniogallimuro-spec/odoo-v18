# -*- coding: utf-8 -*-

from odoo import fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    l10n_pe_edi_es_retenedor = fields.Boolean(
        string='Es Agente de Retención',
        default=False,
        help='Indica si el proveedor es agente de retención. '
             'Si es True, el proveedor nos retiene a nosotros. '
             'Si es False, nosotros le retenemos y debemos enviar el CRE a SUNAT.',
    )
