# -*- coding: utf-8 -*-
{
    'name': 'Technik - Peru EDI Retenciones',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/EDI',
    'summary': 'Envío de comprobantes de retención a SUNAT',
    'description': """
        Módulo para el envío de comprobantes de retención electrónicos a SUNAT.

        Funcionalidades:
        - Detecta facturas de compra con impuestos de retención (grupo RET)
        - Campo en proveedores para indicar si es agente de retención
        - Wizard para capturar datos antes de enviar (diario, serie, número, monto)
        - Permite enviar el comprobante de retención a SUNAT
        - Genera el XML UBL 2.0 para retenciones
        - Obtiene y almacena el CDR de respuesta
        - Soporte para modo de pruebas (usa l10n_pe_edi_test_env)
    """,
    'author': 'Technik',
    'website': '',
    'license': 'LGPL-3',
    'depends': [
        'l10n_pe_edi',
    ],
    'data': [
        'security/ir.model.access.csv',
        'wizard/retention_send_wizard_views.xml',
        'views/res_partner_views.xml',
        'views/account_move_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
