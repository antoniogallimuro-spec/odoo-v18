# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class RetentionSendWizard(models.TransientModel):
    _name = 'retention.send.wizard'
    _description = 'Wizard para enviar retención a SUNAT'

    move_id = fields.Many2one(
        'account.move',
        string='Factura',
        required=True,
        readonly=True,
    )

    journal_id = fields.Many2one(
        'account.journal',
        string='Diario Contable',
        required=True,
        domain="[('type', 'in', ['bank', 'cash'])]",
        help='Diario contable para el registro de la retención',
    )

    invoice_serie = fields.Char(
        string='Serie Factura',
        required=True,
        help='Serie de la factura de compra (ej: F001)',
    )

    invoice_number = fields.Char(
        string='Número Factura',
        required=True,
        help='Número de la factura de compra (ej: 00000123)',
    )

    retention_amount = fields.Monetary(
        string='Monto a Retener',
        required=True,
        currency_field='currency_id',
        help='Monto de la retención a aplicar',
    )

    currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='move_id.currency_id',
        readonly=True,
    )

    # Campos informativos
    partner_id = fields.Many2one(
        'res.partner',
        string='Proveedor',
        related='move_id.partner_id',
        readonly=True,
    )

    move_amount_total = fields.Monetary(
        string='Total Factura',
        related='move_id.amount_total',
        readonly=True,
    )

    suggested_retention_amount = fields.Monetary(
        string='Retención Sugerida',
        related='move_id.l10n_pe_edi_retention_amount',
        readonly=True,
    )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        active_id = self._context.get('active_id')
        if active_id:
            move = self.env['account.move'].browse(active_id)
            res['move_id'] = move.id
            res['retention_amount'] = move.l10n_pe_edi_retention_amount
            # Intentar extraer serie y número del campo ref
            if move.ref:
                parts = move.ref.split('-')
                if len(parts) >= 2:
                    res['invoice_serie'] = parts[0]
                    res['invoice_number'] = parts[1]
        return res

    def action_send_retention(self):
        """Ejecuta el envío de retención a SUNAT con los datos del wizard."""
        self.ensure_one()

        if self.retention_amount <= 0:
            raise UserError(_('El monto a retener debe ser mayor a cero.'))

        # Guardar los datos en la factura
        self.move_id.write({
            'l10n_pe_edi_retention_invoice_serie': self.invoice_serie,
            'l10n_pe_edi_retention_invoice_number': self.invoice_number,
            'l10n_pe_edi_retention_amount_sent': self.retention_amount,
        })

        # Ejecutar el envío a SUNAT
        return self.move_id.action_send_retention()
