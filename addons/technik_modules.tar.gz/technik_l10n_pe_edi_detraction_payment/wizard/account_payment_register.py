# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    # Campo para detectar si la factura tiene detracción
    l10n_pe_edi_has_detraction = fields.Boolean(
        string='Tiene Detracción',
        compute='_compute_l10n_pe_edi_has_detraction',
    )

    # Monto de detracción
    l10n_pe_edi_detraction_amount = fields.Monetary(
        string='Monto Detracción',
        currency_field='currency_id',
        compute='_compute_l10n_pe_edi_detraction_amount',
        readonly=False,
    )

    # Diario para el pago de detracción
    l10n_pe_edi_detraction_journal_id = fields.Many2one(
        'account.journal',
        string='Diario Detracción',
        domain="[('type', 'in', ['bank', 'cash']), ('company_id', '=', company_id)]",
    )

    @api.depends('line_ids')
    def _compute_l10n_pe_edi_has_detraction(self):
        """
        Calcula si la factura tiene detracción.
        """
        for wizard in self:
            wizard.l10n_pe_edi_has_detraction = False
            moves = wizard.line_ids.mapped('move_id')
            if len(moves) == 1 and moves.move_type == 'out_invoice':
                wizard.l10n_pe_edi_has_detraction = moves[0].l10n_pe_edi_has_spot

    @api.depends('line_ids')
    def _compute_l10n_pe_edi_detraction_amount(self):
        """
        Calcula el monto de detracción.
        """
        for wizard in self:
            wizard.l10n_pe_edi_detraction_amount = 0.0
            moves = wizard.line_ids.mapped('move_id')
            if len(moves) == 1 and moves.move_type == 'out_invoice':
                if moves[0].l10n_pe_edi_has_spot:
                    wizard.l10n_pe_edi_detraction_amount = moves[0].l10n_pe_edi_spot_amount

    def action_create_payments(self):
        """
        Override para crear dos pagos cuando hay detracción:
        - Pago principal (monto - detracción) en el diario normal
        - Pago detracción en el diario de detracción
        """
        # Si tiene detracción y diario de detracción seleccionado, crear dos pagos
        if self.l10n_pe_edi_has_detraction and self.l10n_pe_edi_detraction_journal_id:
            # Guardar valores originales
            original_amount = self.amount
            original_journal = self.journal_id

            # 1. Crear pago neto (monto - detracción)
            self.amount = original_amount - self.l10n_pe_edi_detraction_amount
            super().action_create_payments()

            # 2. Crear pago detracción
            self.amount = self.l10n_pe_edi_detraction_amount
            self.journal_id = self.l10n_pe_edi_detraction_journal_id
            result = super().action_create_payments()

            # Restaurar valores originales
            self.amount = original_amount
            self.journal_id = original_journal

            return result

        # Comportamiento normal
        return super().action_create_payments()
