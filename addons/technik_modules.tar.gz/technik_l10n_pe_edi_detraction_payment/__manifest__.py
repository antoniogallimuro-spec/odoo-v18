# -*- coding: utf-8 -*-
{
    'name': 'Technik Peru EDI - Pago con Detracción',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/EDI',
    'summary': 'Permite realizar pagos de facturas con detracción usando dos diarios contables',
    'description': """
Technik Peru EDI - Pago con Detracción
==================================

Al realizar un pago de una factura con detracción, permite dividir
el pago en dos diarios contables:

- Diario de pago normal: Para el monto neto
- Diario de detracción: Para el monto de la detracción

Genera dos pagos separados vinculados a la misma factura.
    """,
    'author': 'Technik',
    'website': '',
    'depends': [
        'l10n_pe_edi',
        'technik_l10n_pe_edi_detraccion_tax2digits',
    ],
    'data': [
        'security/ir.model.access.csv',
        'wizard/account_payment_register_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'LGPL-3',
}
