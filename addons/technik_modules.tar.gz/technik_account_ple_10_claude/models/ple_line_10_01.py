# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PleLine1001(models.Model):
    _name = 'ple.line.10.01'
    _description = 'PLE 10.1 - Estado de Costo de Ventas Anual'
    _order = 'report_id, sequence, id'

    report_id = fields.Many2one(
        'ple.report.10',
        string='Reporte PLE 10.0',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    period = fields.Char(
        string='Período',
        related='report_id.period',
        store=True,
        readonly=True
    )

    # Campo 2: Código del Plan de Cuentas Utilizado
    chart_account_code = fields.Char(
        string='Código Plan de Cuentas',
        size=10,
        help='Código del plan de cuentas utilizado por la empresa'
    )

    # Campo 3: Código del Catálogo del Elemento del Costo
    cost_element_code = fields.Char(
        string='Código Elemento Costo',
        size=20,
        required=True,
        help='Código del catálogo del elemento del costo'
    )

    # Campo 4: Descripción del Elemento del Costo
    cost_element_description = fields.Char(
        string='Descripción Elemento',
        size=200,
        required=True,
        help='Descripción del elemento del costo'
    )

    # Campo 5: Inventario Inicial
    initial_inventory = fields.Monetary(
        string='Inventario Inicial',
        currency_field='company_currency_id',
        help='Valor del inventario inicial del elemento'
    )

    # Campo 6: Compras y/o Producción
    purchases_production = fields.Monetary(
        string='Compras/Producción',
        currency_field='company_currency_id',
        help='Valor de las compras y/o producción del período'
    )

    # Campo 7: Otros
    others = fields.Monetary(
        string='Otros',
        currency_field='company_currency_id',
        help='Otros movimientos que afectan el costo'
    )

    # Campo 8: Total Inventario Final
    total_final_inventory = fields.Monetary(
        string='Total Inventario Final',
        currency_field='company_currency_id',
        compute='_compute_total_final_inventory',
        store=True,
        help='Suma de inventario inicial + compras/producción + otros'
    )

    # Campo 9: Inventario Final
    final_inventory = fields.Monetary(
        string='Inventario Final',
        currency_field='company_currency_id',
        help='Valor del inventario final del elemento'
    )

    # Campo 10: Costo de Ventas
    cost_of_sales = fields.Monetary(
        string='Costo de Ventas',
        currency_field='company_currency_id',
        compute='_compute_cost_of_sales',
        store=True,
        help='Total inventario final menos inventario final (lo que se vendió)'
    )

    # Campo 11: Costo de Producción
    production_cost = fields.Monetary(
        string='Costo de Producción',
        currency_field='company_currency_id',
        help='Costo de producción del elemento'
    )

    # Campo 12: Estado de la Operación
    state_code = fields.Char(
        string='Estado',
        size=1,
        default='1',
        help='Estado del registro (1=Activo, 8=Anulado, 9=Ajuste)'
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    @api.depends('initial_inventory', 'purchases_production', 'others')
    def _compute_total_final_inventory(self):
        """Calcula el total del inventario final"""
        for line in self:
            line.total_final_inventory = (
                line.initial_inventory +
                line.purchases_production +
                line.others
            )

    @api.depends('total_final_inventory', 'final_inventory')
    def _compute_cost_of_sales(self):
        """Calcula el costo de ventas"""
        for line in self:
            line.cost_of_sales = line.total_final_inventory - line.final_inventory

    def _format_txt_line(self):
        """
        Formatea la línea según el formato TXT de SUNAT para libro 10.1

        Estructura del registro 10.1 (12 campos):
        1. Período
        2. Código del Plan de Cuentas Utilizado
        3. Código del Catálogo del Elemento del Costo
        4. Descripción del Elemento del Costo
        5. Inventario Inicial
        6. Compras y/o Producción
        7. Otros
        8. Total Inventario Final
        9. Inventario Final
        10. Costo de Ventas
        11. Costo de Producción
        12. Estado de la Operación
        """
        self.ensure_one()

        # Formatear montos con 2 decimales
        def format_amount(amount):
            return f"{amount:.2f}" if amount else '0.00'

        line_parts = [
            self.period or '',                                  # 1. Período
            self.chart_account_code or '',                      # 2. Código Plan Cuentas
            self.cost_element_code or '',                       # 3. Código Elemento Costo
            self.cost_element_description or '',                # 4. Descripción
            format_amount(self.initial_inventory),              # 5. Inventario Inicial
            format_amount(self.purchases_production),           # 6. Compras/Producción
            format_amount(self.others),                         # 7. Otros
            format_amount(self.total_final_inventory),          # 8. Total Inv. Final
            format_amount(self.final_inventory),                # 9. Inventario Final
            format_amount(self.cost_of_sales),                  # 10. Costo de Ventas
            format_amount(self.production_cost),                # 11. Costo de Producción
            self.state_code or '1',                             # 12. Estado
        ]

        return '|'.join(line_parts) + '|'
