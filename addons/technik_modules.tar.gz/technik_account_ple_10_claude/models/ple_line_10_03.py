# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PleLine1003(models.Model):
    _name = 'ple.line.10.03'
    _description = 'PLE 10.3 - Estado de Costo de Producción Valorizado Anual'
    _order = 'report_id, sequence, id'

    report_id = fields.Many2one(
        'ple.report.10',
        string='Reporte PLE 10.0',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    period = fields.Char(
        string='Período',
        related='report_id.period',
        store=True,
        readonly=True
    )

    # Campo 2: Código del Catálogo Utilizado
    catalog_code = fields.Char(
        string='Código Catálogo',
        size=10,
        help='Código del catálogo utilizado'
    )

    # Campo 3: Código del Proceso Productivo
    process_code = fields.Char(
        string='Código Proceso',
        size=20,
        required=True,
        help='Código del proceso productivo'
    )

    # Campo 4: Descripción del Proceso Productivo
    process_description = fields.Char(
        string='Descripción Proceso',
        size=200,
        required=True,
        help='Descripción del proceso productivo'
    )

    # Campo 5: Código del Producto
    product_code = fields.Char(
        string='Código Producto',
        size=20,
        help='Código del producto resultante del proceso'
    )

    # Campo 6: Descripción del Producto
    product_description = fields.Char(
        string='Descripción Producto',
        size=200,
        required=True,
        help='Descripción del producto resultante'
    )

    # Campo 7: Unidad de Medida
    uom_code = fields.Char(
        string='Unidad de Medida',
        size=10,
        help='Código de la unidad de medida del producto'
    )

    # Campo 8: Inventario Inicial en Proceso
    initial_wip_inventory = fields.Monetary(
        string='Inventario Inicial WIP',
        currency_field='company_currency_id',
        help='Valor del inventario inicial en proceso (Work In Process)'
    )

    # Campo 9: Consumo en el Proceso
    process_consumption = fields.Monetary(
        string='Consumo en Proceso',
        currency_field='company_currency_id',
        help='Valor del consumo de materiales y recursos en el proceso'
    )

    # Campo 10: Costo de Producción Proceso
    process_production_cost = fields.Monetary(
        string='Costo Producción Proceso',
        currency_field='company_currency_id',
        compute='_compute_process_production_cost',
        store=True,
        help='Inventario inicial WIP + Consumo en proceso'
    )

    # Campo 11: Inventario Final en Proceso
    final_wip_inventory = fields.Monetary(
        string='Inventario Final WIP',
        currency_field='company_currency_id',
        help='Valor del inventario final en proceso'
    )

    # Campo 12: Costo de Producción de Productos Terminados
    finished_production_cost = fields.Monetary(
        string='Costo Producción Terminados',
        currency_field='company_currency_id',
        compute='_compute_finished_production_cost',
        store=True,
        help='Costo de producción menos inventario final WIP'
    )

    # Campo 13: Estado de la Operación
    state_code = fields.Char(
        string='Estado',
        size=1,
        default='1',
        help='Estado del registro (1=Activo, 8=Anulado, 9=Ajuste)'
    )

    # Relación opcional con orden de manufactura
    mrp_production_id = fields.Many2one(
        'mrp.production',
        string='Orden de Manufactura',
        ondelete='set null',
        help='Orden de manufactura asociada a este registro'
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    @api.depends('initial_wip_inventory', 'process_consumption')
    def _compute_process_production_cost(self):
        """Calcula el costo de producción del proceso"""
        for line in self:
            line.process_production_cost = (
                line.initial_wip_inventory +
                line.process_consumption
            )

    @api.depends('process_production_cost', 'final_wip_inventory')
    def _compute_finished_production_cost(self):
        """Calcula el costo de producción de productos terminados"""
        for line in self:
            line.finished_production_cost = (
                line.process_production_cost -
                line.final_wip_inventory
            )

    def _format_txt_line(self):
        """
        Formatea la línea según el formato TXT de SUNAT para libro 10.3

        Estructura del registro 10.3 (13 campos):
        1. Período
        2. Código del Catálogo Utilizado
        3. Código del Proceso Productivo
        4. Descripción del Proceso Productivo
        5. Código del Producto
        6. Descripción del Producto
        7. Unidad de Medida
        8. Inventario Inicial en Proceso
        9. Consumo en el Proceso
        10. Costo de Producción Proceso
        11. Inventario Final en Proceso
        12. Costo de Producción de Productos Terminados
        13. Estado de la Operación
        """
        self.ensure_one()

        # Formatear montos con 2 decimales
        def format_amount(amount):
            return f"{amount:.2f}" if amount else '0.00'

        line_parts = [
            self.period or '',                                  # 1. Período
            self.catalog_code or '',                            # 2. Código Catálogo
            self.process_code or '',                            # 3. Código Proceso
            self.process_description or '',                     # 4. Descripción Proceso
            self.product_code or '',                            # 5. Código Producto
            self.product_description or '',                     # 6. Descripción Producto
            self.uom_code or '',                                # 7. Unidad de Medida
            format_amount(self.initial_wip_inventory),          # 8. Inventario Inicial WIP
            format_amount(self.process_consumption),            # 9. Consumo en Proceso
            format_amount(self.process_production_cost),        # 10. Costo Producción Proceso
            format_amount(self.final_wip_inventory),            # 11. Inventario Final WIP
            format_amount(self.finished_production_cost),       # 12. Costo Prod. Terminados
            self.state_code or '1',                             # 13. Estado
        ]

        return '|'.join(line_parts) + '|'

    @api.onchange('mrp_production_id')
    def _onchange_mrp_production_id(self):
        """Rellena campos automáticamente desde la orden de manufactura"""
        if self.mrp_production_id:
            order = self.mrp_production_id

            # Datos del proceso
            self.process_code = order.name or ''
            self.process_description = order.name or ''

            # Datos del producto
            if order.product_id:
                self.product_code = order.product_id.default_code or ''
                self.product_description = order.product_id.name or ''

            # Unidad de medida
            if order.product_uom_id:
                self.uom_code = order.product_uom_id.name or ''
