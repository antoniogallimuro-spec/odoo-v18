# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import base64
from datetime import datetime


class PleReport10(models.Model):
    _name = 'ple.report.10'
    _description = 'PLE 10.0 - Registro de Costos'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc, month desc, id desc'

    name = fields.Char(
        string='Nombre',
        required=True,
        readonly=True,
        copy=False,
        default='Nuevo',
        tracking=True
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.company,
        tracking=True
    )

    year = fields.Integer(
        string='Año',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: datetime.now().year,
        tracking=True
    )

    month = fields.Selection(
        [
            ('00', 'Anual'),
            ('01', 'Enero'),
            ('02', 'Febrero'),
            ('03', 'Marzo'),
            ('04', 'Abril'),
            ('05', 'Mayo'),
            ('06', 'Junio'),
            ('07', 'Julio'),
            ('08', 'Agosto'),
            ('09', 'Septiembre'),
            ('10', 'Octubre'),
            ('11', 'Noviembre'),
            ('12', 'Diciembre'),
        ],
        string='Mes',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default='00',
        tracking=True,
        help='Seleccione "Anual" para formatos 10.1 y 10.3, o un mes específico para formato 10.2'
    )

    period = fields.Char(
        string='Período',
        compute='_compute_period',
        store=True,
        help='Formato AAAA0000 para anual o AAAAMM00 para mensual'
    )

    date_from = fields.Date(
        string='Fecha Desde',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        tracking=True
    )

    date_to = fields.Date(
        string='Fecha Hasta',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        tracking=True
    )

    state = fields.Selection(
        [
            ('draft', 'Borrador'),
            ('generated', 'Generado'),
            ('published', 'Publicado'),
        ],
        string='Estado',
        default='draft',
        required=True,
        tracking=True
    )

    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True,
        copy=False
    )

    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True,
        copy=False
    )

    # Líneas para formato 10.1 (Estado de Costo de Ventas Anual)
    line_10_01_ids = fields.One2many(
        'ple.line.10.01',
        'report_id',
        string='Estado de Costo de Ventas Anual (10.1)',
        readonly=True,
        states={'draft': [('readonly', False)], 'generated': [('readonly', False)]}
    )

    line_count_10_01 = fields.Integer(
        string='Cantidad de Líneas 10.1',
        compute='_compute_line_counts',
        store=True
    )

    # Líneas para formato 10.2 (Elementos del Costo Mensual)
    line_10_02_ids = fields.One2many(
        'ple.line.10.02',
        'report_id',
        string='Elementos del Costo Mensual (10.2)',
        readonly=True,
        states={'draft': [('readonly', False)], 'generated': [('readonly', False)]}
    )

    line_count_10_02 = fields.Integer(
        string='Cantidad de Líneas 10.2',
        compute='_compute_line_counts',
        store=True
    )

    # Líneas para formato 10.3 (Estado de Costo de Producción Valorizado Anual)
    line_10_03_ids = fields.One2many(
        'ple.line.10.03',
        'report_id',
        string='Estado de Costo de Producción Valorizado Anual (10.3)',
        readonly=True,
        states={'draft': [('readonly', False)], 'generated': [('readonly', False)]}
    )

    line_count_10_03 = fields.Integer(
        string='Cantidad de Líneas 10.3',
        compute='_compute_line_counts',
        store=True
    )

    # Archivos TXT generados
    txt_file_10_01 = fields.Binary(
        string='Archivo TXT 10.1',
        readonly=True,
        copy=False
    )

    txt_filename_10_01 = fields.Char(
        string='Nombre Archivo TXT 10.1',
        readonly=True,
        copy=False
    )

    txt_file_10_02 = fields.Binary(
        string='Archivo TXT 10.2',
        readonly=True,
        copy=False
    )

    txt_filename_10_02 = fields.Char(
        string='Nombre Archivo TXT 10.2',
        readonly=True,
        copy=False
    )

    txt_file_10_03 = fields.Binary(
        string='Archivo TXT 10.3',
        readonly=True,
        copy=False
    )

    txt_filename_10_03 = fields.Char(
        string='Nombre Archivo TXT 10.3',
        readonly=True,
        copy=False
    )

    @api.depends('year', 'month')
    def _compute_period(self):
        """Calcula el período en formato AAAA0000 (anual) o AAAAMM00 (mensual)"""
        for record in self:
            if record.year and record.month:
                record.period = f"{record.year}{record.month}00"
            else:
                record.period = False

    @api.depends('line_10_01_ids', 'line_10_02_ids', 'line_10_03_ids')
    def _compute_line_counts(self):
        """Calcula la cantidad de líneas para cada formato"""
        for record in self:
            record.line_count_10_01 = len(record.line_10_01_ids)
            record.line_count_10_02 = len(record.line_10_02_ids)
            record.line_count_10_03 = len(record.line_10_03_ids)

    @api.onchange('year', 'month')
    def _onchange_year_month(self):
        """Actualiza las fechas según el año y mes seleccionados"""
        if self.year and self.month:
            if self.month == '00':
                # Período anual
                self.date_from = datetime(self.year, 1, 1).date()
                self.date_to = datetime(self.year, 12, 31).date()
            else:
                # Período mensual
                month_int = int(self.month)
                self.date_from = datetime(self.year, month_int, 1).date()

                # Último día del mes
                if month_int == 12:
                    next_month = datetime(self.year + 1, 1, 1)
                else:
                    next_month = datetime(self.year, month_int + 1, 1)

                from datetime import timedelta
                self.date_to = (next_month - timedelta(days=1)).date()

    @api.model_create_multi
    def create(self, vals_list):
        """Genera el nombre automáticamente al crear"""
        for vals in vals_list:
            if vals.get('name', 'Nuevo') == 'Nuevo':
                year = vals.get('year', datetime.now().year)
                month = vals.get('month', '00')
                company = self.env['res.company'].browse(
                    vals.get('company_id', self.env.company.id)
                )

                month_name = dict(self._fields['month'].selection).get(month, month)
                vals['name'] = f"PLE 10.0 - {company.name} - {year}/{month_name}"

        return super().create(vals_list)

    def action_generate(self):
        """Genera las líneas del reporte desde los movimientos de costos"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError('Solo se pueden generar reportes en estado Borrador.')

        # Eliminar líneas existentes
        self.line_10_01_ids.unlink()
        self.line_10_02_ids.unlink()
        self.line_10_03_ids.unlink()

        # Generar líneas según el período
        if self.month == '00':
            # Período anual: generar 10.1 y 10.3
            self._generate_lines_10_01()
            self._generate_lines_10_03()
        else:
            # Período mensual: generar 10.2
            self._generate_lines_10_02()

        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now(),
        })

        message = _(f'Generación completada: {self.line_count_10_01} líneas 10.1, '
                   f'{self.line_count_10_02} líneas 10.2, {self.line_count_10_03} líneas 10.3')

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': message,
                'type': 'success',
                'sticky': False,
            }
        }

    def _generate_lines_10_01(self):
        """
        Genera líneas para el formato 10.1 (Estado de Costo de Ventas Anual)

        Este formato muestra el estado de costo de ventas anual con elementos como:
        - Inventario inicial y final
        - Compras y/o producción
        - Costo de ventas y producción
        """
        self.ensure_one()

        # Este es un ejemplo básico. En una implementación real, se deberían
        # obtener los datos desde el sistema contable y de costos

        line_obj = self.env['ple.line.10.01']

        # Ejemplo: Crear líneas para elementos de costo principales
        cost_elements = [
            ('60', 'COMPRAS', 1),
            ('61', 'VARIACION DE EXISTENCIAS', 1),
            ('69', 'COSTO DE VENTAS', 1),
        ]

        for code, description, sequence in cost_elements:
            line_obj.create({
                'report_id': self.id,
                'sequence': sequence,
                'chart_account_code': code,
                'cost_element_code': code,
                'cost_element_description': description,
                'initial_inventory': 0.0,
                'purchases_production': 0.0,
                'others': 0.0,
                'total_final_inventory': 0.0,
                'final_inventory': 0.0,
                'cost_of_sales': 0.0,
                'production_cost': 0.0,
                'state_code': '1',
            })

    def _generate_lines_10_02(self):
        """
        Genera líneas para el formato 10.2 (Elementos del Costo Mensual)

        Este formato muestra mensualmente los elementos del costo:
        - Materiales y suministros directos
        - Mano de obra directa
        - Otros costos directos
        - Gastos de producción indirectos
        """
        self.ensure_one()

        line_obj = self.env['ple.line.10.02']

        # Ejemplo: Crear líneas para elementos de costo mensuales
        cost_elements = [
            ('60', 'COMPRAS', '01', 1),
            ('61', 'VARIACION DE EXISTENCIAS', '01', 2),
            ('62', 'GASTOS DE PERSONAL', '01', 3),
            ('63', 'GASTOS DE SERVICIOS', '01', 4),
        ]

        for code, description, existence_type, sequence in cost_elements:
            line_obj.create({
                'report_id': self.id,
                'sequence': sequence,
                'chart_account_code': code,
                'cost_element_code': code,
                'cost_element_description': description,
                'existence_type': existence_type,
                'direct_materials': 0.0,
                'direct_labor': 0.0,
                'other_direct_costs': 0.0,
                'indirect_production_costs': 0.0,
                'state_code': '1',
            })

    def _generate_lines_10_03(self):
        """
        Genera líneas para el formato 10.3 (Estado de Costo de Producción Valorizado Anual)

        Este formato muestra el estado de costo de producción valorizado anual:
        - Por proceso productivo
        - Por producto
        - Inventario inicial y final en proceso
        - Consumo en el proceso
        - Costo de producción
        """
        self.ensure_one()

        line_obj = self.env['ple.line.10.03']

        # Ejemplo: Obtener órdenes de manufactura del período
        mrp_orders = self.env['mrp.production'].search([
            ('company_id', '=', self.company_id.id),
            ('date_finished', '>=', self.date_from),
            ('date_finished', '<=', self.date_to),
            ('state', '=', 'done'),
        ])

        sequence = 1
        for order in mrp_orders:
            line_obj.create({
                'report_id': self.id,
                'sequence': sequence,
                'catalog_code': '01',
                'process_code': order.name or '',
                'process_description': order.name or '',
                'product_code': order.product_id.default_code or '',
                'product_description': order.product_id.name or '',
                'uom_code': order.product_uom_id.name or '',
                'initial_wip_inventory': 0.0,
                'process_consumption': 0.0,
                'process_production_cost': 0.0,
                'final_wip_inventory': 0.0,
                'finished_production_cost': 0.0,
                'state_code': '1',
                'mrp_production_id': order.id,
            })
            sequence += 1

    def action_publish(self):
        """Genera los archivos TXT y publica el reporte"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError('Solo se pueden publicar reportes en estado Generado.')

        # Generar archivos TXT según corresponda
        if self.month == '00':
            # Período anual: generar 10.1 y 10.3
            self._generate_txt_10_01()
            self._generate_txt_10_03()
        else:
            # Período mensual: generar 10.2
            self._generate_txt_10_02()

        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now(),
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def _generate_txt_10_01(self):
        """Genera el archivo TXT para formato 10.1"""
        self.ensure_one()

        ruc = self.company_id.vat or '00000000000'
        if len(ruc) < 11:
            ruc = ruc.zfill(11)

        establecimiento = '0000'
        oim = '00011'

        filename = f"LE{ruc}{self.period}001001{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_10_01_ids:
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        if not lines:
            lines.append(f"{self.period}||||||||||||1|")

        content = '\r\n'.join(lines)
        content_b64 = base64.b64encode(content.encode('utf-8'))

        self.write({
            'txt_file_10_01': content_b64,
            'txt_filename_10_01': filename,
        })

    def _generate_txt_10_02(self):
        """Genera el archivo TXT para formato 10.2"""
        self.ensure_one()

        ruc = self.company_id.vat or '00000000000'
        if len(ruc) < 11:
            ruc = ruc.zfill(11)

        establecimiento = '0000'
        oim = '00011'

        filename = f"LE{ruc}{self.period}001002{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_10_02_ids:
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        if not lines:
            lines.append(f"{self.period}||||||||||1|")

        content = '\r\n'.join(lines)
        content_b64 = base64.b64encode(content.encode('utf-8'))

        self.write({
            'txt_file_10_02': content_b64,
            'txt_filename_10_02': filename,
        })

    def _generate_txt_10_03(self):
        """Genera el archivo TXT para formato 10.3"""
        self.ensure_one()

        ruc = self.company_id.vat or '00000000000'
        if len(ruc) < 11:
            ruc = ruc.zfill(11)

        establecimiento = '0000'
        oim = '00011'

        filename = f"LE{ruc}{self.period}001003{establecimiento}{oim}1.txt"

        lines = []
        for line in self.line_10_03_ids:
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        if not lines:
            lines.append(f"{self.period}|||||||||||||1|")

        content = '\r\n'.join(lines)
        content_b64 = base64.b64encode(content.encode('utf-8'))

        self.write({
            'txt_file_10_03': content_b64,
            'txt_filename_10_03': filename,
        })

    def action_back_to_draft(self):
        """Regresa el reporte a estado Borrador"""
        self.ensure_one()

        self.write({
            'state': 'draft',
            'generation_date': False,
            'publication_date': False,
            'txt_file_10_01': False,
            'txt_filename_10_01': False,
            'txt_file_10_02': False,
            'txt_filename_10_02': False,
            'txt_file_10_03': False,
            'txt_filename_10_03': False,
        })

        return True

    def action_view_lines_10_01(self):
        """Abre la vista de líneas del formato 10.1"""
        self.ensure_one()

        return {
            'name': _('Estado de Costo de Ventas Anual (10.1)'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.10.01',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id},
        }

    def action_view_lines_10_02(self):
        """Abre la vista de líneas del formato 10.2"""
        self.ensure_one()

        return {
            'name': _('Elementos del Costo Mensual (10.2)'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.10.02',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id},
        }

    def action_view_lines_10_03(self):
        """Abre la vista de líneas del formato 10.3"""
        self.ensure_one()

        return {
            'name': _('Estado de Costo de Producción Valorizado Anual (10.3)'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.10.03',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id},
        }

    def unlink(self):
        """Evita eliminar reportes que no estén en borrador"""
        for record in self:
            if record.state != 'draft':
                raise UserError(
                    'No se pueden eliminar reportes que no estén en estado Borrador. '
                    'Primero regrese el reporte a Borrador.'
                )

        return super().unlink()
