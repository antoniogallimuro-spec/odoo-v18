# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PleLine1002(models.Model):
    _name = 'ple.line.10.02'
    _description = 'PLE 10.2 - Elementos del Costo Mensual'
    _order = 'report_id, sequence, id'

    report_id = fields.Many2one(
        'ple.report.10',
        string='Reporte PLE 10.0',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10
    )

    period = fields.Char(
        string='Período',
        related='report_id.period',
        store=True,
        readonly=True
    )

    # Campo 2: Código del Plan de Cuentas Utilizado
    chart_account_code = fields.Char(
        string='Código Plan de Cuentas',
        size=10,
        help='Código del plan de cuentas utilizado por la empresa'
    )

    # Campo 3: Código del Catálogo del Elemento del Costo
    cost_element_code = fields.Char(
        string='Código Elemento Costo',
        size=20,
        required=True,
        help='Código del catálogo del elemento del costo'
    )

    # Campo 4: Descripción del Elemento del Costo
    cost_element_description = fields.Char(
        string='Descripción Elemento',
        size=200,
        required=True,
        help='Descripción del elemento del costo'
    )

    # Campo 5: Tipo de Existencia
    existence_type = fields.Char(
        string='Tipo de Existencia',
        size=2,
        help='Código del tipo de existencia según tabla SUNAT'
    )

    # Campo 6: Materiales y Suministros Directos
    direct_materials = fields.Monetary(
        string='Materiales Directos',
        currency_field='company_currency_id',
        help='Valor de materiales y suministros directos del período'
    )

    # Campo 7: Mano de Obra Directa
    direct_labor = fields.Monetary(
        string='Mano de Obra Directa',
        currency_field='company_currency_id',
        help='Valor de mano de obra directa del período'
    )

    # Campo 8: Otros Costos Directos
    other_direct_costs = fields.Monetary(
        string='Otros Costos Directos',
        currency_field='company_currency_id',
        help='Otros costos directos del período'
    )

    # Campo 9: Gastos de Producción Indirectos
    indirect_production_costs = fields.Monetary(
        string='Gastos Indirectos',
        currency_field='company_currency_id',
        help='Gastos de producción indirectos (materiales indirectos, mano de obra indirecta, otros gastos)'
    )

    # Campo 10: Estado de la Operación
    state_code = fields.Char(
        string='Estado',
        size=1,
        default='1',
        help='Estado del registro (1=Activo, 8=Anulado, 9=Ajuste)'
    )

    # Campos calculados
    total_cost = fields.Monetary(
        string='Costo Total',
        currency_field='company_currency_id',
        compute='_compute_total_cost',
        store=True,
        help='Suma de todos los elementos de costo'
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    company_currency_id = fields.Many2one(
        'res.currency',
        string='Moneda',
        related='company_id.currency_id',
        readonly=True
    )

    @api.depends('direct_materials', 'direct_labor', 'other_direct_costs', 'indirect_production_costs')
    def _compute_total_cost(self):
        """Calcula el costo total"""
        for line in self:
            line.total_cost = (
                line.direct_materials +
                line.direct_labor +
                line.other_direct_costs +
                line.indirect_production_costs
            )

    def _format_txt_line(self):
        """
        Formatea la línea según el formato TXT de SUNAT para libro 10.2

        Estructura del registro 10.2 (10 campos):
        1. Período
        2. Código del Plan de Cuentas Utilizado
        3. Código del Catálogo del Elemento del Costo
        4. Descripción del Elemento del Costo
        5. Tipo de Existencia
        6. Materiales y Suministros Directos
        7. Mano de Obra Directa
        8. Otros Costos Directos
        9. Gastos de Producción Indirectos
        10. Estado de la Operación
        """
        self.ensure_one()

        # Formatear montos con 2 decimales
        def format_amount(amount):
            return f"{amount:.2f}" if amount else '0.00'

        line_parts = [
            self.period or '',                              # 1. Período
            self.chart_account_code or '',                  # 2. Código Plan Cuentas
            self.cost_element_code or '',                   # 3. Código Elemento Costo
            self.cost_element_description or '',            # 4. Descripción
            self.existence_type or '',                      # 5. Tipo de Existencia
            format_amount(self.direct_materials),           # 6. Materiales Directos
            format_amount(self.direct_labor),               # 7. Mano de Obra Directa
            format_amount(self.other_direct_costs),         # 8. Otros Costos Directos
            format_amount(self.indirect_production_costs),  # 9. Gastos Indirectos
            self.state_code or '1',                         # 10. Estado
        ]

        return '|'.join(line_parts) + '|'
