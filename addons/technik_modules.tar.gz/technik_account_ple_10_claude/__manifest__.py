# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 10.0 - Registro de Costos',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 10.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 10.0 - Registro de Costos para Odoo 18
==========================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 10.0
correspondiente al Registro de Costos según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 10.0 por período
* Soporte para tres formatos:
  - 10.1: Estado de Costo de Ventas Anual
  - 10.2: Elementos del Costo Mensual
  - 10.3: Estado de Costo de Producción Valorizado Anual
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Control de costos de producción y ventas
* Seguimiento de elementos del costo (materiales, mano de obra, gastos indirectos)

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período (anual para 10.1 y 10.3, mensual para 10.2)
3. Generar: Obtiene la información de costos desde el sistema
4. Publicar: Genera los archivos TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 10.01: Registro de Costos - Estado de Costo de Ventas Anual
* 10.02: Registro de Costos - Elementos del Costo Mensual
* 10.03: Registro de Costos - Estado de Costo de Producción Valorizado Anual

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}001001{ESTABLECIMIENTO}{OIM}1.txt (Formato 10.1)
LE{RUC}{PERIODO}001002{ESTABLECIMIENTO}{OIM}1.txt (Formato 10.2)
LE{RUC}{PERIODO}001003{ESTABLECIMIENTO}{OIM}1.txt (Formato 10.3)

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAA0000 para anual, AAAAMM00 para mensual
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro 10.1 (Estado de Costo de Ventas Anual):
------------------------------------------------------------
1. Período
2. Código del Plan de Cuentas Utilizado
3. Código del Catálogo del Elemento del Costo
4. Descripción del Elemento del Costo
5. Inventario Inicial
6. Compras y/o Producción
7. Otros
8. Total Inventario Final
9. Inventario Final
10. Costo de Ventas
11. Costo de Producción
12. Estado de la Operación

Campos del Registro 10.2 (Elementos del Costo Mensual):
--------------------------------------------------------
1. Período
2. Código del Plan de Cuentas Utilizado
3. Código del Catálogo del Elemento del Costo
4. Descripción del Elemento del Costo
5. Tipo de Existencia
6. Materiales y Suministros Directos
7. Mano de Obra Directa
8. Otros Costos Directos
9. Gastos de Producción Indirectos
10. Estado de la Operación

Campos del Registro 10.3 (Estado de Costo de Producción Valorizado Anual):
---------------------------------------------------------------------------
1. Período
2. Código del Catálogo Utilizado
3. Código del Proceso Productivo
4. Descripción del Proceso Productivo
5. Código del Producto
6. Descripción del Producto
7. Unidad de Medida
8. Inventario Inicial en Proceso
9. Consumo en el Proceso
10. Costo de Producción Proceso
11. Inventario Final en Proceso
12. Costo de Producción de Productos Terminados
13. Estado de la Operación

¿Qué es el Registro de Costos?
-------------------------------
El Registro de Costos es un libro auxiliar obligatorio donde las empresas manufactureras
y de servicios registran y controlan todos los elementos que forman parte del costo de
producción y del costo de ventas, permitiendo la determinación precisa del costo de los
productos fabricados y vendidos.

Obligados a llevar el Registro:
--------------------------------
- Empresas con ingresos brutos anuales mayores a 1,500 UIT
- Empresas designadas como Principales Contribuyentes (PRICOS)
- Empresas que se dedican a actividades de producción o transformación

Casos de Uso:
-------------
- Empresas manufactureras que producen bienes
- Empresas de servicios con procesos productivos
- Control y determinación del costo de producción
- Determinación del costo de ventas para efectos tributarios
- Análisis de la estructura de costos de la empresa

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'stock',
        'mrp',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_10_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
