# -*- coding: utf-8 -*-
from . import account_move
from . import account_edi_xml_ubl_pe
from . import product_template
