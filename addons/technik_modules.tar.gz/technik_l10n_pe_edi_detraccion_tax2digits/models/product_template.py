# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    l10n_pe_withhold_code = fields.Selection(
        selection='_get_l10n_pe_withhold_code_selection',
    )

    @api.model
    def _get_l10n_pe_withhold_code_selection(self):
        """
        Genera la lista de selección para el código de detracción
        desde el catálogo 54 con formato: "code - name (rate%)"
        """
        catalog = self.env['l10n_pe_edi.catalog.54'].search([], order='code')
        result = []
        for rec in catalog:
            rate_str = ('%g' % rec.rate) if rec.rate == int(rec.rate) else str(rec.rate)
            label = '%s - %s (%s%%)' % (rec.code, rec.name, rate_str)
            result.append((rec.code, label))
        return result

    @api.constrains('type', 'l10n_pe_withhold_code', 'l10n_pe_withhold_percentage')
    def _check_service_detraction_fields(self):
        """
        Valida que los productos de tipo servicio tengan configurados
        los campos de detracción (código y porcentaje).
        """
        for product in self:
            _logger.info(
                f"[_check_service_detraction_fields] product: {product.name}, "
                f"type: {product.type}, "
                f"withhold_code: {product.l10n_pe_withhold_code}, "
                f"withhold_percentage: {product.l10n_pe_withhold_percentage}"
            )
            if product.type == 'service':
                if not product.l10n_pe_withhold_code:
                    raise ValidationError(
                        _('El producto "%s" es un servicio y debe tener '
                          'configurado el Código de Detracción (l10n_pe_withhold_code).')
                        % product.name
                    )


class ProductProduct(models.Model):
    _inherit = 'product.product'

    @api.onchange('l10n_pe_withhold_code')
    def _onchange_l10n_pe_withhold_code(self):
        """
        Auto-llena el porcentaje de detracción basado en el código seleccionado.
        Busca el valor 'rate' en el modelo l10n_pe_edi.catalog.54.
        """
        _logger.info(f"[product.product l10n_pe_withhold_code] valor: {self.l10n_pe_withhold_code}")
        if self.l10n_pe_withhold_code:
            catalog_54 = self.env['l10n_pe_edi.catalog.54'].search([
                ('code', '=', self.l10n_pe_withhold_code)
            ], limit=1)
            _logger.info(catalog_54)
            if catalog_54:
                self.product_tmpl_id.l10n_pe_withhold_percentage = catalog_54.rate
                _logger.info(f"[product.product l10n_pe_withhold_code] rate: {self.product_tmpl_id.l10n_pe_withhold_percentage}")
