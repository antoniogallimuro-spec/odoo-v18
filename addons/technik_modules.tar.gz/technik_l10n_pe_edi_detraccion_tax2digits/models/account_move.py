# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


# Tipos de operación que requieren detracción
DETRACTION_OPERATION_TYPES = ['1001', '1002', '1003', '1004']


class AccountMove(models.Model):
    _inherit = 'account.move'

    # Campo para indicar si tiene detracción SPOT
    l10n_pe_edi_has_spot = fields.Boolean(
        string='Tiene Detracción SPOT',
        compute='_compute_spot_fields',
        help='Indica si la factura tiene detracción SPOT configurada',
    )

    # Campos del objeto SPOT
    l10n_pe_edi_spot_amount = fields.Monetary(
        string='Monto Detracción',
        currency_field='currency_id',
        compute='_compute_spot_fields',
        help='Monto de la detracción (spot_amount)',
    )

    l10n_pe_edi_spot_amount_signed = fields.Monetary(
        string='Monto Detracción (Firmado)',
        currency_field='company_currency_id',
        compute='_compute_spot_fields',
        help='Monto de la detracción con signo (amount)',
    )

    l10n_pe_edi_spot_payment_percent = fields.Float(
        string='Porcentaje Detracción',
        digits=(5, 2),
        compute='_compute_spot_fields',
        help='Porcentaje de la detracción (payment_percent)',
    )

    l10n_pe_edi_spot_payment_means_id = fields.Char(
        string='Código Detracción',
        compute='_compute_spot_fields',
        help='Código del bien/servicio sujeto a detracción',
    )

    l10n_pe_edi_spot_bank_account = fields.Char(
        string='Cuenta Banco Nación',
        compute='_compute_spot_fields',
        help='Cuenta del Banco de la Nación para depósito',
    )

    @api.depends('move_type', 'state', 'line_ids')
    def _compute_spot_fields(self):
        """
        Calcula los campos de detracción SPOT desde _l10n_pe_edi_get_spot().
        """
        for move in self:
            # Inicializar valores por defecto
            move.l10n_pe_edi_has_spot = False
            move.l10n_pe_edi_spot_amount = 0.0
            move.l10n_pe_edi_spot_amount_signed = 0.0
            move.l10n_pe_edi_spot_payment_percent = 0.0
            move.l10n_pe_edi_spot_payment_means_id = ''
            move.l10n_pe_edi_spot_bank_account = ''

            # Solo para facturas de cliente
            if move.move_type not in ('out_invoice', 'out_refund'):
                continue

            # Obtener datos de SPOT
            try:
                spot = move._l10n_pe_edi_get_spot()

                if spot and isinstance(spot, dict) and spot.get('id') == 'Detraccion':
                    move.l10n_pe_edi_has_spot = True
                    move.l10n_pe_edi_spot_amount = spot.get('spot_amount', 0.0)
                    move.l10n_pe_edi_spot_amount_signed = spot.get('amount', 0.0)
                    move.l10n_pe_edi_spot_payment_percent = spot.get('payment_percent', 0.0)
                    move.l10n_pe_edi_spot_payment_means_id = spot.get('payment_means_id', '')
                    move.l10n_pe_edi_spot_bank_account = spot.get('payee_financial_account', '')

            except Exception:
                # Si hay error, mantener valores por defecto
                pass

    @api.constrains('l10n_pe_edi_operation_type', 'invoice_line_ids')
    def _check_detraction_service_required(self):
        """
        Valida que las facturas con tipo de operación de detracción (1001-1004)
        tengan al menos un servicio con código y porcentaje de detracción configurados.
        """
        for move in self:
            # Solo aplica para facturas de cliente (no notas de crédito)
            if move.move_type != 'out_invoice':
                continue

            # Solo aplica para tipos de operación de detracción
            if move.l10n_pe_edi_operation_type not in DETRACTION_OPERATION_TYPES:
                continue

            # Buscar líneas con productos de tipo servicio que tengan detracción configurada
            service_lines_with_detraction = move.invoice_line_ids.filtered(
                lambda l: l.product_id
                and l.product_id.type == 'service'
                and l.product_id.l10n_pe_withhold_code
                and l.product_id.l10n_pe_withhold_percentage
            )

            if not service_lines_with_detraction:
                raise ValidationError(_(
                    'La factura tiene tipo de operación con detracción (%s) pero no contiene '
                    'ningún servicio con código y porcentaje de detracción configurados.\n\n'
                    'Debe agregar al menos un producto de tipo "Servicio" que tenga '
                    'configurados los campos:\n'
                    '- Código de Detracción (l10n_pe_withhold_code)\n'
                    '- Porcentaje de Detracción (l10n_pe_withhold_percentage)'
                ) % move.l10n_pe_edi_operation_type)

    def _post(self, soft=True):
        """
        Override para validar tipo de operación con detracción antes de confirmar.
        """
        for move in self:
            # Solo aplica para facturas de cliente
            if move.move_type != 'out_invoice':
                continue

            # Buscar servicios con detracción configurada
            services_with_detraction = move.invoice_line_ids.filtered(
                lambda l: l.product_id
                and l.product_id.type == 'service'
                and l.product_id.l10n_pe_withhold_percentage
                and l.product_id.l10n_pe_withhold_percentage > 0
            )

            # Si hay servicios con detracción, el tipo de operación debe ser de detracción
            if services_with_detraction and move.l10n_pe_edi_operation_type not in DETRACTION_OPERATION_TYPES:
                service_names = ', '.join(services_with_detraction.mapped('product_id.name'))
                raise ValidationError(_(
                    'La factura contiene servicios con detracción configurada:\n%s\n\n'
                    'El Tipo de Operación debe ser uno de los siguientes:\n'
                    '- 1001: Venta interna con detracción\n'
                    '- 1002: Venta interna con detracción - Recursos Hidrobiológicos\n'
                    '- 1003: Venta interna con detracción - Transporte Pasajeros\n'
                    '- 1004: Venta interna con detracción - Transporte Carga\n\n'
                    'Tipo de operación actual: %s'
                ) % (service_names, move.l10n_pe_edi_operation_type or 'No seleccionado'))

        return super()._post(soft=soft)

    @api.onchange('invoice_line_ids')
    def _onchange_invoice_line_ids_detraction_warning(self):
        """
        Muestra una advertencia cuando se agregan productos (no servicios)
        a una factura con tipo de operación de detracción, indicando
        el porcentaje de detracción que se aplicará.
        """
        # Solo aplica para facturas de cliente
        if self.move_type != 'out_invoice':
            return

        # Solo aplica para tipos de operación de detracción
        if self.l10n_pe_edi_operation_type not in DETRACTION_OPERATION_TYPES:
            return

        # Verificar si hay productos no-servicio en las líneas
        non_service_products = self.invoice_line_ids.filtered(
            lambda l: l.product_id and l.product_id.type != 'service'
        )

        if non_service_products:
            # Obtener el porcentaje de detracción desde _l10n_pe_edi_get_spot
            spot = self._l10n_pe_edi_get_spot()
            payment_percent = spot.get('payment_percent', 0) if spot else 0

            # Si no hay porcentaje de SPOT aún, calcular desde los servicios
            if not payment_percent:
                service_percentages = self.invoice_line_ids.filtered(
                    lambda l: l.product_id and l.product_id.type == 'service'
                ).mapped('product_id.l10n_pe_withhold_percentage')
                payment_percent = max(service_percentages, default=0)

            if payment_percent:
                product_names = ', '.join(non_service_products.mapped('product_id.name'))
                return {
                    'warning': {
                        'title': _('Aviso de Detracción'),
                        'message': _(
                            'Los siguientes productos no son servicios:\n%s\n\n'
                            'Esta factura tiene detracción del %.2f%% configurada.\n'
                            'El monto de detracción se calculará sobre el total de la factura, '
                            'incluyendo estos productos.'
                        ) % (product_names, payment_percent),
                    }
                }

    @api.onchange('invoice_line_ids')
    def _onchange_invoice_line_ids_auto_detraction_type(self):
        """
        Cambia automáticamente el tipo de operación a '1001' cuando se agrega
        un servicio con detracción y el tipo actual no es de detracción.
        """
        # Solo aplica para facturas de cliente
        if self.move_type != 'out_invoice':
            return

        # Solo aplica si el tipo de operación NO es de detracción
        if self.l10n_pe_edi_operation_type in DETRACTION_OPERATION_TYPES:
            return

        # Buscar servicios con porcentaje de detracción configurado
        services_with_detraction = self.invoice_line_ids.filtered(
            lambda l: l.product_id
            and l.product_id.type == 'service'
            and l.product_id.l10n_pe_withhold_percentage
            and l.product_id.l10n_pe_withhold_percentage > 0
        )

        if services_with_detraction:
            # Obtener el porcentaje máximo de detracción
            max_percentage = max(services_with_detraction.mapped('product_id.l10n_pe_withhold_percentage'))
            service_names = ', '.join(services_with_detraction.mapped('product_id.name'))

            # Cambiar el tipo de operación a '1001'
            self.l10n_pe_edi_operation_type = '1001'

            return {
                'warning': {
                    'title': _('Tipo de Operación Actualizado'),
                    'message': _(
                        'Se ha cambiado automáticamente el Tipo de Operación a "1001" '
                        '(Venta interna con detracción) porque se agregó un servicio '
                        'con detracción configurada.\n\n'
                        'Servicio(s): %s\n'
                        'Porcentaje de detracción: %.2f%%'
                    ) % (service_names, max_percentage),
                }
            }
