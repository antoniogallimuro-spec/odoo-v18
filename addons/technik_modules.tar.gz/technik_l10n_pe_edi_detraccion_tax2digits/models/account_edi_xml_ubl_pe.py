# -*- coding: utf-8 -*-
from odoo import models
from odoo.tools import float_round, float_compare
import logging

_logger = logging.getLogger(__name__)

# Precisión fija para montos de impuestos en XML SUNAT (2 decimales)
SUNAT_TAX_PRECISION = 2


class AccountEdiXmlUBL21PE(models.AbstractModel):
    """
    Extensión del generador XML UBL 2.1 para Perú.

    Redondea los montos de impuestos a 2 dígitos al generar XML para SUNAT
    y aplica cuadre para evitar errores de validación.
    """
    _inherit = 'account.edi.xml.ubl_pe'

    def _force_currency_dp_2(self, obj):
        """
        Función recursiva para forzar currency_dp=2 en toda la estructura.
        Modifica el objeto en lugar.
        """
        if isinstance(obj, dict):
            if 'currency_dp' in obj:
                obj['currency_dp'] = SUNAT_TAX_PRECISION
            for value in obj.values():
                self._force_currency_dp_2(value)
        elif isinstance(obj, list):
            for item in obj:
                self._force_currency_dp_2(item)

    def _export_invoice_vals(self, invoice):
        """
        Override para forzar currency_dp=2 en todo el XML.
        Esto asegura que todos los montos se formateen con 2 decimales.
        """
        vals = super()._export_invoice_vals(invoice)

        # Forzar currency_dp=2 en toda la estructura del XML
        self._force_currency_dp_2(vals)

        return vals
