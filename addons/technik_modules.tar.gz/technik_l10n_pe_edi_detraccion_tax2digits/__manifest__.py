# -*- coding: utf-8 -*-
{
    'name': 'Technik Peru EDI - Detracción y Redondeo Impuestos',
    'version': '18.0.1.1.0',
    'category': 'Accounting/Localizations/EDI',
    'summary': 'Muestra campos SPOT y redondea impuestos a 2 dígitos para SUNAT',
    'description': """
Technik Peru EDI - Detracción y Redondeo Impuestos
==============================================

Este módulo extiende la funcionalidad de facturación electrónica para Perú.

Características:

1. Campos de Detracción SPOT
   - Muestra campos computados de información SPOT en facturas
   - Monto Detracción (spot_amount)
   - Monto Detracción Firmado (amount)
   - Porcentaje Detracción (payment_percent)
   - Código SPOT (payment_means_id)
   - Cuenta Banco Nación (payee_financial_account)

2. Redondeo de Impuestos para SUNAT
   - Redondea montos de impuestos a 2 decimales al generar XML
   - Aplica cuadre automático para evitar errores de validación
   - Ideal para facturas en moneda extranjera con más decimales
   - Evita errores SUNAT 3292 (discrepancia de totales)

Los campos SPOT se muestran debajo del campo 'Importe adeudado'
solo cuando la factura tiene detracción configurada.
    """,
    'author': 'Technik',
    'website': '',
    'depends': [
        'l10n_pe_edi',
        'l10n_pe_edi_catalog',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/account_move_views.xml',
        'views/product_template_views.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
    'license': 'LGPL-3',
}
