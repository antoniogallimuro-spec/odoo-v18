{
    'name': 'Technik - Tipo de Moneda LATAM',
    'version': '18.0.1.0.0',
    'category': 'Accounting',
    'summary': 'Agrega tipo de moneda (Compra/Venta) para países LATAM',
    'description': """
        Este módulo agrega un campo tipo (Compra/Venta) a las monedas
        y muestra esta información en los selectores.
    """,
    'author': 'shinseiki.nge@gmail.com',
    'website': 'https://fya.pe',
    'depends': ['base', 'account'],
    'data': [
        'views/currency_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
