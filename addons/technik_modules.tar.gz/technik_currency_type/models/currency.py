from odoo import models, fields, api
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class ResCurrency(models.Model):
    _inherit = 'res.currency'
    
    currency_type = fields.Selection(
        selection=[
            ('compra', 'Compra'),
            ('venta', 'Venta'),
        ],
        string='Tipo de Moneda',
        help='Especifica si la moneda es para compra o venta'
    )

    _sql_constraints = [
        ('unique_name', 
         'UNIQUE(name, currency_type)', 
         'The combination of currency name and type must be unique!'),
    ]

    @api.constrains('name', 'currency_type')
    def _check_name_currency_type_unique(self):
        """Validación a nivel de Python para la unicidad"""
        for currency in self:
            if currency.name:
                domain = [
                    ('name', '=', currency.name),
                    ('currency_type', '=', currency.currency_type),
                    ('id', '!=', currency.id)
                ]
                existing = self.search(domain, limit=1)
                if existing:
                    raise ValidationError(
                        f"Ya existe una moneda con código '{currency.name}' y tipo '{currency.currency_type}'. "
                        "La combinación de código y tipo de moneda debe ser única."
                    )
    
    @api.depends('name', 'currency_type')
    def _compute_display_name(self):
        """Sobrescribir name_get para mostrar el tipo de moneda si existe"""
        for currency in self:
            name = currency.name
            if currency.currency_type:
                type_display = dict(self._fields['currency_type'].selection).get(currency.currency_type)
                name = f"{name} ({type_display})"
            currency.display_name = name
    
    @api.model
    def _name_search(self, name='', args=None, operator='ilike', limit=100, name_get_uid=None):
        """Sobrescribir _name_search para buscar también por tipo de moneda"""
        if args is None:
            args = []
        domain = args + ['|', '|', 
                        ('name', operator, name),
                        ('full_name', operator, name),
                        ('currency_type', operator, name)]
        return self._search(domain, limit=limit, access_rights_uid=name_get_uid)
    
    @api.model
    def create(self, vals):
        """Handle creation with new constraints"""
        record = super().create(vals)
        # Forzar la validación de constraints
        record._check_name_currency_type_unique()
        return record
    
    def write(self, vals):
        """Handle write with new constraints"""
        self._check_name_currency_type_unique()
        result = super().write(vals)
        return result
