# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PleLine0902(models.Model):
    _name = 'ple.line.09.02'
    _description = 'PLE 9.2 - Línea de Consignaciones (Consignatario)'
    _order = 'report_id, sequence, id'

    report_id = fields.Many2one(
        'ple.report.09',
        string='Reporte PLE 9.0',
        required=True,
        ondelete='cascade',
        index=True
    )

    sequence = fields.Integer(
        string='Secuencia',
        default=10,
        help='Número correlativo del registro'
    )

    period = fields.Char(
        string='Período',
        related='report_id.period',
        store=True,
        readonly=True
    )

    # Campo 3: Fecha de Recepción
    reception_date = fields.Date(
        string='Fecha de Recepción',
        required=True,
        help='Fecha de recepción de los bienes en consignación'
    )

    # Campos 4-6: Datos del Consignador
    consignor_doc_type = fields.Char(
        string='Tipo Doc. Consignador',
        size=2,
        help='Tipo de documento de identidad del consignador (6=RUC, 1=DNI, etc.)'
    )

    consignor_vat = fields.Char(
        string='Número Documento',
        size=20,
        help='Número de documento del consignador'
    )

    consignor_name = fields.Char(
        string='Nombre Consignador',
        size=200,
        help='Apellidos y nombres, denominación o razón social del consignador'
    )

    # Campo 7: Descripción del Bien
    goods_description = fields.Char(
        string='Descripción del Bien',
        size=200,
        required=True,
        help='Descripción detallada del bien recibido en consignación'
    )

    # Campo 8: Unidad de Medida
    uom_code = fields.Char(
        string='Unidad de Medida',
        size=10,
        help='Código de la unidad de medida (UNI, KGM, MTR, etc.)'
    )

    # Campos 9-12: Cantidades
    received_qty = fields.Float(
        string='Cantidad Recibida',
        digits='Product Unit of Measure',
        default=0.0,
        help='Cantidad de bienes recibidos en consignación'
    )

    returned_qty = fields.Float(
        string='Cantidad Devuelta',
        digits='Product Unit of Measure',
        default=0.0,
        help='Cantidad de bienes devueltos al consignador'
    )

    sold_qty = fields.Float(
        string='Cantidad Vendida',
        digits='Product Unit of Measure',
        default=0.0,
        help='Cantidad de bienes vendidos a terceros'
    )

    balance_qty = fields.Float(
        string='Saldo en Consignación',
        digits='Product Unit of Measure',
        compute='_compute_balance_qty',
        store=True,
        help='Saldo de bienes que permanecen en consignación'
    )

    # Campos 13-16: Datos del Comprobante de Pago
    voucher_type = fields.Char(
        string='Tipo Comprobante',
        size=2,
        help='Tipo de comprobante de pago (01=Factura, 03=Boleta, etc.)'
    )

    voucher_series = fields.Char(
        string='Serie',
        size=20,
        help='Serie del comprobante de pago'
    )

    voucher_number = fields.Char(
        string='Número',
        size=20,
        help='Número del comprobante de pago'
    )

    voucher_date = fields.Date(
        string='Fecha Comprobante',
        help='Fecha de emisión del comprobante de pago'
    )

    # Campo 17: Estado
    state_code = fields.Char(
        string='Estado',
        size=1,
        default='1',
        help='Estado del registro (1=Activo, 8=Anulado, 9=Ajuste)'
    )

    # Relación con movimiento de stock (opcional)
    stock_move_id = fields.Many2one(
        'stock.move',
        string='Movimiento de Stock',
        ondelete='set null',
        help='Movimiento de inventario asociado a esta consignación'
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        related='report_id.company_id',
        store=True,
        readonly=True
    )

    @api.depends('received_qty', 'returned_qty', 'sold_qty')
    def _compute_balance_qty(self):
        """Calcula el saldo de bienes en consignación"""
        for line in self:
            line.balance_qty = line.received_qty - line.returned_qty - line.sold_qty

    def _format_txt_line(self):
        """
        Formatea la línea según el formato TXT de SUNAT para libro 9.2

        Estructura del registro 9.2 (17 campos):
        1. Período
        2. Número Correlativo
        3. Fecha de Recepción
        4. Tipo de Documento del Consignador
        5. Número de Documento del Consignador
        6. Nombre del Consignador
        7. Descripción del Bien
        8. Unidad de Medida
        9. Cantidad Recibida
        10. Cantidad Devuelta
        11. Cantidad Vendida
        12. Saldo de Bienes en Consignación
        13. Tipo de Comprobante de Pago
        14. Serie del Comprobante
        15. Número del Comprobante
        16. Fecha de Emisión del Comprobante
        17. Estado
        """
        self.ensure_one()

        # Formatear fecha de recepción
        date_str = self.reception_date.strftime('%d/%m/%Y') if self.reception_date else ''

        # Formatear fecha de comprobante
        voucher_date_str = self.voucher_date.strftime('%d/%m/%Y') if self.voucher_date else ''

        # Formatear cantidades con 2 decimales
        received_str = f"{self.received_qty:.2f}" if self.received_qty else '0.00'
        returned_str = f"{self.returned_qty:.2f}" if self.returned_qty else '0.00'
        sold_str = f"{self.sold_qty:.2f}" if self.sold_qty else '0.00'
        balance_str = f"{self.balance_qty:.2f}" if self.balance_qty else '0.00'

        line_parts = [
            self.period or '',                          # 1. Período
            str(self.sequence) if self.sequence else '', # 2. Número Correlativo
            date_str,                                   # 3. Fecha de Recepción
            self.consignor_doc_type or '',              # 4. Tipo Doc. Consignador
            self.consignor_vat or '',                   # 5. Número Doc. Consignador
            self.consignor_name or '',                  # 6. Nombre Consignador
            self.goods_description or '',               # 7. Descripción del Bien
            self.uom_code or '',                        # 8. Unidad de Medida
            received_str,                               # 9. Cantidad Recibida
            returned_str,                               # 10. Cantidad Devuelta
            sold_str,                                   # 11. Cantidad Vendida
            balance_str,                                # 12. Saldo en Consignación
            self.voucher_type or '',                    # 13. Tipo Comprobante
            self.voucher_series or '',                  # 14. Serie
            self.voucher_number or '',                  # 15. Número
            voucher_date_str,                           # 16. Fecha Comprobante
            self.state_code or '1',                     # 17. Estado
        ]

        return '|'.join(line_parts) + '|'

    @api.onchange('stock_move_id')
    def _onchange_stock_move_id(self):
        """Rellena campos automáticamente desde el movimiento de stock"""
        if self.stock_move_id:
            move = self.stock_move_id
            picking = move.picking_id

            if picking:
                # Fecha de recepción
                if picking.date:
                    self.reception_date = picking.date.date()

                # Datos del consignador (partner del picking)
                if picking.partner_id:
                    partner = picking.partner_id
                    if partner.l10n_latam_identification_type_id:
                        self.consignor_doc_type = partner.l10n_latam_identification_type_id.l10n_pe_vat_code or '6'
                    self.consignor_vat = partner.vat or ''
                    self.consignor_name = partner.name or ''

            # Datos del producto
            if move.product_id:
                self.goods_description = move.product_id.name or ''

            # Unidad de medida
            if move.product_uom:
                self.uom_code = move.product_uom.name or ''

            # Cantidad recibida
            self.received_qty = move.product_uom_qty or 0.0
