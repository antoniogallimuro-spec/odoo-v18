# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
import base64
from datetime import datetime


class PleReport09(models.Model):
    _name = 'ple.report.09'
    _description = 'PLE 9.0 - Registro de Consignaciones'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc, month desc, id desc'

    name = fields.Char(
        string='Nombre',
        required=True,
        readonly=True,
        copy=False,
        default='Nuevo',
        tracking=True
    )

    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: self.env.company,
        tracking=True
    )

    year = fields.Integer(
        string='Año',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: datetime.now().year,
        tracking=True
    )

    month = fields.Selection(
        [
            ('01', 'Enero'),
            ('02', 'Febrero'),
            ('03', 'Marzo'),
            ('04', 'Abril'),
            ('05', 'Mayo'),
            ('06', 'Junio'),
            ('07', 'Julio'),
            ('08', 'Agosto'),
            ('09', 'Septiembre'),
            ('10', 'Octubre'),
            ('11', 'Noviembre'),
            ('12', 'Diciembre'),
        ],
        string='Mes',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        default=lambda self: str(datetime.now().month).zfill(2),
        tracking=True
    )

    period = fields.Char(
        string='Período',
        compute='_compute_period',
        store=True,
        help='Formato AAAAMM00'
    )

    date_from = fields.Date(
        string='Fecha Desde',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        tracking=True
    )

    date_to = fields.Date(
        string='Fecha Hasta',
        required=True,
        readonly=True,
        states={'draft': [('readonly', False)]},
        tracking=True
    )

    state = fields.Selection(
        [
            ('draft', 'Borrador'),
            ('generated', 'Generado'),
            ('published', 'Publicado'),
        ],
        string='Estado',
        default='draft',
        required=True,
        tracking=True
    )

    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True,
        copy=False
    )

    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True,
        copy=False
    )

    # Líneas para formato 9.1 (Consignador)
    line_09_01_ids = fields.One2many(
        'ple.line.09.01',
        'report_id',
        string='Registro de Consignaciones - Consignador (9.1)',
        readonly=True,
        states={'draft': [('readonly', False)], 'generated': [('readonly', False)]}
    )

    line_count_09_01 = fields.Integer(
        string='Cantidad de Líneas 9.1',
        compute='_compute_line_counts',
        store=True
    )

    # Líneas para formato 9.2 (Consignatario)
    line_09_02_ids = fields.One2many(
        'ple.line.09.02',
        'report_id',
        string='Registro de Consignaciones - Consignatario (9.2)',
        readonly=True,
        states={'draft': [('readonly', False)], 'generated': [('readonly', False)]}
    )

    line_count_09_02 = fields.Integer(
        string='Cantidad de Líneas 9.2',
        compute='_compute_line_counts',
        store=True
    )

    # Archivos TXT generados
    txt_file_09_01 = fields.Binary(
        string='Archivo TXT 9.1',
        readonly=True,
        copy=False
    )

    txt_filename_09_01 = fields.Char(
        string='Nombre Archivo TXT 9.1',
        readonly=True,
        copy=False
    )

    txt_file_09_02 = fields.Binary(
        string='Archivo TXT 9.2',
        readonly=True,
        copy=False
    )

    txt_filename_09_02 = fields.Char(
        string='Nombre Archivo TXT 9.2',
        readonly=True,
        copy=False
    )

    @api.depends('year', 'month')
    def _compute_period(self):
        """Calcula el período en formato AAAAMM00"""
        for record in self:
            if record.year and record.month:
                record.period = f"{record.year}{record.month}00"
            else:
                record.period = False

    @api.depends('line_09_01_ids', 'line_09_02_ids')
    def _compute_line_counts(self):
        """Calcula la cantidad de líneas para cada formato"""
        for record in self:
            record.line_count_09_01 = len(record.line_09_01_ids)
            record.line_count_09_02 = len(record.line_09_02_ids)

    @api.onchange('year', 'month')
    def _onchange_year_month(self):
        """Actualiza las fechas según el año y mes seleccionados"""
        if self.year and self.month:
            month_int = int(self.month)
            self.date_from = datetime(self.year, month_int, 1).date()

            # Último día del mes
            if month_int == 12:
                next_month = datetime(self.year + 1, 1, 1)
            else:
                next_month = datetime(self.year, month_int + 1, 1)

            from datetime import timedelta
            self.date_to = (next_month - timedelta(days=1)).date()

    @api.model_create_multi
    def create(self, vals_list):
        """Genera el nombre automáticamente al crear"""
        for vals in vals_list:
            if vals.get('name', 'Nuevo') == 'Nuevo':
                year = vals.get('year', datetime.now().year)
                month = vals.get('month', str(datetime.now().month).zfill(2))
                company = self.env['res.company'].browse(
                    vals.get('company_id', self.env.company.id)
                )
                vals['name'] = f"PLE 9.0 - {company.name} - {year}/{month}"

        return super().create(vals_list)

    def action_generate(self):
        """Genera las líneas del reporte desde los movimientos de consignación"""
        self.ensure_one()

        if self.state != 'draft':
            raise UserError('Solo se pueden generar reportes en estado Borrador.')

        # Eliminar líneas existentes
        self.line_09_01_ids.unlink()
        self.line_09_02_ids.unlink()

        # Generar líneas 9.1 (Consignador)
        self._generate_lines_09_01()

        # Generar líneas 9.2 (Consignatario)
        self._generate_lines_09_02()

        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now(),
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _(
                    f'Se generaron {self.line_count_09_01} líneas para formato 9.1 '
                    f'y {self.line_count_09_02} líneas para formato 9.2'
                ),
                'type': 'success',
                'sticky': False,
            }
        }

    def _generate_lines_09_01(self):
        """
        Genera líneas para el formato 9.1 (Consignador - quien entrega bienes)

        En Odoo, las consignaciones del consignador se pueden rastrear mediante:
        - Movimientos de stock con ubicación de consignación
        - Albaranes de salida con tipo 'consignación'
        """
        self.ensure_one()

        # Buscar movimientos de stock en consignación como consignador
        # (entregas realizadas a consignatarios)
        StockMove = self.env['stock.move']
        StockPicking = self.env['stock.picking']

        # Obtener pickings de consignación saliente en el período
        pickings = StockPicking.search([
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('state', '=', 'done'),
            # Filtrar por tipo de operación de consignación si existe
            # ('picking_type_code', '=', 'outgoing'),
        ])

        sequence = 1
        line_obj = self.env['ple.line.09.01']

        for picking in pickings:
            # Por cada picking, verificar si es una consignación
            # En una implementación real, esto debería verificar un campo específico
            # que marque el picking como consignación

            for move in picking.move_ids:
                if move.state != 'done':
                    continue

                # Crear línea de consignación
                line_obj.create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'issue_date': picking.date.date() if picking.date else False,
                    'consignee_doc_type': picking.partner_id.l10n_latam_identification_type_id.l10n_pe_vat_code or '6',
                    'consignee_vat': picking.partner_id.vat or '',
                    'consignee_name': picking.partner_id.name or '',
                    'goods_description': move.product_id.name or '',
                    'uom_code': move.product_uom.name or '',
                    'delivered_qty': move.product_uom_qty,
                    'returned_qty': 0.0,
                    'sold_qty': 0.0,
                    'balance_qty': move.product_uom_qty,
                    'voucher_type': '',
                    'voucher_series': '',
                    'voucher_number': '',
                    'voucher_date': False,
                    'state_code': '1',
                    'stock_move_id': move.id,
                })

                sequence += 1

    def _generate_lines_09_02(self):
        """
        Genera líneas para el formato 9.2 (Consignatario - quien recibe bienes)

        En Odoo, las consignaciones del consignatario se pueden rastrear mediante:
        - Movimientos de stock recibidos en consignación
        - Albaranes de entrada con tipo 'consignación'
        """
        self.ensure_one()

        StockPicking = self.env['stock.picking']

        # Obtener pickings de consignación entrante en el período
        pickings = StockPicking.search([
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('state', '=', 'done'),
            # Filtrar por tipo de operación de consignación si existe
            # ('picking_type_code', '=', 'incoming'),
        ])

        sequence = 1
        line_obj = self.env['ple.line.09.02']

        for picking in pickings:
            for move in picking.move_ids:
                if move.state != 'done':
                    continue

                # Crear línea de consignación
                line_obj.create({
                    'report_id': self.id,
                    'sequence': sequence,
                    'reception_date': picking.date.date() if picking.date else False,
                    'consignor_doc_type': picking.partner_id.l10n_latam_identification_type_id.l10n_pe_vat_code or '6',
                    'consignor_vat': picking.partner_id.vat or '',
                    'consignor_name': picking.partner_id.name or '',
                    'goods_description': move.product_id.name or '',
                    'uom_code': move.product_uom.name or '',
                    'received_qty': move.product_uom_qty,
                    'returned_qty': 0.0,
                    'sold_qty': 0.0,
                    'balance_qty': move.product_uom_qty,
                    'voucher_type': '',
                    'voucher_series': '',
                    'voucher_number': '',
                    'voucher_date': False,
                    'state_code': '1',
                    'stock_move_id': move.id,
                })

                sequence += 1

    def action_publish(self):
        """Genera los archivos TXT y publica el reporte"""
        self.ensure_one()

        if self.state != 'generated':
            raise UserError('Solo se pueden publicar reportes en estado Generado.')

        # Generar archivos TXT
        self._generate_txt_09_01()
        self._generate_txt_09_02()

        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now(),
        })

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def _generate_txt_09_01(self):
        """Genera el archivo TXT para formato 9.1 (Consignador)"""
        self.ensure_one()

        # Obtener RUC de la compañía
        ruc = self.company_id.vat or '00000000000'
        if len(ruc) < 11:
            ruc = ruc.zfill(11)

        # Formato del nombre del archivo:
        # LE{RUC}{PERIODO}000901{ESTABLECIMIENTO}{OIM}1.txt
        establecimiento = '0000'
        oim = '00011'  # Operación, Indicador, Moneda

        filename = f"LE{ruc}{self.period}000901{establecimiento}{oim}1.txt"

        # Generar contenido del archivo
        lines = []
        for line in self.line_09_01_ids:
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        # Si no hay líneas, agregar una línea vacía según estándar SUNAT
        if not lines:
            lines.append(f"{self.period}||||||||||||||||||1|")

        content = '\r\n'.join(lines)

        # Codificar en base64
        content_b64 = base64.b64encode(content.encode('utf-8'))

        self.write({
            'txt_file_09_01': content_b64,
            'txt_filename_09_01': filename,
        })

    def _generate_txt_09_02(self):
        """Genera el archivo TXT para formato 9.2 (Consignatario)"""
        self.ensure_one()

        # Obtener RUC de la compañía
        ruc = self.company_id.vat or '00000000000'
        if len(ruc) < 11:
            ruc = ruc.zfill(11)

        # Formato del nombre del archivo:
        # LE{RUC}{PERIODO}000902{ESTABLECIMIENTO}{OIM}1.txt
        establecimiento = '0000'
        oim = '00011'

        filename = f"LE{ruc}{self.period}000902{establecimiento}{oim}1.txt"

        # Generar contenido del archivo
        lines = []
        for line in self.line_09_02_ids:
            txt_line = line._format_txt_line()
            lines.append(txt_line)

        # Si no hay líneas, agregar una línea vacía según estándar SUNAT
        if not lines:
            lines.append(f"{self.period}||||||||||||||||||1|")

        content = '\r\n'.join(lines)

        # Codificar en base64
        content_b64 = base64.b64encode(content.encode('utf-8'))

        self.write({
            'txt_file_09_02': content_b64,
            'txt_filename_09_02': filename,
        })

    def action_back_to_draft(self):
        """Regresa el reporte a estado Borrador"""
        self.ensure_one()

        self.write({
            'state': 'draft',
            'generation_date': False,
            'publication_date': False,
            'txt_file_09_01': False,
            'txt_filename_09_01': False,
            'txt_file_09_02': False,
            'txt_filename_09_02': False,
        })

        return True

    def action_view_lines_09_01(self):
        """Abre la vista de líneas del formato 9.1"""
        self.ensure_one()

        return {
            'name': _('Consignaciones - Consignador (9.1)'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.09.01',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id},
        }

    def action_view_lines_09_02(self):
        """Abre la vista de líneas del formato 9.2"""
        self.ensure_one()

        return {
            'name': _('Consignaciones - Consignatario (9.2)'),
            'type': 'ir.actions.act_window',
            'res_model': 'ple.line.09.02',
            'view_mode': 'list,form',
            'domain': [('report_id', '=', self.id)],
            'context': {'default_report_id': self.id},
        }

    def unlink(self):
        """Evita eliminar reportes que no estén en borrador"""
        for record in self:
            if record.state != 'draft':
                raise UserError(
                    'No se pueden eliminar reportes que no estén en estado Borrador. '
                    'Primero regrese el reporte a Borrador.'
                )

        return super().unlink()
