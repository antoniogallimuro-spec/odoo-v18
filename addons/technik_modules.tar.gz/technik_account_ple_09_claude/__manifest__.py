# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 9.0 - Registro de Consignaciones',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 9.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 9.0 - Registro de Consignaciones para Odoo 18
==================================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 9.0
correspondiente al Registro de Consignaciones según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 9.0 por período mensual
* Soporte para dos formatos:
  - 9.1: Registro para el Consignador (quien entrega bienes)
  - 9.2: Registro para el Consignatario (quien recibe bienes)
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos mensuales
* Control de bienes entregados y recibidos en consignación
* Seguimiento de movimientos: entregados, devueltos, vendidos

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período mensual
3. Generar: Obtiene los movimientos de consignación
4. Publicar: Genera los archivos TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 09.01: Registro de Consignaciones - Consignador
* 09.02: Registro de Consignaciones - Consignatario

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}000901{ESTABLECIMIENTO}{OIM}1.txt (Formato 9.1)
LE{RUC}{PERIODO}000902{ESTABLECIMIENTO}{OIM}1.txt (Formato 9.2)

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato AAAAMM00 (año, mes y 00)
- ESTABLECIMIENTO: Código de establecimiento (0000 por defecto)
- OIM: Código de operación, indicador y moneda

Campos del Registro 9.1 (Consignador):
---------------------------------------
1. Período
2. Número Correlativo
3. Fecha de Emisión de Guía/Comprobante
4. Tipo de Documento del Consignatario
5. Número de Documento del Consignatario
6. Nombre del Consignatario
7. Descripción del Bien
8. Unidad de Medida
9. Cantidad Entregada
10. Cantidad Devuelta
11. Cantidad Vendida
12. Saldo de Bienes en Consignación
13. Tipo de Comprobante de Pago
14. Serie del Comprobante
15. Número del Comprobante
16. Fecha de Emisión del Comprobante
17. Estado

Campos del Registro 9.2 (Consignatario):
-----------------------------------------
1. Período
2. Número Correlativo
3. Fecha de Recepción
4. Tipo de Documento del Consignador
5. Número de Documento del Consignador
6. Nombre del Consignador
7. Descripción del Bien
8. Unidad de Medida
9. Cantidad Recibida
10. Cantidad Devuelta
11. Cantidad Vendida
12. Saldo de Bienes en Consignación
13. Tipo de Comprobante de Pago
14. Serie del Comprobante
15. Número del Comprobante
16. Fecha de Emisión del Comprobante
17. Estado

¿Qué es la Consignación?
-------------------------
La consignación es un contrato mercantil donde el consignador (propietario) entrega
bienes al consignatario para que los venda a terceros. El consignatario solo paga
al consignador cuando vende los bienes, y devuelve lo que no vende.

Casos de Uso:
-------------
- Empresas que entregan productos en consignación a distribuidores
- Distribuidores que reciben productos para vender en consignación
- Control de inventario en consignación
- Facturación de ventas realizadas por el consignatario

    """,
    'author': 'FyA Consultores',
    'website': 'https://www.fyaconsultores.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'stock',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_09_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
