# -*- coding: utf-8 -*-
{
    'name': 'FyA PLE 1.0 - Libro Caja y Bancos',
    'version': '18.0.1.0.0',
    'category': 'Accounting/Localizations/Reporting',
    'summary': 'Generación de reportes PLE 1.0 para cumplimiento tributario SUNAT Perú',
    'description': """
PLE 1.0 - Libro Caja y Bancos para Odoo 18
===========================================

Este módulo implementa la generación del Programa de Libros Electrónicos (PLE) 1.0
correspondiente al Libro Caja y Bancos según los estándares de la SUNAT en Perú.

Características principales:
-----------------------------
* Generación de reportes PLE 1.0 por período o día
* Segregación automática de movimientos de efectivo (cuentas 101x) y bancos (cuentas 104x)
* Flujo de estados: Borrador → Generado → Publicado
* Generación automática de archivos TXT en formato SUNAT
* Gestión de períodos flexibles (diario o mensual)
* Integración completa con el plan contable

Flujo de Trabajo:
-----------------
1. Crear reporte en estado Borrador
2. Seleccionar período y rango de fechas
3. Generar: Obtiene y clasifica los movimientos contables
4. Publicar: Genera los archivos TXT según formato SUNAT

Formatos de Archivo:
--------------------
* 01.01: Movimientos de efectivo (cuentas 101x)
* 01.02: Movimientos de cuenta corriente (cuentas 104x)

Nomenclatura de archivos:
--------------------------
LE{RUC}{PERIODO}030100001011000001.txt (Efectivo)
LE{RUC}{PERIODO}030100001012000001.txt (Bancos)

Donde:
- RUC: Número de RUC de la compañía
- PERIODO: Formato YYYYMMDD según criterio seleccionado

    """,
    'author': 'Tu Empresa',
    'website': 'https://www.tuempresa.com',
    'license': 'LGPL-3',
    'depends': [
        'account',
        'l10n_pe',
        'technik_account_ple_base'
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/ple_report_01_views.xml',
        'views/menu_views.xml',
    ],
    'demo': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
