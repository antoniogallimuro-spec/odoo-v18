# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
import base64
import logging

_logger = logging.getLogger(__name__)


class PleReport01(models.Model):
    _name = 'ple.report.01'
    _description = 'PLE 1.2 - Libro Caja y Bancos'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'year desc, period desc'

    name = fields.Char(
        string='Nombre',
        compute='_compute_name',
        store=True
    )
    company_id = fields.Many2one(
        'res.company',
        string='Compañía',
        required=True,
        default=lambda self: self.env.company,
        tracking=True
    )
    year = fields.Integer(
        string='Año',
        required=True,
        default=lambda self: fields.Date.today().year,
        tracking=True
    )
    period_type = fields.Selection([
        ('day', 'Día'),
        ('period', 'Período')
    ], string='Tipo de Período', required=True, default='period', tracking=True)
    
    period = fields.Char(
        string='Período',
        help='Formato YYYYMMDD según criterio del tipo periodo',
        tracking=True
    )
    date_from = fields.Date(
        string='Fecha Inicio',
        required=True,
        tracking=True
    )
    date_to = fields.Date(
        string='Fecha Fin',
        required=True,
        tracking=True
    )
    day_period_date = fields.Date(
        string='Día/Fecha Período',
        help='Fecha específica cuando el tipo es día'
    )
    
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('generated', 'Generado'),
        ('published', 'Publicado')
    ], string='Estado', default='draft', required=True, tracking=True)
    
    generation_date = fields.Datetime(
        string='Fecha de Generación',
        readonly=True
    )
    publication_date = fields.Datetime(
        string='Fecha de Publicación',
        readonly=True
    )
    
    # Líneas de detalle
    line_01_01_ids = fields.One2many(
        'ple.report.01.line.01.01',
        'ple_report_01_id',
        string='Movimientos de Efectivo'
    )
    line_01_02_ids = fields.One2many(
        'ple.report.01.line.01.02',
        'ple_report_01_id',
        string='Movimientos de Cuenta Corriente'
    )
    
    # Campos computados
    count_line_01_01 = fields.Integer(
        string='Líneas Efectivo',
        compute='_compute_line_counts'
    )
    count_line_01_02 = fields.Integer(
        string='Líneas Cta. Corriente',
        compute='_compute_line_counts'
    )
    
    # Archivos generados
    txt_file_01_01 = fields.Binary(
        string='Archivo TXT 01.01',
        readonly=True
    )
    txt_filename_01_01 = fields.Char(
        string='Nombre Archivo 01.01',
        readonly=True
    )
    txt_file_01_02 = fields.Binary(
        string='Archivo TXT 01.02',
        readonly=True
    )
    txt_filename_01_02 = fields.Char(
        string='Nombre Archivo 01.02',
        readonly=True
    )

    @api.depends('year', 'period', 'period_type')
    def _compute_name(self):
        for record in self:
            if record.period_type == 'day':
                record.name = f"PLE 1.2 - {record.year} - Día {record.period or ''}"
            else:
                record.name = f"PLE 1.2 - {record.year} - Período {record.period or ''}"

    @api.depends('line_01_01_ids', 'line_01_02_ids')
    def _compute_line_counts(self):
        for record in self:
            record.count_line_01_01 = len(record.line_01_01_ids)
            record.count_line_01_02 = len(record.line_01_02_ids)

    @api.onchange('period_type', 'day_period_date', 'date_from', 'date_to')
    def _onchange_period(self):
        """Calcula automáticamente el período en formato YYYYMMDD"""
        if self.period_type == 'day' and self.day_period_date:
            self.period = self.day_period_date.strftime('%Y%m%d')
        elif self.period_type == 'period' and self.date_from and self.date_to:
            # Para período, usar YYYYMM00
            self.period = self.date_from.strftime('%Y%m00')

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for record in self:
            if record.date_from and record.date_to and record.date_from > record.date_to:
                raise ValidationError(_('La fecha de inicio no puede ser mayor a la fecha fin.'))

    def action_generate(self):
        """Genera las líneas del reporte PLE según el período seleccionado"""
        self.ensure_one()
        
        if self.state != 'draft':
            raise UserError(_('Solo se pueden generar reportes en estado Borrador.'))
        
        # Limpiar líneas existentes
        self.line_01_01_ids.unlink()
        self.line_01_02_ids.unlink()
        
        # Obtener movimientos contables en el rango de fechas
        domain = [
            ('company_id', '=', self.company_id.id),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
            ('parent_state', '=', 'posted'),  # Solo asientos contabilizados
        ]
        
        move_lines = self.env['account.move.line'].search(domain)
        
        # Cuentas de efectivo (10) y bancos (104)
        cash_accounts = move_lines.filtered(
            lambda l: l.account_id.code and l.account_id.code.startswith('101')
        )
        bank_accounts = move_lines.filtered(
            lambda l: l.account_id.code and l.account_id.code.startswith('104')
        )
        
        # Crear líneas de efectivo
        line_01_01_vals = []
        for line in cash_accounts:
            line_01_01_vals.append({
                'ple_report_01_id': self.id,
                'line_01_id': line.id,
            })
        
        # Crear líneas de cuenta corriente
        line_01_02_vals = []
        for line in bank_accounts:
            line_01_02_vals.append({
                'ple_report_01_id': self.id,
                'line_02_id': line.id,
            })
        
        if line_01_01_vals:
            self.env['ple.report.01.line.01.01'].create(line_01_01_vals)
        
        if line_01_02_vals:
            self.env['ple.report.01.line.01.02'].create(line_01_02_vals)
        
        # Actualizar estado
        self.write({
            'state': 'generated',
            'generation_date': fields.Datetime.now()
        })
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Generación Exitosa'),
                'message': _('Se han generado %s líneas de efectivo y %s líneas de cuenta corriente.') % (
                    len(line_01_01_vals), len(line_01_02_vals)
                ),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_publish(self):
        """Publica el reporte generando los archivos TXT"""
        self.ensure_one()
        
        if self.state != 'generated':
            raise UserError(_('Solo se pueden publicar reportes en estado Generado.'))
        
        # Generar archivos TXT
        self._generate_txt_files()
        
        # Actualizar estado
        self.write({
            'state': 'published',
            'publication_date': fields.Datetime.now()
        })
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Publicación Exitosa'),
                'message': _('Los archivos TXT han sido generados correctamente.'),
                'type': 'success',
                'sticky': False,
            }
        }

    def action_back_to_draft(self):
        """Regresa el reporte a estado borrador"""
        self.ensure_one()
        self.write({'state': 'draft'})

    def _generate_txt_files(self):
        """Genera los archivos TXT según formato PLE"""
        self.ensure_one()
        
        # RUC de la compañía
        ruc = self.company_id.vat or '00000000000'
        
        # Formato: LERRRRRRRRRRRAAAAMMDD030100001011000001.txt
        # LE + RUC + AÑO + MES + DIA + 030100001011 + indicador_operaciones + indicador_contenido + moneda + 1.txt
        
        # Generar archivo 01.01 (Efectivo)
        if self.line_01_01_ids:
            content_01_01 = self._generate_txt_content_01_01()
            filename_01_01 = f"LE{ruc}{self.period}030100001011000001.txt"
            
            self.txt_file_01_01 = base64.b64encode(content_01_01.encode('utf-8'))
            self.txt_filename_01_01 = filename_01_01
        
        # Generar archivo 01.02 (Cuenta Corriente)
        if self.line_01_02_ids:
            content_01_02 = self._generate_txt_content_01_02()
            filename_01_02 = f"LE{ruc}{self.period}030100001012000001.txt"
            
            self.txt_file_01_02 = base64.b64encode(content_01_02.encode('utf-8'))
            self.txt_filename_01_02 = filename_01_02

    def _generate_txt_content_01_01(self):
        """Genera el contenido del archivo TXT para movimientos de efectivo"""
        lines = []
        
        for line in self.line_01_01_ids:
            move_line = line.line_01_id
            move = move_line.move_id
            
            # Formato PLE 1.2 - Libro Caja (simplificado)
            txt_line = "|".join([
                self.period,  # Período
                move_line.account_id.code or '',  # Código cuenta
                move.name or '',  # Número correlativo
                move.date.strftime('%d/%m/%Y') if move.date else '',  # Fecha
                move_line.name or '',  # Glosa
                f"{move_line.debit:.2f}",  # Debe
                f"{move_line.credit:.2f}",  # Haber
                '1',  # Estado
            ])
            lines.append(txt_line)
        
        return "\n".join(lines)

    def _generate_txt_content_01_02(self):
        """Genera el contenido del archivo TXT para movimientos de cuenta corriente"""
        lines = []
        
        for line in self.line_01_02_ids:
            move_line = line.line_02_id
            move = move_line.move_id
            
            # Formato PLE 1.2 - Libro Bancos (simplificado)
            txt_line = "|".join([
                self.period,  # Período
                move_line.account_id.code or '',  # Código cuenta
                move.name or '',  # Número correlativo
                move.date.strftime('%d/%m/%Y') if move.date else '',  # Fecha
                move_line.name or '',  # Glosa
                f"{move_line.debit:.2f}",  # Debe
                f"{move_line.credit:.2f}",  # Haber
                '1',  # Estado
            ])
            lines.append(txt_line)
        
        return "\n".join(lines)
    
    def action_view_move_lines(self):
        """Abre una vista con los apuntes contables originales"""
        self.ensure_one()
        
        # Obtener IDs de los move lines de ambos tipos
        cash_line_ids = self.line_01_01_ids.mapped('line_01_id').ids
        bank_line_ids = self.line_01_02_ids.mapped('line_02_id').ids
        all_line_ids = cash_line_ids + bank_line_ids
        
        return {
            'name': _('Apuntes Contables - %s') % self.name,
            'type': 'ir.actions.act_window',
            'res_model': 'account.move.line',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', all_line_ids)],
            'context': {
                'search_default_group_by_account': 1,
                'search_default_posted': 1,
            }
        }


class PleReport01Line0101(models.Model):
    _name = 'ple.report.01.line.01.01'
    _description = 'PLE 1.2 - Línea Libro Caja (Efectivo)'
    _order = 'line_01_id'

    ple_report_01_id = fields.Many2one(
        'ple.report.01',
        string='Reporte PLE',
        required=True,
        ondelete='cascade'
    )
    line_01_id = fields.Many2one(
        'account.move.line',
        string='Línea Contable',
        required=True,
        domain=[('account_id.code', '=like', '101%')]
    )
    
    # Campos relacionados para visualización
    date = fields.Date(
        related='line_01_id.date',
        string='Fecha',
        store=True
    )
    account_id = fields.Many2one(
        related='line_01_id.account_id',
        string='Cuenta',
        store=True
    )
    move_id = fields.Many2one(
        related='line_01_id.move_id',
        string='Asiento Contable',
        store=True
    )
    debit = fields.Monetary(
        related='line_01_id.debit',
        string='Debe'
    )
    credit = fields.Monetary(
        related='line_01_id.credit',
        string='Haber'
    )
    balance = fields.Monetary(
        related='line_01_id.balance',
        string='Balance'
    )
    currency_id = fields.Many2one(
        related='line_01_id.currency_id',
        string='Moneda'
    )


class PleReport01Line0102(models.Model):
    _name = 'ple.report.01.line.01.02'
    _description = 'PLE 1.2 - Línea Libro Bancos (Cuenta Corriente)'
    _order = 'line_02_id'

    ple_report_01_id = fields.Many2one(
        'ple.report.01',
        string='Reporte PLE',
        required=True,
        ondelete='cascade'
    )
    line_02_id = fields.Many2one(
        'account.move.line',
        string='Línea Contable',
        required=True,
        domain=[('account_id.code', '=like', '104%')]
    )
    
    # Campos relacionados para visualización
    date = fields.Date(
        related='line_02_id.date',
        string='Fecha',
        store=True
    )
    account_id = fields.Many2one(
        related='line_02_id.account_id',
        string='Cuenta',
        store=True
    )
    move_id = fields.Many2one(
        related='line_02_id.move_id',
        string='Asiento Contable',
        store=True
    )
    debit = fields.Monetary(
        related='line_02_id.debit',
        string='Debe'
    )
    credit = fields.Monetary(
        related='line_02_id.credit',
        string='Haber'
    )
    balance = fields.Monetary(
        related='line_02_id.balance',
        string='Balance'
    )
    currency_id = fields.Many2one(
        related='line_02_id.currency_id',
        string='Moneda'
    )