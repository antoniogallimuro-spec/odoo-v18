{
    'name': 'Technik - Product Code Migration',
    'version': '18.0.1.0.0',
    'category': 'Inventory',
    'summary': 'Agrega campo codigo_fya para migracion de productos',
    'description': """
        Modulo encargado de agregar el campo codigo_fya (Codigo FyA)
        al modelo de productos para facilitar la migracion de datos.
        Este campo permite buscar y filtrar productos por el codigo FyA.
    """,
    'author': 'shinseiki.nge@gmail.com',
    'website': 'https://fya.pe',
    'depends': ['product', 'stock'],
    'data': [
        'views/product_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
