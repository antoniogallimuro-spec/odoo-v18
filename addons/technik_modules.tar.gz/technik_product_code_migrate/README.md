# Technik - Product Code Migration

## Descripción

Módulo de Odoo v18 que agrega los campos `codigo_fya` (Codigo FyA) y `codigo_almacenable` (Codigo Almacenable) al modelo de productos para facilitar la migración de datos desde sistemas legacy.

## Características

### Campos de Migración

#### Campo codigo_fya

- **Modelo**: `product.template` y `product.product`
- **Tipo**: Char (texto)
- **Características**:
  - Indexado para búsquedas rápidas
  - No se copia al duplicar productos
  - Tracking activado para auditoría de cambios
  - Visible en vistas de formulario, lista y kanban

#### Campo codigo_almacenable

- **Modelo**: `product.template` y `product.product`
- **Tipo**: Char (texto)
- **Características**:
  - Indexado para búsquedas rápidas
  - No se copia al duplicar productos
  - Tracking activado para auditoría de cambios
  - Visible en vistas de formulario, lista y kanban

### Funcionalidades de Búsqueda

Los campos `codigo_fya` y `codigo_almacenable` están integrados en el sistema de búsqueda de productos:

1. **Búsqueda rápida**: Puede buscar productos escribiendo cualquiera de los códigos en el campo de búsqueda
2. **Búsqueda avanzada**: Campos de búsqueda específicos en la vista de filtros
3. **Filtros predefinidos**:
   - "Con Codigo FyA": Muestra solo productos que tienen código FyA
   - "Sin Codigo FyA": Muestra productos sin código FyA
   - "Con Codigo Almacenable": Muestra solo productos que tienen código almacenable
   - "Sin Codigo Almacenable": Muestra productos sin código almacenable

### Vistas Modificadas

- ✓ Vista de Formulario (product.template)
- ✓ Vista de Lista/Tree
- ✓ Vista de Búsqueda/Filtros
- ✓ Vista Kanban
- ✓ Vista de Formulario de Variantes (product.product)

## Instalación

1. Copiar el módulo en la carpeta de addons de Odoo
2. Actualizar la lista de aplicaciones
3. Buscar "Technik - Product Code Migration"
4. Instalar el módulo

## Uso

### Asignar Códigos a un producto

1. Ir a Inventario → Productos → Productos
2. Abrir o crear un producto
3. En el formulario, encontrarás los campos "Codigo FyA" y "Codigo Almacenable" debajo de "Referencia Interna"
4. Ingresar los códigos correspondientes del producto

### Buscar por Códigos

1. En la lista de productos, usar el campo de búsqueda
2. Escribir el código FyA o el código almacenable del producto
3. El sistema buscará automáticamente en nombre, referencia interna, código de barras, código FyA y código almacenable

### Filtrar productos

1. Click en "Filtros" en la vista de productos
2. Seleccionar entre:
   - "Con Codigo FyA" / "Sin Codigo FyA"
   - "Con Codigo Almacenable" / "Sin Codigo Almacenable"

## Dependencias

- `product`: Módulo de productos de Odoo
- `stock`: Módulo de inventario de Odoo

## Versión

- **Odoo**: 18.0
- **Módulo**: 1.0.0

## Autor

shinseiki.nge@gmail.com

## Licencia

LGPL-3
