from odoo import models, fields, api
import logging

_logger = logging.getLogger(__name__)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    codigo_fya = fields.Char(
        string='Codigo FyA',
        help='Codigo de producto FyA para migracion',
        index=True,
        copy=False,
        tracking=True,
    )

    codigo_almacenable = fields.Char(
        string='Codigo Almacenable',
        help='Codigo almacenable de producto para migracion',
        index=True,
        copy=False,
        tracking=True,
    )

    @api.model
    def _name_search(self, name='', domain=None, operator='ilike', limit=None, order=None):
        """
        Extiende la búsqueda de productos para incluir codigo_fya y codigo_almacenable
        Permite buscar productos por codigo_fya y codigo_almacenable ademas de los campos por defecto
        """
        domain = domain or []
        if name:
            # Buscar por codigo_fya y codigo_almacenable ademas de los campos por defecto
            domain = [
                '|', '|', '|', '|',
                ('default_code', operator, name),
                ('name', operator, name),
                ('barcode', operator, name),
                ('codigo_fya', operator, name),
                ('codigo_almacenable', operator, name),
            ] + domain
        return super()._name_search(
            name=name,
            domain=domain,
            operator=operator,
            limit=limit,
            order=order
        )


class ProductProduct(models.Model):
    _inherit = 'product.product'

    # Heredar el campo de product.template para que tambien este disponible en product.product
    codigo_fya = fields.Char(
        related='product_tmpl_id.codigo_fya',
        string='Codigo FyA',
        store=True,
        readonly=False,
    )

    codigo_almacenable = fields.Char(
        related='product_tmpl_id.codigo_almacenable',
        string='Codigo Almacenable',
        store=True,
        readonly=False,
    )
